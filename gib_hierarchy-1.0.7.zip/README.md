# Redwood Starter Application

A starter application template for Redwood applications pre configured with Redwood components and templates
This Template is useful for creating starter applications to get familiar with Redwood.


### Instructions for Use

Visual Builder applications created from this template will have a component-palette that is pre-configured with components that are published in oj-sp Pack 

As new versions of the components are published you will receive notifications to upgrade the components.

For more information on how to build using Redwood components, visit redwood.oracle.com.
