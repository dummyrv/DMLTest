define([], () => {
  'use strict';

  class PageModule {

  
     replaceCurrentHistoryEntry(newChildView) {
      const newState = window.history.state;
      if (newState && newState.vbState && newState.vbState.inputParameters) {
        newState.vbState.inputParameters.childView = newChildView;
      }
  
      window.history.replaceState(newState, '', undefined);
    }

       generatePDF(selection){

 console.log("we got " + selection.length + "selections ");
    for (let i = 0; i < selection.length; i++) {
      console.log("start key " + selection[i].startKey.row +
        ", start index " + +selection[i].startIndex.row);
      console.log("end key " + selection[i].endKey.row + ", end index " +
        +selection[i].endIndex.row);
        //The following loop prints the names
      for (let j = selection[i].startIndex.row; j <= selection[i].endIndex
        .row; j++) {
        let rowdata = document.getElementById("mytable").getDataForVisibleRow(j);
        console.log(rowdata.data.name)
      }
    }
    }


  
  }

  
  return PageModule;
});
