define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterCheckUserRoleExists extends ActionChain {

    /**
     * checking if user has been assigned with a role
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      console.log('role array: ', $application.variables.userRoleVar);

      // ---- TODO: Add your code here ---- //
      let roleCount = 0;
      for(let i = 0; i < $application.variables.userRoleVar.length; i++) {
        if($application.variables.userRoleVar[i] === 'Organizaton-Dev_Hierarchy_Page_User_Role' ) {
          ++roleCount;
          console.log(roleCount);
        }
      }
      if ($application.variables.userRoleVar[($application.variables.userRoleVar.length) - 1] === 'approle.authenticated.user') {
        if (roleCount > 0) {
        } else {
          // navigating to error page
          const errorPageNavigation = await Actions.navigateToPage(context, {
            page: '/shell/main/main-error-page',
          }, { id: 'navigateToErrorPage_02' });
        }
      } else {
        // navigating to error page
        const errorPageNavigation_02 = await Actions.navigateToPage(context, {
          page: '/shell/main/main-error-page',
        }, { id: 'navigateToErrorPage' });
      }
    }
  }

  return vbEnterCheckUserRoleExists;
});
