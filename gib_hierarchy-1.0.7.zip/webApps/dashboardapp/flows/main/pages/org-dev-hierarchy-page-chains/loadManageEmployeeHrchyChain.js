define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadManageEmployeeHrchyChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.manageEmployeeHrchyId 
     * @param {boolean} params.onlyData 
     */
    async run(context, { manageEmployeeHrchyId, onlyData = true }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Test valid input
      if (true && manageEmployeeHrchyId !== undefined) {
        // Clears ManageEmployeeHrchy data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.manageEmployeeHrchy',
          ],
        }, { id: 'resetManageEmployeeHrchyData' });

        // Initiates REST call loading ManageEmployeeHrchy data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_ManageEmployeeHrchy',
          responseType: 'getManageEmployeeHrchyResponse',
          uriParams: {
            'ManageEmployeeHrchy_Id': manageEmployeeHrchyId,
            onlyData: onlyData,
          },
        }, { id: 'loadManageEmployeeHrchy' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the ManageEmployeeHrchy variable
        $page.variables.manageEmployeeHrchy = callRestResult.body;
      }
    }
  }

  return loadManageEmployeeHrchyChain;
});
