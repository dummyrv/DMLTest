define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class GeneralOverviewPageTemplateSpSecondaryActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.actionId 
     */
    async run(context, { actionId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.logout(context, {
        logoutUrl: 'https://oic-vbcs-giboicdev-vb-axopc3t7dala.builder.me-jeddah-1.ocp.oraclecloud.com/ic/builder/logout',
      }, { id: 'logout1' });
    }
  }

  return GeneralOverviewPageTemplateSpSecondaryActionChain1;
});
