define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class currentItemIdListener extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{oldValue:number,value:number}} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_ManageEmployeeHrchy',
        uriParams: {
          'ManageEmployeeHrchy_Id': event.value,
          onlyData: true,
        },
      }, { id: 'invokeEmployeeTableBusinessObject' });

      // assigning value to variable
      $variables.managerID = response.body.reportingManager;
    }
  }

  return currentItemIdListener;
});
