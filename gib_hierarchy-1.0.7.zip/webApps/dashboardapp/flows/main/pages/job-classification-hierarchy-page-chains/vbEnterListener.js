define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_ManageEmployeeHrchy',
        uriParams: {
          'ManageEmployeeHrchy_Id': $variables.currentItemId,
          onlyData: true,
        },
        headers: {
          'REST-Framework-Version': '2',
        },
      }, { id: 'invokeBusinessObjectEmployeeManager' });

      // assign manager ID to variable
      $variables.managerID = response2.body.reportingManager;
    }
  }

  return vbEnterListener;
});
