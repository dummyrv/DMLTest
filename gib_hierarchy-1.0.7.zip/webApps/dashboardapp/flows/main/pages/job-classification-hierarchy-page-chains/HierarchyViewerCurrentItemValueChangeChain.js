define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HierarchyViewerCurrentItemValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.currentItemValue 
     * @param {any} params.detail 
     */
    async run(context, { currentItemValue, detail }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (detail.updatedFrom === 'internal') {
        // assigning current selected card details
        $variables.currentEmployeeManagerVar = currentItemValue;
      }
    }
  }

  return HierarchyViewerCurrentItemValueChangeChain;
});
