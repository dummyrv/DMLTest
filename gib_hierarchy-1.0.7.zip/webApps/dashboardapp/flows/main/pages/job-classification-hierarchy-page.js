define([], () => {
  'use strict';

  class PageModule {

     replaceCurrentHistoryEntry(newChildView) {
      const newState = window.history.state;
      if (newState && newState.vbState && newState.vbState.inputParameters) {
        newState.vbState.inputParameters.childView = newChildView;
      }
  
      window.history.replaceState(newState, '', undefined);
    }

    
  }
  
  return PageModule;
});
