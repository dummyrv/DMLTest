/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['oj-sp/spectra-shell/config/config'], function() {
  'use strict';

  class AppModule {
  }

  return AppModule;
});
