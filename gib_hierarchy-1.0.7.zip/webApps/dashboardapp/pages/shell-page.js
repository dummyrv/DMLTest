/* Copyright (c) 2024, Oracle and/or its affiliates */

define([], () => {
  'use strict';
  
  class PageModule {
  }
    
  return PageModule;
});
  