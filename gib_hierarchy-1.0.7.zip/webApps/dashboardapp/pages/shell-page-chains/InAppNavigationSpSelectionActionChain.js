define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InAppNavigationSpSelectionActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.currentId 
     * @param {string} params.previousId 
     */
    async run(context, { currentId, previousId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      // Navigating to new page
      const navigationToPage = await Actions.navigateToPage(context, {
        page: '/shell/main/'+currentId,
      }, { id: 'navigationToPage' });
    }
  }

  return InAppNavigationSpSelectionActionChain;
});
