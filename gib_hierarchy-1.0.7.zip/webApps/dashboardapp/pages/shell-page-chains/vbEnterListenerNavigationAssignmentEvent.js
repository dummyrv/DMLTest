define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListenerNavigationAssignmentEvent extends ActionChain {

    /**
     * action chain to assign navigation item list to variable
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

    

      $variables.navigationADPVar.data = $variables.navigationArrayVar;
      $variables.selectedId = $application.currentPage.id;
    }
  }

  return vbEnterListenerNavigationAssignmentEvent;
});
