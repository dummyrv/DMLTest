/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define(['ojs/ojarraytreedataprovider'], function (ArrayTreeDataProvider) {
  'use strict';

  var AppModule = function AppModule() { };

  AppModule.prototype.showLoading = function () {
    $('.loading').show();
  };

  AppModule.prototype.hideLoading = function () {
    $('.loading').hide();
  };

   AppModule.prototype.changeLoadingText = function (loadingText) {
    
     var span = document.getElementById("loading-text");
     span.innerText = loadingText;

  };

  AppModule.prototype.extractAssignedProjects = function (arrPrj, arrPrjRoles) {
    

    var strprjs = '';
    var restrictedPrjArr = [];
    var retObj;
    if (arrPrjRoles == undefined || arrPrjRoles == null || arrPrjRoles == "") {
      retObj = { "AssignedProjectString": strprjs, "AssignedProjectArray": restrictedPrjArr };
      return retObj;
    }
    var i;
    for (i = 0; i < arrPrj.length; i++) {
      for (const role of arrPrjRoles) {
        if (arrPrj[i].ProjectRoleName == role.role_name) {
          if (strprjs == '') {
            strprjs = arrPrj[i].ProjectId;
          } else {
            strprjs = strprjs + ',' + arrPrj[i].ProjectId;
          }
          restrictedPrjArr.push(arrPrj[i]);
          break;
        }
      }
    }
    retObj = { "AssignedProjectString": strprjs, "AssignedProjectArray": restrictedPrjArr };
    
    return retObj;
  };

  AppModule.prototype.extractUserRoles = function (array) {
    
 
    var strprjs = '';
    var i;
    for (i = 0; i < array.length; i++) {
      if (i == 0) {
        strprjs = array[i].RoleName;
      } else {
        strprjs = strprjs + ',' + array[i].RoleName;
      }

    }
    
    return strprjs;
  };

  AppModule.prototype.initAssignedProjectsArr = function (array) {
   
    var prjArr = [];
    var i;
    for (i = 0; i < array.length; i++) {
      prjArr[i] = array[i].ProjectId;
    }
    return prjArr;
  };

  AppModule.prototype.initAssignedRolesArr = function (array) {
  
    var rolesArr = [];
    var i;
    for (i = 0; i < array.length; i++) {
      rolesArr[i] = array[i].user_role;
    }
    return rolesArr;
  };

  AppModule.prototype.printObject = function (obj, comments) {
       
   
   
  };


  AppModule.prototype.processProjNumParameter = function (projArr, assignedProjectsArr) {
    if (projArr === undefined || projArr === null || projArr === "") {
    
      projArr = [];
      if (assignedProjectsArr !== undefined && assignedProjectsArr !== null && assignedProjectsArr !== "") {
        for (const project of assignedProjectsArr) {
          projArr.push(project.ProjectNumber);
        }
      }
      //reset for demo purpose only
      projArr = null;
    }
    return projArr;
  };

  AppModule.prototype.initMenuItems = function () {
    var menuArr = [];
    var menuItem1 = {"id":1,"ItemName":"Notifications", "ItemPath":"shell/main/main-notifications","ImagePath":"resources/images/signal-stream.svg"};
    menuArr.push(menuItem1);
    var menuItem2 = {"id":2,"ItemName":"Action List", "ItemPath":"shell/main/main-start","ImagePath":"resources/images/Rocket.svg"};
    menuArr.push(menuItem2);
    var menuItem3 = {"id":3,"ItemName":"Controlling Budget", "ItemPath":"shell/main/main-start","ImagePath":"resources/images/wallet.svg"};
    menuArr.push(menuItem3);
    var menuItem4 = {"id":4,"ItemName":"Forecast Budget", "ItemPath":"shell/main/main-start","ImagePath":""};
    menuArr.push(menuItem4);
    var menuItem5 = {"id":5,"ItemName":"Contract Budget", "ItemPath":"shell/main/main-start","ImagePath":""};
    menuArr.push(menuItem5);

    return menuArr;
  };

  AppModule.prototype.menuFunctionsData = function () {
    var menuDataArr = 
    [
    {
      "function_id": 15,
      "name": "Reports",
      "navigation_path": "shell/main/main-reports",
      "enabled": "Y",
      "image_path": "resources/images/Rocket.svg",
      "parent_function_id": null,
      "parameters": null,
      "children": []
    },
    {
      "function_id": 16,
      "name": "Administration",
      "navigation_path": "shell/main/main-admin",
      "enabled": "Y",
      "image_path": "resources/images/wallet.svg",
      "parent_function_id": null,
      "parameters": null,
      "children": []
    },
    {
      "function_id": 1,
      "name": "Notifications",
      "navigation_path": "shell/main/main-start",
      "enabled": "Y",
      "image_path": "resources/images/signal-stream.svg",
      "parent_function_id": null,
      "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"ALL\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}",
      "children": [
        {
            "function_id": 6,
            "name": "Draft",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"DRAFT\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          },
          {
            "function_id": 7,
            "name": "Submitted",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\r\n  \"status\": \"SUBMITTED\",\r\n  \"searchProjNum\": \"-1\",\r\n  \"budget_type_id\": -1\r\n}"
          },
          {
            "function_id": 8,
            "name": "Approved",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"APPROVED\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          },
          {
            "function_id": 9,
            "name": "Rejected",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"REJECTED\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          },
          {
            "function_id": 10,
            "name": "Posted",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"REJECTED\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          },
          {
            "function_id": 11,
            "name": "PostedError",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"POSTED\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          },
          {
            "function_id": 12,
            "name": "Withdrawn",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 1,
            "parameters": "{ \"search_category\": \"NOTIFICATION\",\n  \"status\": \"POSTEDERROR\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          }
      ]  
    },
    {
      "function_id": 2,
      "name": "Action List",
      "navigation_path": "shell/main/main-start",
      "enabled": "Y",
      "image_path": "resources/images/Rocket.svg",
      "parent_function_id": null,
      "parameters": "{ \"search_category\": \"ACTION\",\n  \"status\": \"ALL\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}",
      "children" : [
        {
            "function_id": 13,
            "name": "Total",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 2,
            "parameters": "{ \"search_category\": \"ACTION\",\n  \"status\": \"ALL\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          },
          {
            "function_id": 14,
            "name": "New",
            "navigation_path": "shell/main/main-start",
            "enabled": "Y",
            "image_path": "resources/images/signal-stream.svg",
            "parent_function_id": 2,
            "parameters": "{ \"search_category\": \"ACTION\",\n  \"status\": \"NEW\",\n  \"searchProjNum\": \"-1\",\n  \"budget_type_id\": -1\n}"
          }
      ]
    },
    {
      "function_id": 3,
      "name": "Controlling Budget",
      "navigation_path": "shell/main/main-start",
      "enabled": "Y",
      "image_path": "resources/images/wallet.svg",
      "parent_function_id": null,
      "parameters": "{\"search_category\": \"-1\",\r\n  \"status\": \"-1\",\r\n  \"searchProjNum\": \"0\",\r\n  \"budget_type_id\": 1\r\n}",
      "children": []
    }
  ];
    var data = {};
    data.data = menuDataArr;
    
    
    return menuDataArr;
  };

  AppModule.prototype.buildTree = function (myarray){
    return new ArrayTreeDataProvider(myarray, { keyAttributes: 'id' , keyAttributesScope : 'siblings' , childrenAttribute : 'children'});
  };

  AppModule.prototype.menuFunctionsList = function (menuADP) {
  
    var menuADPResponse = menuADP;
    var menuFunctionDataArr = menuADPResponse;
    var menuFunctionsTreeDataArr = [];
    var menuFunctionsTreeDataObj = {};
    var children;
    //menuFunctionsTreeDataArr["children"] = [];
    var distinctFunctionIds_parentIds = [];
       
        for(const menuFunctionItem of menuFunctionDataArr) {
          if(menuFunctionItem.parent_function_id === null) {
            menuFunctionsTreeDataArr.push(menuFunctionItem);
            distinctFunctionIds_parentIds.push(menuFunctionItem.function_id);
          }
        
        }
        menuFunctionsTreeDataArr.forEach(menuFunction => { menuFunction['children'] = []; });
       
        for(const menuFunctionItem of menuFunctionDataArr) {
          if(menuFunctionItem.parent_function_id !== null){
            for(const menuFunctionTreeDataItem of menuFunctionsTreeDataArr){
              if(menuFunctionItem.parent_function_id === menuFunctionTreeDataItem.function_id){
                //menuFunctionTreeDataItem.children = [];
                menuFunctionTreeDataItem.children.push(menuFunctionItem);
              
              }
            }
          }
        }
       
    return menuFunctionsTreeDataArr;
  };

  AppModule.prototype.navigationMenuLink = function(navigationMenuItemClicked, navMenuDataArr) {
   
    var linkParameters;
    if(navMenuDataArr !== undefined && navMenuDataArr !== null){
      for(const navMenuDataItem of navMenuDataArr) {
        if(navigationMenuItemClicked === navMenuDataItem.name) {
          linkParameters = JSON.parse(navMenuDataItem.parameters);
        }    
        else if(navigationMenuItemClicked !== navMenuDataItem.name){
          if(navMenuDataItem.children.length !== 0){
            for(const navMenuDataItemChild of navMenuDataItem.children){
              if(navigationMenuItemClicked === navMenuDataItemChild.name){
                linkParameters = JSON.parse(navMenuDataItemChild.parameters);
              }
            }
          }
        }
      }
      
    }
    return linkParameters;
  };
  
  AppModule.prototype.setNotificationList = function(origProjectArr, category){
      var notificationList = [];
      if(origProjectArr !== undefined && origProjectArr !== null && origProjectArr !== ""){
        for(const prj of origProjectArr){
          if(category == "TOTAL"){
            notificationList.push(prj.proj_number);
          }else if(category == "APPROVED"){
            if(prj.status == "Approved" || prj.status == "Posted" || prj.status == "PostedError"){
              notificationList.push(prj.proj_number);
            }
          }else if(category == "REJECTED"){
            if(prj.status == "Rejected"){
              notificationList.push(prj.proj_number);
            }

          }  
        }
      }  
      return notificationList;

  };

  AppModule.prototype.initFYArray = function(){
      var today = new Date();
      var year = today.getFullYear();
      var month = today.getMonth()+1;
      var startFY = year -2000;
      if( month > 6){
        startFY = startFY + 1;
        
      }
      var fyArr = [];
      for(var i=0; i<10; i++){
        var fyobj = {};
        fyobj.fy_value = startFY;
        fyobj.fy_name = "FY" + startFY;
        fyArr.push(fyobj);
        startFY = startFY + 1;
      }

      return fyArr;
    
    };
    
    AppModule.prototype.formatCurrency = function(amount){
      var formattedamt = 0;
     
      if(!isNaN(amount))
      {
        amount = Number.parseFloat(amount).toFixed(2);
        formattedamt = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
     
      return formattedamt;
    
    };

  AppModule.prototype.isFormValid = function (form) {
    var tracker = document.getElementById(form);
    if (tracker.valid === "valid") {
      return true;
    } else {
      tracker.showMessages();
      tracker.focusOn("@firstInvalidShown");
      return false;
    }
  };

  AppModule.prototype.isArraycontainsStr = function (inputArray , inputStr) {

    var inputArray1 = [];

    inputArray1 = inputArray;

   


    if (inputArray1.includes(inputStr))
     
     {
         return true;
     }

     else
      {
          return false;
      }

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  AppModule.prototype.getRetryServiceArray = function (bpresponseArr) {

   


     var formattedArray = [];
     
      if (bpresponseArr != undefined && bpresponseArr !== null && bpresponseArr !== "")
    {
           if(bpresponseArr.length>0)
           {
              bpresponseArr.forEach((item, index5) => {

               

                formattedArray.push(item.fieldValue);


              });
           }  
    }

    return formattedArray;
    

  };

   AppModule.prototype.prepareRetryCount = function (retryCount)
   {
         
    var retryArray = [];

    var retryCount1 = Number(retryCount) + 1;

       for(var i=1;i<=retryCount1;i++)
       {
              retryArray.push(i);
       }

      

       return retryArray;
       

   };

  return AppModule;
});
