/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define(['ojs/ojcore'], function(oj) {
  'use strict';
var eventHelper;
  var timeoutInMiliseconds = 1800000; // Session timeout (ms) 600000 10000
  var timeoutId;
  var globalTimeOutVal;
  var PageModule = function PageModule(context) {
    eventHelper = context.getEventHelper();
  };

  PageModule.prototype.setupSessionHandler = function(timeoutVal) {
    // Set events that reset timer
    document.addEventListener("mousemove", resetTimer);
    document.addEventListener("mousedown", resetTimer);
    document.addEventListener("keypress", resetTimer);
    document.addEventListener("touchmove", resetTimer);
    globalTimeOutVal = timeoutVal;
    startTimer(timeoutVal);
  };
  
  function startTimer(globalTimeOutVal) { 
    globalTimeOutVal = globalTimeOutVal == undefined ? timeoutInMiliseconds:parseInt(globalTimeOutVal);
    timeoutId = setTimeout(doInactive, timeoutInMiliseconds);
  };
  function resetTimer() { 
    clearTimeout(timeoutId);
    startTimer(globalTimeOutVal);
  };
  
  function doInactive() {
    // Execute below actions when session expires
    eventHelper.fireCustomEvent('sessionIdle');
  };
  
  PageModule.prototype.reload = function() {
    location.reload();
  };

  PageModule.prototype.showSide = function() {
    var offcanvas = {
      "selector": "#startDrawer",
      "content": "#mainContent",
      "edge": "start",
      "displayMode": "push",
      "size": "250px"
    };
 
    oj.OffcanvasUtils.open(offcanvas);
 
  };

  PageModule.prototype.processProjNum = function (origText) {
    console.log('===> in processProjNum');
    var text = origText.trim();
    var len = text.indexOf(" ");
    var projnum;
    if (len == 0) {
      projnum = text;
    } else {
      projnum = text.substr(0, len);
    }
    console.log('===> projNum:' + projnum);
    return projnum;
  };

  PageModule.prototype.processSearchPlaceholder = function (currentPageId) {
    //console.log('===> in processSearchPlaceholder');

    var placeholder;
    /*if (currentPageId == 'main-home-page') {
      placeholder = 'Search for Project...';
    } else if (currentPageId == 'main-start') {
      placeholder = 'Enter project number...';
    }else if (currentPageId == 'main-projviastatusreport') {
      placeholder = 'Enter project number...';
    }else if (currentPageId == 'main-report') {
      placeholder = 'Enter project number...';
    }  else {
      placeholder = 'Others....';
    }*/
    placeholder = 'Search for Project...';
    //console.log('===> placeholder:' + placeholder);
    return placeholder;
  };

  PageModule.prototype.pageBackground = function (currentPageId) {
    console.log('===> in pageBackground');

    var pageBackground;
    if (currentPageId == 'main-home-page') {
      // pageBackground = "linear-gradient(black, transparent), center 200%/cover no-repeat url('https://dotvic-development-sdkuzeu06hot-sy.integration.ocp.oraclecloud.com/ic/builder/design/DOT_BFA_APP/1.0/resources/storage/webApps/budgetforecastingapp/resources/images/home-page-bg.svg') transparent !important";
      pageBackground = "lightblue !important";
    } 
    else {
      pageBackground = "#5d5d5d !important";
    }
    console.log('===> pageBackground:' + pageBackground);
    return pageBackground;
  };

  PageModule.prototype.isEnterKey = function (details) {
    //console.info('===> in isEnterKey');
    //console.info('===> details:' + details);

    return true;
  };

  PageModule.prototype.searchKeyPressHandle = function (event) {
    //console.info('===> in searchKeyPressHandle');
    //console.info('===> event:' + event.keyCode);
    if (event.keyCode == 13) {

     if(document.createEvent){
         event = document.createEvent("HTMLEvents");
         event.initEvent("ojAction", true, false);
         event.eventName = "ojAction";
     
         document.getElementById("btnSearch").dispatchEvent(event);
     } else {
       console.log("if false");
         event = document.createEventObject();
         event.eventName = "ojAction";
        // event.eventType = "ojAction";
         document.getElementById("btnSearch").fireEvent("on" + event.eventType, event);
     }
      //const event = new Event('ojAction');
      //document.getElementById("btnSearch").dispatchEvent(event);
    }
    return true;
  }; 

  PageModule.prototype.extractSearchedProjects = function (array) {
    //console.info('===> in extractSearchedProjects');
    console.info('===> array length:' + array.length);
    var projects = [];
    var i;
    for (i = 0; i < array.length; i++) {
      projects[i] = array[i].combination_id;
      
    }
    //console.info("===> projects: " +  JSON.stringify(projects));
    return projects;
    
  };

  PageModule.prototype.printObject = function (obj, comments) {
    if(comments !== undefined){
      console.info('===> ' + comments);
    }
    console.info('===> object: ' + JSON.stringify(obj));
  };
  
  PageModule.prototype.showSearchProjectDialog = function(event) {
    document.getElementById("searchProjectDialog").open();
  };

  PageModule.prototype.hideSearchProjectDialog = function(event) {
    document.getElementById("searchProjectDialog").close();
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.test = function (arg1) {
    alert(arg1);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.showAboutUs = function (arg1) {
    const popup = document.getElementById("aboutPopup");
     if (popup.isOpen()) {
                      popup.close();
                  }
                  else
                  {
                    popup.open("#about");
                  }
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.extractCombinations = function (combList) {
    var str = '';
    console.log("combList",combList);
    for(var i in combList){
      str = str+combList[i]['combination_id'];
      str = str+',';
    }
    console.log("str"+str);
    return str;
  };

  return PageModule;
});
