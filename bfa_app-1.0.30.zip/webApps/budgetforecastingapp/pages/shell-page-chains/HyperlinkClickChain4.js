define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain4 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const toMain = await Actions.navigateToFlow(context, {
        flow: 'main',
        page: 'main-role-mapping',
      });
    }
  }

  return HyperlinkClickChain4;
});
