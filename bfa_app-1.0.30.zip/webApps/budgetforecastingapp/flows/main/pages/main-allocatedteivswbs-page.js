define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getLovData = function (response) {
     var dataArr = {};
    var budgetTypeArr = [];
    var pastBasedPerCodeArr = [];
    var authCodeArr=[];
    var iniCodeArr=[];
    var costCodeArr=[];
    var baseProjArr=[];
    var codeDescObj = {};

    var selBudgetTypeByDefault;
   
    response.forEach(function(item, index) {
          var tempObj = {};
          if(item.segment_name=="AUTHORITY CODE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          authCodeArr.push(tempObj);
          }
           else if(item.segment_name=="INITIATIVE CODE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          iniCodeArr.push(tempObj);
          }
           else if(item.segment_name=="COST CENTRE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          costCodeArr.push(tempObj);
          }
          else if(item.segment_name=="BASE PROJECT"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          baseProjArr.push(tempObj);
          }
          codeDescObj[item.code+item.segment_name.split(" ")[0]] = item.description;
        });
    
        dataArr.authcodeArray=authCodeArr;
       dataArr.initcodeArray=iniCodeArr;
       dataArr.costcodeArray=costCodeArr;
       dataArr.baseProjArray=baseProjArr;
       dataArr.codeDescObj = codeDescObj;
       
     
    
         dataArr.budgetTypeArray=budgetTypeArr;
         return dataArr;
};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getFormattedData = function (response,distinctfy,codeDescObj) {
    if(response.length ==0 || response == undefined){
      $("#noData").show();
    }
    else{
        $("#noData").hide();
    }
    var defaultFys =  [...new Set(distinctfy.map(x => x.fy_name))].sort(); 
    var distinctSubProjects =  [...new Set(response.map(x => x.segment_code10))]; 
    distinctSubProjects.sort(function(a,b){
        return a - b;
      });
    var mainDistinctperiodCodes =  [...new Set(response.map(x => x.period_name))].sort(); 
    
    var subProjectArr = [];
    var curPeriodArrLen;
    var lastPeriodArrLen = 0;
    var periodFYArr = [];
    
    distinctSubProjects.forEach((item,itemIndex)=>{

      var data = response.filter(function(obj){
        return obj.segment_code10.toString() == item.toString();
      });

      var distinctperiodCodes =  [...new Set(data.map(x => x.period_code))]; 
      distinctperiodCodes.sort(function(a,b){
        return a - b;
      });
    
      console.log(item,distinctperiodCodes,data);
      //var obj = {"key":item,"value":data,"periodFY":distinctperiodCodes};
      subProjectArr.push({"key":item,"value":data,
      "periodFY":distinctperiodCodes,
      "init":data[0].segment_code4+" - "+codeDescObj[data[0].segment_code4 + "INITIATIVE"],
      "auth":data[0].segment_code5+" - "+codeDescObj[data[0].segment_code5 + "AUTHORITY"],
      "cost":data[0].segment_code3+" - "+codeDescObj[data[0].segment_code3 + "COST"],
      "proj":data[0].segment_code6+" - "+codeDescObj[data[0].segment_code6 + "BASE"],
      "subproj":data[0].segment_code10,
      "teiAmount":data[0].teiamount,
      "wbsAmount":data[0].wbs_amount,
      "wbsfyamount":data[0].wbsfyamount,
      "version":data[0].version_name,
      "status":data[0].status
      });

      console.log(subProjectArr);

      
    });
    
    if(mainDistinctperiodCodes.length < 6){
      mainDistinctperiodCodes = defaultFys;
    }
      var retData = {};
      retData.reportData = subProjectArr;
      retData.periodFY = mainDistinctperiodCodes;
      return  retData;
  };


  PageModule.prototype.getChildData = function(res,periodArr,subproj){
   var temp = {};
 var tempArray = [];
   periodArr.sort(function(a,b){
     return a - b;
   });

   periodArr.forEach((item,itemIndex)=>{
        var tempObj = res.filter(function(obj){
              return obj.segment_code10 == subproj && obj.period_name == item;
        });
        
        temp[item] = tempObj[0] == undefined ? "0" : tempObj[0].wbsfyamount;
        var amt = tempObj[0] == undefined ? "0" : tempObj[0].wbsfyamount;
        //tempArray.push(amt);

   });
    /*res.forEach((item,itemIndex)=>{
      temp["FY"+item.period_code] = item.wbsfyamount;
    });*/
   
    console.log("temparray",temp);
    var retData = {};
    retData.fydata = tempArray;
    tempArray.push(temp);
    return tempArray;


  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.exportData = function (data,distinctYears,formatCurFn,callbackFn,headerConfigurations) {
    var exportObj = {};
    var exportDataArr = [];
    data.forEach((item,itemIndex)=>{
          exportObj = {};
            exportObj[headerConfigurations.initiative] = item.init;
            exportObj[headerConfigurations.authority] = item.auth;
            exportObj[headerConfigurations.costCenter] = item.cost;
            exportObj[headerConfigurations.projectNumber] = item.proj;
            exportObj[headerConfigurations.subProjectNumber] = item.key+"\t";
              exportObj[headerConfigurations.teiAmount] = formatCurFn(item.teiAmount);
              exportObj[headerConfigurations.wbsAmount] = formatCurFn(item.wbsAmount);
              exportObj[headerConfigurations.version] = item.version;
              exportObj[headerConfigurations.status] = item.status;
            var subProject = item.key;
            var retData = callbackFn(item.value,distinctYears,item.key);
            if(retData.length>0){
                distinctYears.forEach((fyYear,fyYearIndex)=>{
                      exportObj[fyYear] = formatCurFn(retData[0][fyYear]);
                });
            }
        exportDataArr.push(exportObj);
    });
    

    return exportDataArr;
  };


  return PageModule;
});
