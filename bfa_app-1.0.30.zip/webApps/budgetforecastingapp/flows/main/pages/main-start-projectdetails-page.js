define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojbootstrap', 'ojs/ojmodel',
  'ojs/ojcube',
  'ojs/ojconverter-number', 'ojs/ojknockouttemplateutils',
  'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider',
  'ojs/ojhtmlutils','ojs/ojdatacollection-utils',
  'ojs/ojdatagrid', 'ojs/ojknockout', 'ojs/ojtable', 'ojs/ojrowexpander','ojs/ojinputtext'],
  function(oj, ko, $, Bootstrap, Model, Cube, NumberConverter,
  KnockoutTemplateUtils, FlattenedTreeDataProviderView,
  ArrayTreeDataProvider, HtmlUtils, DataCollectionEditUtils) {
    'use strict';

    var PageModule = function PageModule() {
      var self = this;
      this.KnockoutTemplateUtils = KnockoutTemplateUtils;
      var cube = null;
      var dataArr = null;
      var rowDataObj = {};
      var ProjTableADP = [];
      var totalYearValidation = [];
      var subprojList = [];
      var baseProject;
      var controllingBudgetVal;
      var allocatedTEIbudget;
      var editMode = true;
      var readonlymode = false;
      var periodYear = [];
      var today = new Date();
      var graph1 = 'TEI Budget';
      var graph2 = 'Approved Budget';
      var graph3 = 'Variance';
      var statusVal = 'Notphased';
      var changeAlertVal = false;
      dataArr = [{
          "budgetPeriod" : 'FY2021',
          "amount" : 100000,
          "budgetBreakdown" : 0,
          "project" : '200047.02',
          "startdate" : '1-Jan-2021',
          "enddate" : '1-Jan-2024',
      },
      {
          "budgetPeriod" : 'FY2022',
          "amount" : 200000,
          "budgetBreakdown" : 0,
          "project" : '200047.02',
          "startdate" : '1-Jan-2021',
          "enddate" : '1-Jan-2024',
      },{
          "budgetPeriod" : 'FY2023',
          "amount" : 300000,
          "budgetBreakdown" : 0,
          "project" : '200047.02',
          "startdate" : '1-Jan-2021',
          "enddate" : '1-Jan-2024',
      },{
          "budgetPeriod" : 'FY2021',
          "amount" : 100000,
          "budgetBreakdown" : 0,
          "project" : '200047.03',
          "startdate" : '1-Jan-2021',
          "enddate" : '1-Jan-2024',
      }];
      
      function generateCube(dataArr, axes) {
      return new Cube.DataValueAttributeCube(dataArr, axes,
         [{
            attribute: 'budgetBreakdown',
            label: 'Amount'
          }
        ]);
      }  
      var axes = [{
          axis: 0,
          levels: [{
            attribute: 'budgetPeriod'
          },{
            attribute: 'amount'
          },{
            attribute: 'cap_amount'
          },
          {
            attribute: 'op_amount'
          },
          {
            attribute: 'columnTotal'
          },
          {
            dataValue: true
          }
          ]
        },
        { axis: 1,
            levels: [
                  { attribute: 'project' },
                  { attribute: 'proj_type' },
                  { attribute: 'startenddate' },
                  { attribute: 'subProjTotal' },
                  { attribute: 'status' }] }
      ];
      
      function MyDataGridDataSource(data, options)
     {
       
         MyDataGridDataSource.superclass.constructor.call(this, data, options);
     }
     oj.Object.createSubclass(MyDataGridDataSource, oj.CubeDataGridDataSource, "oj.MyDataGridDataSource");
     MyDataGridDataSource.prototype.fetchHeaders = function(headerRange, callbacks, callbackObjects)
     {
         var callback = function(headerSet, headerRange) {          
            headerSet.getLabel = function(level){
              if(headerRange.axis == "column"){
                  if(level == 0)
                  return '';
                  else if(level == 1)
                  return 'EPM Budget';
                  else if(level == 2)
                  return 'EPM CAPEX';
                  else if(level == 3)
                  return 'EPM OPEX';
                  else if(level == 4)
                  return 'PFM Budget';
                  else if(level == 5)
                  return '';
              }

             if (headerRange.axis == "row"){
              if(level == 0)
              return 'PFM Project';
              else if(level == 1)
              return 'Project Type';
              else if(level == 2)
              return 'Date';
              else if(level == 3)
              return 'Total';
              else if(level == 4)
              return 'Status';
              else 
              return '';
            }

            return '';
            };
            callbacks.success.call(this, headerSet, headerRange);
         }
         MyDataGridDataSource.superclass.fetchHeaders.call(this, headerRange, {success: callback}, callbackObjects);
     };
      
      PageModule.prototype.formatProjBaseDataGrid = function(response) {
       // // console.log(response);
        return ;
      };
      
      this.launchedFromCell = ko.observable('None launched yet');
    
      PageModule.prototype.myActionFunction = function (event) {
//         // console.log(rowDataObj);
      //console.info("===> rowDataObj: " + JSON.stringify(rowDataObj));
        return rowDataObj;
      };
      
      PageModule.prototype.menuBeforeOpenAction = function(event) {
        var projectDet = [];
        var rowHeaders = [];
        var target = event.detail.originalEvent.target;
          var context = document.getElementById('projDetdatagrid').getContextByNode(target);
          if (context != null) {
            var rowData = context.datasource.data._rows;
            //console.info("===> rowData: " + JSON.stringify(rowData));
            if (context.indexes != null) {
              this.launchedFromCell(context.indexes.row + ',' + context.indexes.column);
            } else if (context.index != null) {
              this.launchedFromCell(context.axis + ' header index ' + context.index);
            } 
            if (context.axis == 'column' || (context.axis == 'row' && context.subId == 'oj-datagrid-header-label')) {
              rowDataObj.status = 'Not Phased';
            } else {
            rowHeaders = JSON.parse(context.key); 
            //console.info("===> context.data: " + JSON.stringify(rowData[context.index]));
            //rowDataObj.project = rowData[context.index]['subproject'];
            //rowDataObj.projectName = rowData[context.index]['project'];
            rowDataObj.project = rowHeaders.project.split('-')[0].trim();
            rowDataObj.projectName = rowHeaders.project;
            var RowDataArr = rowData.filter(it => (it.subproject === rowDataObj.project));
            var RowTEIDataArr = rowData.filter(it => (it.subproject === rowDataObj.project) && (it.budgetPeriod === 'TEI'));
            rowDataObj.startDateDisplay = RowDataArr.length ? RowDataArr[0].startdate : 0;
            rowDataObj.endDateDisplay = RowDataArr.length ? RowDataArr[0].enddate : 0;
            var projArr = ProjTableADP.filter(it => (it.proj_number === rowDataObj.project))
            rowDataObj.startdate = projArr.length ? projArr[0].startdate : 0;
            rowDataObj.enddate = projArr.length ? projArr[0].enddate : 0;
            rowDataObj.status = RowDataArr.length ? RowDataArr[0].status : '-';
            rowDataObj.projectDet = rowData.filter(it => (it.project.split('-')[0].trim() === rowDataObj.project));
            rowDataObj.tei = RowTEIDataArr.length ? RowTEIDataArr[0].budgetBreakdown : 0;
            }
          }
          return rowDataObj;
      };
      
      PageModule.prototype.getRowHeaderStyleName = function(cellContext) {
        var cellClassName;
        var row = JSON.parse(cellContext.key);
        if (cellContext.level === 0) {
             cellClassName = 'width:150px;font-size:0.857rem;background-color: lightgrey;height:50px;';
        } else {
             cellClassName = 'width:100px;font-size:0.857rem;height:50px;background-color: #efefef'; 
        }
        return cellClassName;
    };
    
    PageModule.prototype.getColHeaderStyleName = function(cellContext) {
        // console.log("++cell context",cellContext);
        // console.log("--valid flag",totalYearValidation);
        var cellClassName;
        
        if (totalYearValidation.length) {
            var col = JSON.parse(cellContext.key);
            var periodIndex = totalYearValidation.findIndex(x => (x.period === col.budgetPeriod));
            if (cellContext.level === 1 ) {
              if (totalYearValidation[periodIndex]['IsValidFlag'] === false) {
                cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #E82C0C;color: white;';
              } else {
                cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #208039;color: white;';
              }
            } 
            else if(cellContext.level === 2)
            {
              if (totalYearValidation[periodIndex]['IsCapValidFlag'] === false) {
                cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #E82C0C;color: white;';
              } else {
                cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #208039;color: white;';
              }
            }
            else if(cellContext.level === 3)
            {
              if (totalYearValidation[periodIndex]['IsOpValidFlag'] === false) {
                cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #E82C0C;color: white;';
              } else {
                cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #208039;color: white;';
              }
            }
            else {
              cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #303030;color: white;';
            }
        } else {
              cellClassName = 'width:150px;font-weight:bold;font-size:0.857rem;background-color: #303030;color: white;';
        }
        return cellClassName ;
    };
      
      PageModule.prototype.getCellClassName = function(cellContext) {
//         // console.log(cellContext);
        var cellClassName;
        var updatedCol = JSON.parse(cellContext.keys.column);
        var updatedRow = JSON.parse(cellContext.keys.row);
        var dateVal = updatedRow.startenddate.split(' ');
        var startDt = new Date(dateVal[0]);
        var endDt = new Date(dateVal[1]);
        if (updatedCol.budgetPeriod == 'TEI') {
          var t1 = (today.getMonth()+1) + '-' + today.getDate() + '-' + today.getFullYear();
          var t2 = (endDt.getMonth()+1) + '-' + endDt.getDate() + '-' + endDt.getFullYear();
          // if ((new Date(t1) <= new Date(t2)) && (editMode === true)) {
          if (editMode === true) {
            cellClassName = 'oj-helper-justify-content-right';
          } else {
            cellClassName = 'oj-helper-justify-content-right oj-read-only';
          }
        } else {
          var year = periodYear[periodYear.findIndex(x => x.periodkey ===
          updatedCol.budgetPeriod)].periodVal;
          // var startDtYr = dateVal[0] ? dateVal[0].split('-')[2] : '';
          // var endDtYr = dateVal[1] ? dateVal[1].split('-')[2] : '';
          var startDtYr = startDt.getMonth() >= 6 ? startDt.getFullYear() +1 : startDt.getFullYear();
          var endDtYr = endDt.getMonth() >= 6 ? endDt.getFullYear() +1 : endDt.getFullYear();       
          if ((startDtYr && year < startDtYr || endDtYr && year > endDtYr) || (readonlymode === true && editMode === false)) {
            cellClassName = 'oj-helper-justify-content-right  oj-read-only';
          } else {
          cellClassName = 'oj-helper-justify-content-right';
          }
        }
        return cellClassName;
      };

      PageModule.prototype.getCellTemplate = function(cellContext) {
          var mode;
          var updatedCol = JSON.parse(cellContext.keys.column);
          var updatedRow = JSON.parse(cellContext.keys.row);
          var dateVal = updatedRow.startenddate.split(' ');
          var startDt = new Date(dateVal[0]);
          var endDt = new Date(dateVal[1]);
          if (updatedCol.budgetPeriod === 'TEI') {
            var t1 = (today.getMonth()+1) + '-' + today.getDate() + '-' + today.getFullYear();
            var t2 = (endDt.getMonth()+1)  + '-' + endDt.getDate()+ '-' + endDt.getFullYear();
            // if ((new Date(t1) <= new Date(t2)) && (editMode === true)) {
            if (editMode === true) {
              return KnockoutTemplateUtils.getRenderer('editCellTemplate')(cellContext);
            } else {
              return KnockoutTemplateUtils.getRenderer('cellTemplate')(cellContext);
            }
          } else {
            var year = periodYear[periodYear.findIndex(x => x.periodkey ===
            updatedCol.budgetPeriod)].periodVal;
            var startDtYr = startDt.getMonth() >= 6 ? startDt.getFullYear() +1 : startDt.getFullYear();
            var endDtYr = endDt.getMonth() >= 6 ? endDt.getFullYear() +1 : endDt.getFullYear();
            
            if ((startDtYr && year < startDtYr || endDtYr && year > endDtYr) || (readonlymode === true && editMode === false) || (year < today.getFullYear())) {
              mode = 'navigation';
            } else {
              mode = 'edit';
            }
            // mode = cellContext.mode;
            if (mode === 'edit') {
              return KnockoutTemplateUtils.getRenderer('editCellTemplate')(cellContext);
            } else if (mode === 'navigation') {
              return KnockoutTemplateUtils.getRenderer('cellTemplate')(cellContext);
            }
          }
          return '';
      };
      
      //Function to prepare data grid data
      PageModule.prototype.getProjDetDataGrid = function(projDetdata, projAmountDet, baseProjNum, authCode, projVersionData, PeriodList, subProjectList,
      readonlyflag, editflag, newFYadp,fyADPdata,budgetTypeList,capexOpexTotals) {
        // console.log('Fuc test');
        // console.log(capexOpexTotals);
        // console.log(projDetdata); //empty init
        // console.log(projAmountDet); //EPM totals by FY list
        // console.log(baseProjNum);
        // console.log(authCode);
        // console.log(projVersionData);//empty
        // console.log(PeriodList);//empty
        // console.log(subProjectList); //list
        // console.log(readonlyflag);
        // console.log(editflag);
        // console.log(newFYadp);
        // console.log(fyADPdata);
        // console.log(budgetTypeList);
        var foramttedArr = [];
        var controllingTotalArr = [];
        var totalTEIArr = [];
        var totalVal = 0;
        var changeStatus;
        var invalidAllocation;
        var totalTEIbudget = 0;
        editMode = editflag;
        readonlymode = readonlyflag;
        ProjTableADP = projDetdata;
        if(newFYadp.length ==0){
          newFYadp = fyADPdata;
        }
        newFYadp.forEach((itemFY, index) => {
          var fyObj ={};
          fyObj.periodkey = itemFY.fy_name;
          var year = itemFY.fy_value + 2000;
          fyObj.periodVal = year.toString();
          periodYear.push(fyObj);
        });
        var budgetData;
        subprojList = subProjectList;
        changeStatus = subProjectList.findIndex(x => (x.change_status === 'Alert'));
        invalidAllocation = subProjectList.findIndex(x => (x.valid_budget_flag === 'N'));
        var distinctPeriod= [...new Set(subProjectList.map(x => x.period_name))];
        distinctPeriod.sort();
        distinctPeriod.splice(0, 0, "TEI");
       // // console.log("distinct period",distinctPeriod,subProjectList);
        // var distinctPeriod = ['FY21','FY22','FY23','FY24','FY25','FY26','FY27'];
        //// console.log("projamtdet",projAmountDet);
        var temp = projAmountDet.filter(x => (x.budget_type_name == budgetTypeList[Object.keys(budgetTypeList)[0]]));
        //// console.log("temp",temp);
        var controllingBudgetAmountDet = temp.filter(o => distinctPeriod.indexOf(o.year) > -1);
        //// console.log("**** filtered projAmountDet:" +JSON.stringify(controllingBudgetAmountDet));
        controllingBudgetVal  = controllingBudgetAmountDet.reduce(function(prev, cur) {
                return prev + cur.proj_amount;
              }, 0);
        // console.log("cb val:", controllingBudgetVal);
        var subProjList = [...new Set(subProjectList.map(x => x.subproject_code))]; 
        subProjList.forEach((item, index) => {
            var status= false;
            var subProjDetIndex = subProjectList.findIndex(x => (x.subproject_code === item));
            var subProjFilteredLst = subProjectList.filter(it => (it.subproject_code === item));
            var statusLst = [...new Set(subProjFilteredLst.map(x => x.status))];
            statusLst.forEach((statusItm, index) => {
                if (statusItm === 'Phased') {
                    status = true;
                    statusVal = 'Phased';
                }
            });
            distinctPeriod.forEach((item1, index) => {
              if (item1 === 'TEI') {
                var budgetIDindex = projAmountDet.findIndex(x =>(x.budget_type_id === '4'));
                var budgetVersionIndex = subProjectList.findIndex(x => (x.subproject_code === item) && (x.budget_type_id === 4));
                var obj = {};
                obj["budgetPeriod"] = item1;
                obj["amount"] = budgetIDindex >= 0 ?  projAmountDet[budgetIDindex]['proj_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : 0;
                obj["cap_amount"] = budgetIDindex >= 0 ?  projAmountDet[budgetIDindex]['proj_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : 0;
                obj["op_amount"] = budgetIDindex >= 0 ?  projAmountDet[budgetIDindex]['proj_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : 0;
                obj["budgetBreakdown"] = budgetVersionIndex >= 0 ? Number(Number(subProjectList[budgetVersionIndex]['amount']).toFixed(2)) : 0;
                obj["project"] = subProjectList[subProjDetIndex]['subproject_code'] + ' - ' + subProjectList[subProjDetIndex]['subproject'];
                obj["subproject"] = subProjectList[subProjDetIndex]['subproject_code'];
                obj["subproject"] = subProjectList[subProjDetIndex]['subproject_code'];
                obj["proj_type"] = subProjectList[subProjDetIndex]['proj_type'];
                obj["startdate"] = subProjectList[subProjDetIndex]['project_startdate']? subProjectList[subProjDetIndex]['project_startdate'] : '';
                obj["enddate"] = subProjectList[subProjDetIndex]['project_enddate'] ? subProjectList[subProjDetIndex]['project_enddate'] : '';
                obj["startenddate"] = obj["startdate"] + ' ' + obj["enddate"];
                obj["columnTotal"] = 0;
                obj["subProjTotal"] = 0;
                obj["combinationID"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['combination_id'] : -1;
                obj["allocationID"] = -1;
                obj["periodCode"] = item1;
                obj["status"] = status ? 'Phased' : 'Not Phased';
                obj["external_batch_number"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['external_batch_number'] : -1;
                obj["parent_batch_number"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['parent_batch_number'] : -1;
                obj["new_batch_number"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['new_batch_number'] : -1;
                obj["allocation_batch_number"] = -1;
                obj["comments"] = '';
                obj["version_name"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['version_name'] : '';
                obj["parent_version_name"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['parent_version_name'] : '';
                obj["budget_type_id"] = 4;
                obj["year"] = budgetIDindex >=0 ? projAmountDet[budgetIDindex]['year'] : distinctPeriod[1];
                allocatedTEIbudget = budgetIDindex >= 0 ? Number(projAmountDet[budgetIDindex]['proj_amount'].toFixed(2)) : 0;
                totalTEIbudget = totalTEIbudget + obj["budgetBreakdown"];
                foramttedArr.push(obj);                
              } else {
                var budgetIDindex = projAmountDet.findIndex(x =>(x.year === item1) && (x.budget_type_id === '1'));
                var budgetVersionIndex = subProjectList.findIndex(x => (x.subproject_code === item) && (x.period_name === item1) && (x.budget_type_id === 1));
                var capIndex = capexOpexTotals.findIndex(x=>(x.period_name == item1) && (x.account_type == 'CAPEX'));
                var opIndex = capexOpexTotals.findIndex(x=>(x.period_name == item1) && (x.account_type == 'OPEX'));
                var obj = {};
                obj["budgetPeriod"] = item1;
                obj["amount"] = budgetIDindex >= 0 ?  projAmountDet[budgetIDindex]['proj_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                obj["cap_amount"] = capIndex >= 0 ?  capexOpexTotals[capIndex]['total'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                obj["op_amount"] = opIndex >= 0 ?  capexOpexTotals[opIndex]['total'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                obj["budgetBreakdown"] = budgetVersionIndex >= 0 ? Number(Number(subProjectList[budgetVersionIndex]['amount']).toFixed(2)) : 0;
                obj["project"] = subProjectList[subProjDetIndex]['subproject_code'] + ' - ' + subProjectList[subProjDetIndex]['subproject'];
                obj["subproject"] = subProjectList[subProjDetIndex]['subproject_code'];
                obj["proj_type"] = subProjectList[subProjDetIndex]['proj_type'];
                obj["startdate"] = subProjectList[subProjDetIndex]['project_startdate']? subProjectList[subProjDetIndex]['project_startdate'] : '';
                obj["enddate"] = subProjectList[subProjDetIndex]['project_enddate'] ? subProjectList[subProjDetIndex]['project_enddate'] : '';
                obj["startenddate"] = obj["startdate"] + ' ' + obj["enddate"];
                obj["columnTotal"] = 0;
                obj["subProjTotal"] = 0;
                obj["combinationID"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['combination_id'] : -1;
                obj["allocationID"] = budgetVersionIndex >= 0 ?subProjectList[budgetVersionIndex]['allocation_id'] : -1;
                obj["periodCode"] = item1;
                obj["status"] = status ? 'Phased' : 'Not Phased';
                obj["external_batch_number"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['external_batch_number'] : -1;
                obj["parent_batch_number"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['parent_batch_number'] : -1;
                obj["new_batch_number"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['new_batch_number'] : -1;
                obj["allocation_batch_number"] = budgetVersionIndex >= 0 ?subProjectList[budgetVersionIndex]['allocation_batch_number'] : -1;
                obj["comments"] = budgetVersionIndex >= 0 ?subProjectList[budgetVersionIndex]['comments'] : '';
                obj["version_name"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['version_name'] : '';
                obj["parent_version_name"] = subProjDetIndex >= 0 ?subProjectList[subProjDetIndex]['parent_version_name'] : '';
                obj["budget_type_id"] = 1;
                //obj["year"] = budgetIDindex >=0 ? projAmountDet[budgetIDindex]['year']:distinctPeriod[1];
                obj["year"] = item1;
                totalVal = totalVal + obj["budgetBreakdown"];
                foramttedArr.push(obj);
              }
            });
        });
        foramttedArr.forEach((item1, index) => {
        var budgetPeriodbased= foramttedArr.filter(it => (it.budgetPeriod === item1.budgetPeriod));
        var colTotal = budgetPeriodbased.reduce(function(prev, cur) {
           return prev + cur.budgetBreakdown;
         }, 0);
         var budgetRowbased= foramttedArr.filter(it => (it.project === item1.project) && (it.budget_type_id === 1));
        var rowTotal = budgetRowbased.reduce(function(prev, cur) {
           return prev + cur.budgetBreakdown;
         }, 0);
         foramttedArr[index]['columnTotal'] = colTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
         foramttedArr[index]['subProjTotal'] = rowTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
       });

       // console.log("formattedArr:",foramttedArr );

        //Controlling budget graph
        var objVal = {};
        objVal["id"] = 0;
        objVal["series"] = 'Total EPM Budget';
        objVal["value"] = subProjectList.length > 0?controllingBudgetVal : 0;
        objVal["group"] = graph2;
        controllingTotalArr.push(objVal);
        var objVal2 = {};
        objVal2["id"] = 1;
        objVal2["series"] = 'Total PFM Budget';
        objVal2["value"] = totalVal;
        objVal2["group"] = graph2;
        controllingTotalArr.push(objVal2);

        //TEI graph
        var objVal3 = {};
        objVal3["id"] = 0;
        objVal3["series"] = 'Total TEI Budget';
        objVal3["value"] = allocatedTEIbudget;
        objVal3["group"] = graph1;
        totalTEIArr.push(objVal3);
        var objVal4 = {};
        objVal4["id"] = 1;
        objVal4["series"] = 'Total TEI Allocated Budget';
        objVal4["value"] = totalTEIbudget;
        objVal4["group"] = graph1;
        totalTEIArr.push(objVal4);

        //Variance value showing the difference between controllingBudgetVal and totalVal
        var objVal5 = {};
        objVal5["id"] = 0;
        objVal5["series"] = 'Variance Value';
        objVal5["value"] = controllingBudgetVal - totalVal;
        objVal5["group"] = graph3;
        controllingTotalArr.push(objVal5);

        console.info("===> grid data: " + JSON.stringify(foramttedArr));
        cube = generateCube(foramttedArr, axes);

        var data = {}; 
        budgetData = foramttedArr.length? new MyDataGridDataSource(cube) : '';  
        data.budgetData = budgetData;
        data.controllingTotalArr = controllingTotalArr; 
        data.totalTEIArr = totalTEIArr; 
        data.changeStatus = changeStatus === -1 ? '' :  subProjectList[changeStatus]['change_status'];   
        changeAlertVal = changeStatus === -1 ? false : true;
        data.invalidAllocation = invalidAllocation === -1 ? 'N': 'Y';

        //console.info("===> final data: " );  
        //console.info(data );  

        // console.log("Test budget data", data);
        
        return data;
      };

      PageModule.prototype.formatProjWBSData = function(response,
        projCustomData, projBaseData) {
       // // console.log(projCustomData);
        var resultArr = [];
        var month = new Array();
        month[0] = "Jan";
        month[1] = "Feb";
        month[2] = "Mar";
        month[3] = "Apr";
        month[4] = "May";
        month[5] = "Jun";
        month[6] = "Jul";
        month[7] = "Aug";
        month[8] = "Sept";
        month[9] = "Oct";
        month[10] = "Nov";
        month[11] = "Dec";
        projCustomData.forEach((item, index) => {
          var tempObj = {};
//           var baseprojarr = item.proj_number.split('.');
          var projIndex = projCustomData.findIndex(x => x
            .proj_number === item.proj_number);
          if (projIndex >= 0) {
            var d1 = projCustomData[projIndex].startdate ? new Date(
              projCustomData[projIndex].startdate) : null;
            var d2 = projCustomData[projIndex].enddate ? new Date(
              projCustomData[projIndex].enddate) : null;
            tempObj.startdate = d1 ? (d1.getMonth() + 1) + '-' + d1
              .getDate() + '-' + d1.getFullYear() : null;
            tempObj.enddate = d2 ? (d2.getMonth() + 1) + '-' + d2
              .getDate() + '-' + d2.getFullYear() : null;
            tempObj.startDateDisplay = d1 ? d1.getDate() + '-' +
              month[(d1.getMonth())] + '-' + d1.getFullYear() : null;
            tempObj.endDateDisplay = d2 ? d2.getDate() + month[(d2
              .getMonth())] + '-' + d2.getFullYear() : null;
          }
          tempObj.SlNo = index;
          tempObj.proj_number = item.proj_number;
          tempObj.proj_name = item.proj_name;
//           tempObj.base_proj_number = baseprojarr[0];
          resultArr.push(tempObj);
        });
//         var finalResArr = resultArr.filter(it => it.base_proj_number === projBaseData);
        return resultArr;
      };

      PageModule.prototype.formatProjCustomData = function(response) {
        //// console.log(response);
        var resultArr = [];
        response.forEach(function(item, index) {
          var tempObj = {};
          tempObj.SlNo = index;
          tempObj.proj_number = item.proj_number;
          tempObj.startdate = item.proj_st_dt;
          tempObj.enddate = item.proj_end_dt;
          tempObj.proj_name = item.proj_name;
          resultArr.push(tempObj);
        });
        return resultArr;
      };
      
      //Function to save the allocated PFM budget data
      PageModule.prototype.saveProjVersionData = function(response, originalData, projNum, initiativeCode, authCode, costcenter, username, capOpTotals,capFlag,opFlag) {
          // console.log("++new data: ",response);
          // console.log("++old data: ",originalData);
          // console.log("++cap op flag",capFlag,opFlag);
          var payload = {};
          var budgetArr = [];
          var count = 0;
          var inactiveFYcount = 0;
          var periodInvalidCount = 0;
          var dataChange = false;
          totalYearValidation = [];
          var cbtotal = originalData.filter(it => (it.amount == 0));
          var isCBTotalNull = cbtotal.length == originalData.length ? true : false;
          if (response) {
          var updatedBudgetArr = response.data._rows;
           var allocatedTotal = updatedBudgetArr.filter(it => (it.budgetBreakdown == 0));
           var isallocatedTotalNull = allocatedTotal.length == updatedBudgetArr.length ? true : false;
          var distinctPeriods = [...new Set(updatedBudgetArr.map(x => x.budgetPeriod))];

          const escapeRegExpMatch = function(s) {
              return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
          };
          const isExactMatch = (str, match) => {
            return new RegExp(`\\b${escapeRegExpMatch(match)}\\b`).test(str);
          }

          distinctPeriods.forEach((itm, index) => {
              var editablecount = 0;
              var isEditable = false;
              var budgetForYear = updatedBudgetArr.filter(it => (it.budgetPeriod === itm))
              var capForYear = updatedBudgetArr.filter(it => (it.budgetPeriod === itm && isExactMatch(it.proj_type,'Capital')))
              var opForYear = updatedBudgetArr.filter(it => (it.budgetPeriod === itm && (isExactMatch(it.proj_type,'Operating') || (isExactMatch(it.proj_type,'Billable')))));
              // console.log("cap op totals",itm,capForYear,opForYear);
              var budgetTotal = budgetForYear.reduce(function(prev, cur) {
                return prev + cur.budgetBreakdown;
              }, 0);
              var capTotal = capForYear[0]?capForYear.reduce(function(prev, cur) {
                return prev + cur.budgetBreakdown;
              }, 0):0;
              var opTotal = opForYear[0]?opForYear.reduce(function(prev, cur) {
                return prev + cur.budgetBreakdown;
              }, 0):0;
              // console.log(capTotal);
              // console.log(opTotal);
              budgetForYear.forEach((dataItm, index) => {
                  var startDt = new Date(dataItm.startdate);
                  var endDt = new Date(dataItm.enddate);
                  var startYr =  startDt.getMonth() >= 7? startDt.getFullYear() +1 :startDt.getFullYear();
                  var endYr = endDt.getMonth() >= 7 ? endDt.getFullYear() + 1: endDt.getFullYear();
                  if (dataItm.budgetPeriod !== 'TEI') {
                    var periodYr = periodYear[periodYear.findIndex(x => x.periodkey === dataItm.budgetPeriod)].periodVal;
                    if ((startDt && periodYr >= startYr || dataItm.startdate == '' || dataItm.startdate == null || dataItm.startdate == undefined) 
                    && (endDt && periodYr <= endYr || dataItm.enddate == '' || dataItm.enddate == null || dataItm.enddate == undefined) && (periodYr >= today.getFullYear())) {
                      isEditable = true;
                      editablecount = editablecount +1;
                    } else {
                      if (dataItm.amount != 0) {
                        inactiveFYcount = inactiveFYcount + 1;
                      }
                    }
                  } else {
                    isEditable = true;
                  }
              });
              if (editablecount <= 0 && budgetForYear[0].amount != 0 && itm != 'TEI') {
                periodInvalidCount = periodInvalidCount + 1;
              }

              var tempObj = {};
              tempObj.period = itm;
              if (isEditable) {
                var controllingBudget = budgetForYear[0].amount !== 0 ? Number(budgetForYear[0].amount.replace(/\,/g,'')) : 0;
                var controllingCap = capForYear[0]?(capForYear[0].cap_amount !== 0 ? Number(capForYear[0].cap_amount.replace(/\,/g,'')) : 0):0;
                var controllingOp = opForYear[0]?(opForYear[0].op_amount !== 0 ? Number(opForYear[0].op_amount.replace(/\,/g,'')) : 0):0;
                // console.log('++ ',controllingCap,' ',controllingOp,' ',Number(capTotal.toFixed(2)),' ',Number(opTotal.toFixed(2)));
                tempObj.IsValidFlag = controllingBudget === Number(budgetTotal.toFixed(2)) ? true : false;
                tempObj.IsCapValidFlag = controllingCap === Number(capTotal.toFixed(2)) ? true : false;
                tempObj.IsOpValidFlag = controllingOp === Number(opTotal.toFixed(2)) ? true : false;

                if(tempObj.IsCapValidFlag == false){
                  capFlag = true;
                }
                if(tempObj.IsOpValidFlag == false){
                  opFlag = true;
                }
              } else {
                
                tempObj.IsValidFlag = true;
                tempObj.IsCapValidFlag = true;
                tempObj.IsOpValidFlag = true;
              }
              if(itm == 'TEI'){
                tempObj.IsValidFlag = true;
                tempObj.IsCapValidFlag = true;
                tempObj.IsOpValidFlag = true;
              }
              count = tempObj.IsValidFlag ? count : count+1;
              count = tempObj.IsCapValidFlag ? count : count+1;
              count = tempObj.IsOpValidFlag ? count : count+1;
              totalYearValidation.push(tempObj);
          });
          document.getElementById("projDetdatagrid").refresh();
           if ((statusVal == 'Notphased' && isallocatedTotalNull && isCBTotalNull) || (changeAlertVal)) { 
            updatedBudgetArr.forEach((itm, index) => {
                  dataChange = true;
                  var tempObj = {};
                  tempObj.combinationID = itm.combinationID;
                  tempObj.allocationID = itm.allocationID;
                  tempObj.budget_amount = itm.budgetBreakdown;
                  tempObj.periodCode = itm.year;
                  tempObj.comments = itm.comments;
                  tempObj.parentBatchNum = itm.parent_batch_number;
                  tempObj.allocationBatchNum = itm.allocation_batch_number;
                  tempObj.externalBatchNum = itm.external_batch_number;
                  tempObj.createdBy = 1;
                  tempObj.transactionType = 'B';
                  tempObj.newBatchNum = itm.new_batch_number;
                  tempObj.versionName = itm.version_name;
                  tempObj.parentVersionName = itm.parent_version_name;
                  tempObj.subProj = itm.subproject;
                  tempObj.budgetTypeID = itm.budget_type_id;
                  budgetArr.push(tempObj);
            });
          } else {
            updatedBudgetArr.forEach((itm, index) => {
              var orignalArr = originalData[index];
                if (itm.budgetBreakdown !== orignalArr.budgetBreakdown) {
                      dataChange = true;
                      var tempObj = {};
                      tempObj.combinationID = itm.combinationID;
                      tempObj.allocationID = itm.allocationID;
                      tempObj.budget_amount = itm.budgetBreakdown;
                      tempObj.periodCode = itm.year;
                      tempObj.comments = itm.comments;
                      tempObj.parentBatchNum = itm.parent_batch_number;
                      tempObj.allocationBatchNum = itm.allocation_batch_number;
                      tempObj.externalBatchNum = itm.external_batch_number;
                      tempObj.createdBy = 1;
                      tempObj.transactionType = 'B';
                      tempObj.newBatchNum = itm.new_batch_number;
                      tempObj.versionName = itm.version_name;
                      tempObj.parentVersionName = itm.parent_version_name;
                      tempObj.subProj = itm.subproject;
                      tempObj.budgetTypeID = itm.budget_type_id;
                      budgetArr.push(tempObj);
                  } else {
                      var tempObj = {};
                      tempObj.combinationID = itm.combinationID;
                      tempObj.allocationID = itm.allocationID;
                      tempObj.budget_amount = itm.budgetBreakdown;
                      tempObj.periodCode = itm.year;
                      tempObj.comments = itm.comments;
                      tempObj.parentBatchNum = itm.parent_batch_number;
                      tempObj.allocationBatchNum = itm.allocation_batch_number;
                      tempObj.externalBatchNum = itm.external_batch_number;
                      tempObj.createdBy = 1;
                      tempObj.transactionType = 'B';
                      tempObj.newBatchNum = itm.new_batch_number;
                      tempObj.versionName = itm.version_name;
                      tempObj.parentVersionName = itm.parent_version_name;
                      tempObj.subProj = itm.subproject;
                      tempObj.budgetTypeID = itm.budget_type_id;
                      budgetArr.push(tempObj);
                  }
            });
          }
          payload.projBudgetVersion = dataChange ? budgetArr : [];
          payload.projNum = projNum;
          payload.initiativeCode = initiativeCode;
          payload.authCode = authCode;
          payload.costcenter = costcenter;
          payload.username = username;
          payload.count = count;
          payload.inactiveFYcount = inactiveFYcount;
          payload.isDataToSave = true;
          payload.periodInvalidCount = periodInvalidCount;
         // console.info("===> payload: " + JSON.stringify(payload));
          } else {
            var allocatedOriTotal = originalData.filter(it => (it.budgetBreakdown == 0));
            var isallocatedOriTotalNull = allocatedOriTotal.length == allocatedOriTotal.length ? true : false;
            if ((statusVal == 'Notphased' && isCBTotalNull && isallocatedOriTotalNull) || (changeAlertVal)) {
              var distinctPeriods = [...new Set(originalData.map(x => x.budgetPeriod))];

              const escapeRegExpMatch = function(s) {
                  return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
              };
              const isExactMatch = (str, match) => {
                return new RegExp(`\\b${escapeRegExpMatch(match)}\\b`).test(str);
              }

              distinctPeriods.forEach((itm, index) => {
                var editablecount = 0;
                var isEditable = false;
                var budgetForYear = originalData.filter(it => (it.budgetPeriod === itm))
                var capForYear = originalData.filter(it => (it.budgetPeriod === itm && isExactMatch(it.proj_type,'Capital')))
                var opForYear = originalData.filter(it => (it.budgetPeriod === itm && (isExactMatch(it.proj_type,'Operating') || (isExactMatch(it.proj_type,'Billable')))));
                var budgetTotal = budgetForYear.reduce(function(prev, cur) {
                return prev + cur.budgetBreakdown;
                }, 0);
                var capTotal = capForYear[0]?capForYear.reduce(function(prev, cur) {
                  return prev + cur.budgetBreakdown;
                }, 0):0;
                var opTotal = opForYear[0]?opForYear.reduce(function(prev, cur) {
                  return prev + cur.budgetBreakdown;
                }, 0):0;
                budgetForYear.forEach((dataItm, index) => {
                  var startDt = new Date(dataItm.startdate);
                  var endDt = new Date(dataItm.enddate);
                  var startYr =  startDt.getMonth() >= 7? startDt.getFullYear() +1 :startDt.getFullYear();
                  var endYr = endDt.getMonth() >= 7 ? endDt.getFullYear() + 1: endDt.getFullYear();
                  if (dataItm.budgetPeriod !== 'TEI') {
                  var periodYr = periodYear[periodYear.findIndex(x => x.periodkey === dataItm.budgetPeriod)].periodVal;
                  if ((startDt && periodYr >= startYr || dataItm.startdate == '' || dataItm.startdate == null || dataItm.startdate == undefined) 
                  && (endDt && periodYr <= endYr || dataItm.enddate == '' || dataItm.enddate == null || dataItm.enddate == undefined) && (periodYr >= today.getFullYear())) {
                    isEditable = true;
                    editablecount = editablecount +1;
                  } else {
                    if (dataItm.amount != 0) {
                    inactiveFYcount = inactiveFYcount + 1;
                    }
                  }
                  } else {
                  isEditable = true;
                  }
                });
                if (editablecount <= 0 && budgetForYear[0].amount != 0 && itm != 'TEI') {
                periodInvalidCount = periodInvalidCount + 1;
                }
                var tempObj = {};
                tempObj.period = itm;
                if (isEditable) {
                var controllingBudget = budgetForYear[0].amount !== 0 ? Number(budgetForYear[0].amount.replace(/\,/g,'')) : 0;
                var controllingCap = capForYear[0]?(capForYear[0].cap_amount !== 0 ? Number(capForYear[0].cap_amount.replace(/\,/g,'')) : 0):0;
                var controllingOp = opForYear[0]?(opForYear[0].op_amount !== 0 ? Number(opForYear[0].op_amount.replace(/\,/g,'')) : 0):0;
                tempObj.IsCapValidFlag = controllingCap === Number(capTotal.toFixed(2)) ? true : false;
                tempObj.IsOpValidFlag = controllingOp === Number(opTotal.toFixed(2)) ? true : false;
                tempObj.IsValidFlag = controllingBudget === Number(budgetTotal.toFixed(2)) ? true : false;

                if(tempObj.IsCapValidFlag == false){
                  capFlag = true;
                }
                if(tempObj.IsOpValidFlag == false){
                  opFlag = true;
                }

                } else {                
                tempObj.IsValidFlag = true;
                tempObj.IsOpValidFlag = true;
                tempObj.IsCapValidFlag = true;
                }
                if(itm == 'TEI')
                {
                  tempObj.IsValidFlag = true;
                  tempObj.IsOpValidFlag = true;
                  tempObj.IsCapValidFlag = true;
                }
                count = tempObj.IsValidFlag ? count : count+1;
                count = tempObj.IsOpValidFlag ? count : count+1;
                count = tempObj.IsCapValidFlag ? count : count+1;
                totalYearValidation.push(tempObj);
              });
              document.getElementById("projDetdatagrid").refresh();
              originalData.forEach((itm, index) => {
                  dataChange = true;
                  var tempObj = {};
                  tempObj.combinationID = itm.combinationID;
                  tempObj.allocationID = itm.allocationID;
                  tempObj.budget_amount = itm.budgetBreakdown;
                  tempObj.periodCode = itm.year;
                  tempObj.comments = itm.comments;
                  tempObj.parentBatchNum = itm.parent_batch_number;
                  tempObj.allocationBatchNum = itm.allocation_batch_number;
                  tempObj.externalBatchNum = itm.external_batch_number;
                  tempObj.createdBy = 1;
                  tempObj.transactionType = 'B';
                  tempObj.newBatchNum = itm.new_batch_number;
                  tempObj.versionName = itm.version_name;
                  tempObj.parentVersionName = itm.parent_version_name;
                  tempObj.subProj = itm.subproject;
                  tempObj.budgetTypeID = itm.budget_type_id;
                  budgetArr.push(tempObj);
              });
              payload.projBudgetVersion = dataChange ? budgetArr : [];
              payload.projNum = projNum;
              payload.initiativeCode = initiativeCode;
              payload.authCode = authCode;
              payload.costcenter = costcenter;
              payload.username = username;
              payload.count = count;
              payload.inactiveFYcount = inactiveFYcount;
              payload.isDataToSave = true;
              payload.periodInvalidCount = periodInvalidCount;
            } else {
              payload.isDataToSave = false;
            }
          }
          // console.log("++payload",payload);
          // console.log("++validation",totalYearValidation);
          // console.log('++capopflag',capFlag,opFlag);
          return [payload,capFlag,opFlag];
      };
      
      PageModule.prototype.saveWithCommentsAdded = function(payload, comments) {
        //// console.log(payload);
        payload.comments = comments;
        return payload;
      };

      //Function on cell data change
      PageModule.prototype.handleAfterEdit = function(event) {
         // // console.log(event);
          var totalVal = 0;
          var totalTEIbudget =0;
          var controllingTotalArr = [];
          var totalTEIArr = [];
          var data = {}; 

            var colTotalBudget=0;
          var rowTotalBudget =0;


          var rowDataArr = event.cellContext.datasource.data._rows;
          var updatedCol = JSON.parse(event.cellContext.keys.column);
          var updatedRow = JSON.parse(event.cellContext.keys.row);
          var rowIndex = rowDataArr.findIndex(i => (i.project === updatedRow.project && i.budgetPeriod === updatedCol.budgetPeriod));
          event.cellContext.datasource.data._rows[rowIndex]['budgetBreakdown'] = Number(Number(event.cellContext.data).toFixed(2));
          var foramttedArr = event.cellContext.datasource.data._rows;
          foramttedArr.forEach((item1, index) => {
            var colTotal=0;
            var rowTotal=0;
            var budgetPeriodbased= foramttedArr.filter(it => (it.budgetPeriod === item1.budgetPeriod));
              colTotal = budgetPeriodbased.reduce(function(prev, cur) {
              return prev + cur.budgetBreakdown;
            }, 0);
            var budgetRowbased= foramttedArr.filter(it => (it.project === item1.project) && (it.budget_type_id === 1));
            rowTotal = budgetRowbased.reduce(function(prev, cur) {
              return prev + cur.budgetBreakdown;
            }, 0);
            foramttedArr[index]['columnTotal'] = colTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            foramttedArr[index]['subProjTotal'] = rowTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            if (item1.budget_type_id === 4) {
              totalTEIbudget = totalTEIbudget + item1.budgetBreakdown;
            } else {
              totalVal = totalVal + item1.budgetBreakdown;
            }
            if(updatedCol.budgetPeriod==item1.budgetPeriod && updatedRow.project==item1.project){
              colTotalBudget = colTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              rowTotalBudget = rowTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }

          });
          var objVal = {};
        objVal["id"] = 0;
        objVal["series"] = 'Total EPM Budget';
        objVal["value"] = controllingBudgetVal;
        objVal["group"] = graph2;
        controllingTotalArr.push(objVal);
        var objVal2 = {};
        objVal2["id"] = 1;
        objVal2["series"] = 'Total PFM Budget';
        objVal2["value"] = totalVal;
        objVal2["group"] = graph2;
        controllingTotalArr.push(objVal2);

        //TEI graph
        var objVal3 = {};
        objVal3["id"] = 0;
        objVal3["series"] = 'Total TEI Budget';
        objVal3["value"] = allocatedTEIbudget;
        objVal3["group"] = graph1;
        totalTEIArr.push(objVal3);
        var objVal4 = {};
        objVal4["id"] = 1;
        objVal4["series"] = 'Total TEI Allocated Budget';
        objVal4["value"] = totalTEIbudget;
        objVal4["group"] = graph1;
        totalTEIArr.push(objVal4);

        //Variance value showing the difference between controllingBudgetVal and totalVal
        var objVal5 = {};
        objVal5["id"] = 0;
        objVal5["series"] = 'Variance Value';
        objVal5["value"] = controllingBudgetVal - totalVal;
        objVal5["group"] = graph3;
        controllingTotalArr.push(objVal5);

          cube = generateCube(foramttedArr, axes);
          var budgetData = new MyDataGridDataSource(cube);  
          data.budgetData = budgetData;
          data.controllingTotalArr = controllingTotalArr; 
          data.totalTEIArr = totalTEIArr; 
             var nodes = document.getElementsByClassName('oj-datagrid-header-cell');
         for (var col = 0; col < nodes.length; col++) {
            //for checking columnwise total budget div element id
            if(nodes[col].innerText==updatedCol.budgetPeriod){
              var colId=nodes[col].id.split("-");
              // console.log("col id",colId);
              var totalBudgetColId="ui-id-"+(Number(colId[2])+4);
              $("#"+totalBudgetColId).text(colTotalBudget);
            }
          }

          for (var row = 0; row < nodes.length; row++) {
            //for checking columnwise total budget div element id
            if(nodes[row].innerText==updatedRow.project){
              var rowId=nodes[row].id.split("-");
              var totalBudgetrowId="ui-id-"+(Number(rowId[2])+3);
              $("#"+totalBudgetrowId).text(rowTotalBudget);
            }
          }
          // console.log("after edit",data);
          return data;
      };
      
      PageModule.prototype.formatProjVersionData = function(response) {
       // // console.log(response);
        var resultArr = [];
        response.forEach(function(item, index) {
          var tempObj = {};
          tempObj.SlNo = index;
          tempObj.proj_number = item.proj_number;
          tempObj.budget_amount = item.budget_amount;
          tempObj.year = item.year;
          tempObj.budget_version_id = item.budget_version_id;
          resultArr.push(tempObj);
        });
        return resultArr;
      };

    PageModule.prototype.getInvalidAllocationMsg = function (editable) {
      var msg = "";
      if( editable){
        msg = "NOTE - The allocated amount(s) during inactive period have been removed.";
      }else{
        msg = "NOTE - There are allocated amount(s) during the inactive period.";
      }
      return msg;
    };

    PageModule.prototype.launchMenu = function () {
      document.getElementById("menuOption").open();
    };

    PageModule.prototype.formatCurrency = function (amount) {
    var formattedamt = 0;

    if (!isNaN(amount)) {
      amount = Number.parseFloat(amount).toFixed(2);
      formattedamt = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    return formattedamt;

  };

  //Function to load comments page
  PageModule.prototype.showCommentTable = function () {
   document.getElementById("commentTable").style.display="block";
   document.getElementById("historyTable").style.display="none";
  document.getElementById("PFMallocationDiv").style.display="none";
  };

  //Function to generate history data
  PageModule.prototype.formatHistoryData = function (response,budgetTypeList) {
  //  // console.log(response);
    var data = {};
    var cpdata = response.filter(it => (it
            .data_level === 'CB'));
    var cpteidata = cpdata.filter(it => (it
            .budget_type_name === 'TEI'));
    var cpbudgetdata = cpdata.filter(it => (it
            .budget_type_name === budgetTypeList[Object.keys(budgetTypeList)[0]]));
    var spdata = response.filter(it => (it
            .data_level === 'SP'));
    var spteidata = spdata.filter(it => (it
            .budget_type_name === 'TEI'));
    var spbudgetdata = spdata.filter(it => (it
            .budget_type_name === budgetTypeList[Object.keys(budgetTypeList)[0]]));
    data.cpteidata = cpteidata;
    data.cpbudgetdata = cpbudgetdata;
    data.spteidata = spteidata;
    data.spbudgetdata = spbudgetdata;
    return data;
  };

  PageModule.prototype.showHistoryTable = function () {
   document.getElementById("commentTable").style.display="none";
   document.getElementById("historyTable").style.display="block";
  document.getElementById("PFMallocationDiv").style.display="none";
  };

  PageModule.prototype.showPFMAllocationDiv = function () {
    document.getElementById("PFMallocationDiv").style.display="block";
    document.getElementById("historyTable").style.display="none";
    document.getElementById("commentTable").style.display="none";
  };

    //Function to validate the total budget with the EPM budget for each year
    PageModule.prototype.validateTotalYearValues = function (gridData){

      // console.log("grid data",gridData);
      if(gridData == undefined || gridData == null || gridData == ""){
        return 0;
      }

      var updatedBudgetArr = gridData.data._rows;
      var distinctPeriods = [...new Set(updatedBudgetArr.map(x => x
        .budgetPeriod))];
     // // console.log("===> distinctPeriods: " + JSON.stringify(distinctPeriods));
      var count = 0;
      totalYearValidation = [];

      distinctPeriods.forEach((item, index) => {
        
          var budgetForYear = updatedBudgetArr.filter(it => (it
            .budgetPeriod === item));
          const escapeRegExpMatch = function(s) {
              return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
          };
          const isExactMatch = (str, match) => {
            return new RegExp(`\\b${escapeRegExpMatch(match)}\\b`).test(str);
          }
          var capForYear = updatedBudgetArr.filter(it => (it.budgetPeriod === item && isExactMatch(it.proj_type,'Capital')));
          var opForYear = updatedBudgetArr.filter(it => (it.budgetPeriod === item && (isExactMatch(it.proj_type,'Operating') || (isExactMatch(it.proj_type,'Billable')))));
          var totalAllocated = budgetForYear[0].amount;
          var totalBudget = budgetForYear[0].columnTotal;
          var capTotal = capForYear[0]?capForYear.reduce(function(prev, cur) {
            return prev + cur.budgetBreakdown;
          }, 0):0;
          var opTotal = opForYear[0]?opForYear.reduce(function(prev, cur) {
            return prev + cur.budgetBreakdown;
          }, 0):0;
          var controllingCap = capForYear[0]?(capForYear[0].cap_amount !== 0 ? Number(capForYear[0].cap_amount.replace(/\,/g,'')) : 0):0;
          var controllingOp = opForYear[0]?(opForYear[0].op_amount !== 0 ? Number(opForYear[0].op_amount.replace(/\,/g,'')) : 0):0;
          // console.log("year",item);
          // console.log("cap total, controlling",capTotal,controllingCap);
          // console.log("op total, controlling",opTotal,controllingOp);
          var tempObj = {};
          tempObj.period = item;
          tempObj.IsValidFlag = Number(totalBudget.toString().replace(/\,/g,'')) == Number(totalAllocated.toString().replace(/\,/g,'')) ? true : false;
          tempObj.IsCapValidFlag = controllingCap === Number(capTotal.toFixed(2)) ? true : false;
          tempObj.IsOpValidFlag = controllingOp === Number(opTotal.toFixed(2)) ? true : false;
          if(item == 'TEI'){
           tempObj.IsValidFlag = true;
          tempObj.IsCapValidFlag = true;
          tempObj.IsOpValidFlag = true;
        }
          count = tempObj.IsValidFlag ? count : count + 1;
          count = tempObj.IsCapValidFlag ? count : count + 1;
          count = tempObj.IsOpValidFlag ? count : count + 1;
          totalYearValidation.push(tempObj);
      });

      return count;

    };

    };

  /**
   * Function to export data
   * @param {String} arg1
   * @return {String}
   */
 PageModule.prototype.createExportData = function (dataArray) {
   // console.log("************* export data array");
    // console.log(dataArray);
if(dataArray && dataArray.length > 0){
    var distinctProject = dataArray.map(item => item.project) .filter((value, index, self) => self.indexOf(value) === index);
    var distnctPeriod = dataArray.map(item => item.budgetPeriod) .filter((value, index, self) => self.indexOf(value) === index);
   // // console.log("************* Distinct Peoject");
   // // console.log(distinctProject);
    
    //// console.log("************* Distinct Period");
   // // console.log(distnctPeriod);
    
    
  var finalArray = [];
//// console.log("************* export data array1002");
  if (distinctProject != undefined && distinctProject !== null && distinctProject !== "" && distnctPeriod != undefined && distnctPeriod !== null && distnctPeriod !== "")
 
   {
     var cnt = 0 ;
     
         for(const tempproject of distinctProject)
           {
              var obj = {};
              cnt = cnt + 1;
//// console.log("************* export data array1016");
                         if (cnt==1)
                              {
                                obj = {};
                                for(const tempperiod of distnctPeriod)
                                   {
                                      var filteredArrayItem = dataArray.filter(item=> item.project==tempproject && item.budgetPeriod==tempperiod);
                                        
                                           obj["PFM Project"] = '';
                                           obj["Project Type"] = '';
                                           obj["Status"] = 'EPM Budget' ; 
                                            obj["PFM Project Total"] = '';
//// console.log("************* export data array1027");
//added && filteredArrayItem[0].amount !== 0 and replaced obj[tempperiod] = 0 with obj[tempperiod] = '0.00'
                                            if (filteredArrayItem[0].amount !== undefined && filteredArrayItem[0].amount !== null && filteredArrayItem[0].amount !== '' && filteredArrayItem[0].amount !== 0)
                                            {
                                             // obj[tempperiod] = filteredArrayItem[0].amount.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                                 obj[tempperiod] = filteredArrayItem[0].amount ;   
                                            }
                                          else
                                            {
                                              obj[tempperiod] = '0.00';
   // // console.log("************* export data array1036");                              
                                            }
                                           
                                    }
                                   
                                          finalArray.push(obj);
                                          // console.log("export array",finalArray);
                                          obj = {};
                                    for(const tempperiod of distnctPeriod)
                                   {
                                      var filteredArrayItem = dataArray.filter(item=> item.project==tempproject && item.budgetPeriod==tempperiod);
                                       
                                           obj["PFM Project"] = '';
                                           obj["Project Type"] = '';
                                           obj["Status"] = 'EPM CAPEX' ; 
                                            obj["PFM Project Total"] = '';
//// console.log("************* export data array1027");
                                            if (filteredArrayItem[0].cap_amount !== undefined && filteredArrayItem[0].cap_amount !== null && filteredArrayItem[0].cap_amount !== '' && filteredArrayItem[0].amount !== 0)
                                            {
                                             // obj[tempperiod] = filteredArrayItem[0].amount.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                                 obj[tempperiod] = filteredArrayItem[0].cap_amount ;   
                                            }
                                          else
                                            {
                                              obj[tempperiod] = '0.00';
   // // console.log("************* export data array1036");                              
                                            }
                                           
                                    }
                              
                                     finalArray.push(obj);
                                     // console.log("export array",finalArray);
                                     obj = {};

                                    for(const tempperiod of distnctPeriod)
                                   {
                                      var filteredArrayItem = dataArray.filter(item=> item.project==tempproject && item.budgetPeriod==tempperiod);
                                   
                                           obj["PFM Project"] = '';
                                           obj["Status"] = 'EPM OPEX' ; 
                                           obj["Project Type"] = '';
                                            obj["PFM Project Total"] = '';
//// console.log("************* export data array1027");
                                            if (filteredArrayItem[0].op_amount !== undefined && filteredArrayItem[0].op_amount !== null && filteredArrayItem[0].op_amount !== '' && filteredArrayItem[0].amount !== 0)
                                            {
                                             // obj[tempperiod] = filteredArrayItem[0].amount.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                                 obj[tempperiod] = filteredArrayItem[0].op_amount ;   
                                            }
                                          else
                                            {
                                              obj[tempperiod] = '0.00';
   // // console.log("************* export data array1036");                              
                                            }
                                           
                                    }
                                    
                                     finalArray.push(obj);
                                     // console.log("export array",finalArray);
                                  } 
                              
             obj = {} ;
                             
             
              for(const tempperiod of distnctPeriod)
              {
                  var filteredArrayItem = dataArray.filter(item=> item.project==tempproject && item.budgetPeriod==tempperiod);
                  // console.log("*current test");
                  // console.log(filteredArrayItem);
                    
                     obj["PFM Project"] = filteredArrayItem[0].project;
                    obj["Status"] = filteredArrayItem[0].status;
                     obj["Project Type"] = filteredArrayItem[0].proj_type;
                   // obj["Budget Period"] = filteredArrayItem[0].budgetPeriod;
                    // obj["Sub Project"] = filteredArrayItem[0].subproject;
                   // obj["Start-End Date"] = filteredArrayItem[0].startenddate;
                 
                      obj["PFM Project Total"] = '';
                   
//// console.log("************* export data array1063");
                   if (filteredArrayItem[0].budgetBreakdown !== undefined && filteredArrayItem[0].budgetBreakdown !== null && filteredArrayItem[0].budgetBreakdown !== '')
                   {
                    obj[tempperiod] = filteredArrayItem[0].budgetBreakdown.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                 
                   }
                   else
                   {
                        obj[tempperiod] = filteredArrayItem[0].budgetBreakdown + '\t';
                       
                   }
                    
                    
                  
              } 
              finalArray.push(obj);
           }  
              
          
   
 
    // // console.log ("Export Array");
   //  // console.log(finalArray);
     return finalArray ;
   }
   else{
     return null;
   }
}
  };

   PageModule.prototype.readFileContent = function(file) {
    var fileData = new Promise(function(resolve) {
      if (file) {
        var fileReader = new FileReader();
        fileReader.onload = function(fileReadEvent) {
          var readCSVData = fileReadEvent.target.result;
          resolve(readCSVData);
        };
        fileReader.readAsText(file);
      } else {
        resolve("false");
      }
    });
    return fileData;
  };

  PageModule.prototype.processFileContent = function (fileData, uploaded_by, project_name, initiative_code, authority_code, cost_center) {

     var project_number = project_name.substr(0, project_name.indexOf('-')).trim(); 
// console.log("jagat fileData");
    // console.log (fileData);
  //  // console.log (uploaded_by);
  //  // console.log (project_number);
  //  // console.log (initiative_code);
  //  // console.log (authority_code);
  //  // console.log (cost_center);

    var fileDataArr = [];
    var finalObj = {};
    var rows = fileData.split("\n");
    var retData = {};

   
    
    for (var i = 1; i < rows.length ; i++) {

      var rowData = this.parseRow(rows[i]);
      // console.log("row data", rowData)

      if (rowData[0] !== undefined && rowData[0] !== null && rowData[0] !== '' ) {

          var filerowObj = {};

          filerowObj.PFM_PROJECT =  rowData[0];
          filerowObj.STATUS =  rowData[2];
          filerowObj.PROJECT_TYPE = rowData[1];
          filerowObj.SUB_PROJECT_TOTAL =  rowData[3].replace('\t', '');
          filerowObj.TEI =  rowData[4].replace('\t', '').replace('\r','');
          filerowObj.YAER1 =  rowData[5].replace('\t', '').replace('\r','');
          filerowObj.YAER2 =  rowData[6].replace('\t', '').replace('\r','');
          filerowObj.YAER3 =  rowData[7].replace('\t', '').replace('\r','');
          filerowObj.YAER4 =  rowData[8].replace('\t', '').replace('\r','');
          filerowObj.YAER5 =  rowData[9].replace('\t', '').replace('\r','');
          filerowObj.YAER6 =  rowData[10].replace('\t', '').replace('\r','');
          filerowObj.UPLOADED_BY = uploaded_by;
          filerowObj.PROJECT_NUMBER = project_number;
          filerowObj.PROJECT_NAME = project_name;
          filerowObj.INITIATIVE_CODE = initiative_code;
          filerowObj.AUTHORITY_CODE = authority_code;
          filerowObj.COST_CENTER_CODE = cost_center;
          filerowObj.SUB_PROJECT_NUMBER = rowData[0].substr(0,rowData[0].indexOf('-')).trim();

          fileDataArr.push(filerowObj);

      }

    }   

    finalObj.BUDGET_DATA_ARR = fileDataArr;

    // console.log(finalObj);
    
    return finalObj;

};

PageModule.prototype.parseRow = function(row) {
    var insideQuote = false,
      entries = [],
      entry = [];
    row.split('').forEach(function(character) {
      if (character === '"') {
        insideQuote = !insideQuote;
      } else {
        if (character == "," && !insideQuote) {
          entries.push(entry.join(''));
          entry = [];
        } else {
          entry.push(character);
        }
      }
    });
    entries.push(entry.join(''));
    return entries;
  };
      

    return PageModule;
  });
