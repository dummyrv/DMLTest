define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.formatApprovedBudget = function(response) {
        console.log(response);
        var resultArr = [];
        response.forEach(function(item, index) {
          var tempObj = {};
          tempObj.SlNo = index;
          tempObj.approval_date = item.approval_date;
          tempObj.approved_by = item.approved_by;
          tempObj.proj_number = item.proj_number;
          tempObj.version = item.version;
          resultArr.push(tempObj);
        });
        return resultArr;
      };
      
     PageModule.prototype.submitRowERPbutton = function(response) {
        console.log(response.row);
        var payload = {};
        payload.BudgetVersionName = response.row.version;
        payload.ProjectNumber = response.row.proj_number;
        return payload;
     };
     
     PageModule.prototype.saveBackToBudgetVersion = function(username, bugdetVersion) {
        var payload = {};
        payload.submittedToERP = 'Y';
        payload.submittedBy = username;
        payload.BudgetVersionName = bugdetVersion;
        return payload;
     };

  return PageModule;
});
