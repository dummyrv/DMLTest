define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  var periodFields = [
        {
          attribute: 'jul',
          label: 'Jul',
          value: 1
        }, {
          attribute: 'aug',
          label: 'Aug',
          value: 2
        },
        {
          attribute: 'sep',
          label: 'Sep',
          value: 3
        }, {
          attribute: 'oct',
          label: 'Oct',
          value: 4
        },
        {
          attribute: 'nov',
          label: 'Nov',
          value: 5
        }, {
          attribute: 'dec',
          label: 'Dec',
          value: 6
        }, {
          attribute: 'jan',
          label: 'Jan',
          value: 7
        }, {
          attribute: 'feb',
          label: 'Feb',
          value: 8
        },
        {
          attribute: 'mar',
          label: 'Mar',
          value: 9
        }, {
          attribute: 'apr',
          label: 'Apr',
          value: 10
        },
        {
          attribute: 'may',
          label: 'May',
          value: 11
        }, {
          attribute: 'jun',
          label: 'Jun',
          value: 12
        }
      ];
  PageModule.prototype.readFileContent = function(file) {
    var fileData = new Promise(function(resolve) {
      if (file) {
        var fileReader = new FileReader();
        fileReader.onload = function(fileReadEvent) {
          var readCSVData = fileReadEvent.target.result;
          resolve(readCSVData);
        };
        fileReader.readAsText(file);
      } else {
        resolve("false");
      }
    });
    return fileData;
  };

    /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.processFileContent = function (fileData, uploaded_by) {

    var fileDataArr = [];
    var finalObj = {};
    var startPos = 9;
    var rows = fileData.split("\n");
    console.log("===> rows: " + JSON.stringify(rows));
    console.log("===> rows length: " + rows.length);

    const d = new Date();
    var currmonth = d.getMonth() - 6;
    //console.log("===> current month: " + currmonth);

    var junData = '';

    var rowDataHeader = this.parseRow(rows[0]);

    var currFiscalYear = rowDataHeader[startPos];

    console.log("rowDataHeader[9] --> " + rowDataHeader[startPos]);
    console.log(rowDataHeader[startPos].substring(4));



    if (rowDataHeader[startPos].substring(4) == 'ul') {
      currFiscalYear = Number(currFiscalYear.toString().substr(0, 2)) + 1;
    } else {
      currFiscalYear = Number(rowDataHeader[startPos].substr(4)) + 1;
    }


    console.log('***currFiscalYear******');

    console.log(currFiscalYear);

    for (var i = 1; i < rows.length; i++) {

      var rowData = this.parseRow(rows[i]);
      if (rowData[0] !== undefined && rowData[0] !== null && rowData[0] !== '' && rowData[2] !== undefined && rowData[2] !== null && rowData[2] !== '') {

        for (var j = 0; j < 10; j++) {

          var filerowObj = {};

          filerowObj.BUDGET_PERIOD = 'FY' + (Number(currFiscalYear) + j);
          console.log("===> budget type: " + rowData[1]);
          filerowObj.SUB_PROJECT_NUMBER = rowData[0];
          if (rowData[1].toUpperCase() == "BUDGET") {
            filerowObj.BUDGET_TYPE_ID = 1;
          } else if(rowData[1].toUpperCase() === "FORECAST") {
            filerowObj.BUDGET_TYPE_ID = 2;
          } else if(rowData[1].toUpperCase() === "CONTRACT") {
            filerowObj.BUDGET_TYPE_ID = 3;
          }

          filerowObj.TASK_CODE = rowData[2];
          filerowObj.EXPENDITURE_NAME = rowData[4];

          for (const period of periodFields) {
            var k = period.value - 1;
            var periodValue = period.attribute.toUpperCase();

            filerowObj[periodValue] = rowData[startPos + k + j * 12];
            if (period.attribute === "jun" && filerowObj[periodValue] !== undefined && filerowObj[periodValue] !== null) {
              filerowObj[periodValue] = filerowObj[periodValue].replace('\r', '');
            }

          }

          filerowObj.UPLOADED_BY = uploaded_by;
          fileDataArr.push(filerowObj);

        }
      }
    }

    finalObj.BUDGET_DATA_ARR = fileDataArr;
    finalObj.ACTION = "VALIDATE";

    console.log("===> finalObj: " + JSON.stringify(finalObj));

    return finalObj;

  };

PageModule.prototype.getSaveData = function (batch_id,uploaded_by) {
  var finalObj = {};
  finalObj.ACTION = 'SAVE';
  finalObj.UPLOADED_BY = uploaded_by;
  finalObj.BATCH_ID = batch_id;
  
  console.log("===> finalObj: " + JSON.stringify(finalObj));
  return finalObj;

};

PageModule.prototype.parseRow = function(row) {
    var insideQuote = false,
      entries = [],
      entry = [];
    row.split('').forEach(function(character) {
      if (character === '"') {
        insideQuote = !insideQuote;
      } else {
        if (character == "," && !insideQuote) {
          entries.push(entry.join(''));
          entry = [];
        } else {
          entry.push(character);
        }
      }
    });
    entries.push(entry.join(''));
    return entries;
  };

  return PageModule;
});
