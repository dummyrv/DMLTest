define([], () => {
  'use strict';

  class PageModule {
    getPageId(response, pageName) {
    if (response?.body?.items && Array.isArray(response.body.items)) {
        for (const item of response.body.items) {
            if (item.page_name === pageName) {
                return item.page_id;
            }
        }
    }
    // Return null if no match is found
    return null;
}


  }
  PageModule.prototype.isFormValid = function(form) {
      const tracker = document.getElementById(form);
      
      if (tracker === undefined || tracker === null) {
        return true;
      } else if (tracker.valid === "valid") {
        return true;
      } else {
        tracker.showMessages();
        tracker.focusOn("@firstInvalidShown");
        return false;
      }
    };
  return PageModule;
});
