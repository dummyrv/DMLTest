define(['ojs/ojcore', 'ojs/ojcube', 'ojs/ojknockouttemplateutils'], function (oj, Cube, KnockoutTemplateUtils) {
  'use strict';

  var PageModule = function PageModule() {

  };
  var cube = null;
  var currentPeriod = null;
  var originalGridData = null;
  var editMode = "navigation";
  var periodFields = [
        {
          attribute: 'jul',
          label: 'Jul',
          value: 1
        }, {
          attribute: 'aug',
          label: 'Aug',
          value: 2
        },
        {
          attribute: 'sep',
          label: 'Sep',
          value: 3
        }, {
          attribute: 'oct',
          label: 'Oct',
          value: 4
        },
        {
          attribute: 'nov',
          label: 'Nov',
          value: 5
        }, {
          attribute: 'dec',
          label: 'Dec',
          value: 6
        }, {
          attribute: 'jan',
          label: 'Jan',
          value: 7
        }, {
          attribute: 'feb',
          label: 'Feb',
          value: 8
        },
        {
          attribute: 'mar',
          label: 'Mar',
          value: 9
        }, {
          attribute: 'apr',
          label: 'Apr',
          value: 10
        },
        {
          attribute: 'may',
          label: 'May',
          value: 11
        }, {
          attribute: 'jun',
          label: 'Jun',
          value: 12
        }
      ];

  function generateCube(dataArr, axes) {
    return new Cube.DataValueAttributeCube(dataArr, axes, periodFields);
  };
  var axes = [{
    axis: 0,
    levels: [{
      attribute: 'period_fy'
    }, {
      attribute: 'total_budget'
    }, {
      dataValue: true
    },
    {
      attribute: 'column_total_budget'
    },
    
    ]
  },
  {
    axis: 1,
    levels: [{
      attribute: 'task_number'
    },
    {
      attribute: 'expenditure_type_name'
    },
    {
      attribute: 'all_fy_total'
    },
    {
      attribute: 'wbs_budget_total'
    },
    {
      attribute: 'fy_total'
    }
    ]
  }
  ];

  function MyDataGridDataSource(data, options) {

    MyDataGridDataSource.superclass.constructor.call(this, data,
      options);
  };
  oj.Object.createSubclass(MyDataGridDataSource, oj.CubeDataGridDataSource, "oj.MyDataGridDataSource");

  MyDataGridDataSource.prototype.fetchHeaders = function (headerRange,
    callbacks, callbackObjects) {
    var axis = headerRange.axis;
    var start = headerRange.start;
    var count = headerRange.count;
    var end = start;

    var callback = function (headerSet, headerRange) {
      headerSet.getLabel = function (level) {
        if (headerRange.axis == "column") {

          if (level == 0)
            return 'Forecast Year';
          else if (level == 1)
            return 'Allocated Forecast';
          else if (level == 2)
            return 'Forecast Month';
          else if (level == 3)
            return 'Month Total';  
        }

        if (headerRange.axis == "row") {
          if (level == 0)
            return 'Task Number';
          else if (level == 1)
            return 'Expenditure Type';
          else if (level == 4)
            return 'FY Total';
          else if (level == 2)
            return 'Total WBS Cost Forecast';
          else if (level == 3)
            return 'FY Approved Budget';
        }

        return '';
      };
      callbacks.success.call(this, headerSet, headerRange);
    }

    MyDataGridDataSource.superclass.fetchHeaders.call(this,
      headerRange, {
      success: callback
    }, callbackObjects);

  };

  function isCellReadonly(cellContext) {

    var cellHeader = JSON.parse(cellContext.keys.column);
    
    var rowHeader = JSON.parse(cellContext.keys.row);
    var periodYr = '20' + cellHeader.period_fy.replace("FY", "");
    
    var cellMonth = Object.keys(cellHeader)[3];

    if (['jul', 'aug', 'sep', 'oct', 'nov', 'dec'].includes(cellMonth)) {
      periodYr = periodYr - 1;
    }

    var cellDate = new Date('1-' + cellMonth + '-' + periodYr);

    var taskStartDate = cellContext.datasource.data._rows[cellContext.indexes.row].task_start_date ? new Date(cellContext.datasource.data._rows[cellContext.indexes.row].task_start_date) : null;
    var taskEndDate = cellContext.datasource.data._rows[cellContext.indexes.row].task_end_date ? new Date(cellContext.datasource.data._rows[cellContext.indexes.row].task_end_date) : null;
    var today = new Date();
    var firstDay = new Date(today. getFullYear(), today. getMonth(), 1);

    if ((taskStartDate && cellDate < taskStartDate) || (taskEndDate && cellDate > taskEndDate) || (cellDate && cellDate < firstDay)) {
      return true;
    } else {
      return false;
    }

  };

  PageModule.prototype.getCellClassName = function (cellContext) {
    var cellClassName;
    var readonly = isCellReadonly(cellContext);

    if (readonly) {
      cellClassName = 'oj-helper-justify-content-right  oj-read-only';
    } else {
      if(editMode === "edit"){
        cellClassName = 'oj-helper-justify-content-right';  
      }else{
        cellClassName = 'oj-helper-justify-content-right  oj-read-only';
      }
      
    }

    return cellClassName;
  };
  
  PageModule.prototype.setDatagridEditMode = function(task_status, editflag, histroyFlag,reviewflag){
      if(histroyFlag){
        editMode = "navigation";
        return;
      }

      if(task_status == undefined || task_status == null || task_status == "" || task_status == "Not Allocated" || task_status == "Draft" || 
         task_status == "Posted" || task_status == "Withdrawn" ||task_status == "PostedError"||task_status == "Rejected"){
        if (editflag === 'Y' &&  (!reviewflag || reviewflag === 'N')) {
          editMode = "edit";
        } else {
          editMode = "navigation";
        }
      }else{

        editMode = "navigation";
      }
      
    };

  PageModule.prototype.getCellTemplate = function (cellContext) {
    var readonly = isCellReadonly(cellContext);

    if (readonly) {
      return KnockoutTemplateUtils.getRenderer('cellTemplate')(
        cellContext);

    } else {
      if(editMode === "edit"){
        return KnockoutTemplateUtils.getRenderer('editCellTemplate')(
        cellContext);
      }else{
        return KnockoutTemplateUtils.getRenderer('cellTemplate')(
        cellContext);
      }
      
    }

  };

  PageModule.prototype.getRowHeaderTemplate = function (cellContext) {

    return KnockoutTemplateUtils.getRenderer('rowHeaderTemplate')(cellContext);
  };

  PageModule.prototype.getRowHeaderStyleName = function (cellContext) {
    var cellClassName;

    var row = JSON.parse(cellContext.key);
    if (cellContext.level === 0) {
      cellClassName = 'width:85px;font-size:10px;height:50px;align-items: center;background-color: lightgrey;';
    } else if (cellContext.level === 1) {
      cellClassName = 'width:85px;font-size:10px;height:50px;align-items: center;background-color: lightgrey;';
    } else {
      cellClassName = 'width:100px;font-size:10px;height:50px;align-items: center;background-color: #efefef;';
    }
    return cellClassName;
  };

  PageModule.prototype.getColHeaderTemplate = function (cellContext) {

    return KnockoutTemplateUtils.getRenderer('columnHeaderTemplate')(cellContext);
  };
  PageModule.prototype.getColHeaderStyleName = function (cellContext) {
    var cellClassName = 'width:95px;font-weight:bold;font-size:12px;background-color: #303030;color: white;';
    return cellClassName;
  };

  PageModule.prototype.initTotalSummary = function (currentFyCostVal, budgetSummaryArr) {
    var totalSummaryArr = [];
    if(budgetSummaryArr === undefined || budgetSummaryArr === null || budgetSummaryArr.length === 0){
      return totalSummaryArr;
    }
    //calculate total wbs budget and total forecast
    var total_wbs_budget = 0;
    var total_forecast_budget = 0;
    for(var i= 1; i< budgetSummaryArr.length; i++){
      if(budgetSummaryArr[i].wbs_budget !== undefined && budgetSummaryArr[i].wbs_budget !== null){
         total_wbs_budget = total_wbs_budget + budgetSummaryArr[i].wbs_budget; 
      }

      total_forecast_budget = total_forecast_budget + budgetSummaryArr[i].forecast_budget;
    }

    var allLifeCycleForecast = {};
    allLifeCycleForecast.id = 0;
    allLifeCycleForecast.name = "Total Project Forecast";
    allLifeCycleForecast.value = (budgetSummaryArr[0].wbs_budget + total_forecast_budget).toFixed(2);
    totalSummaryArr.push(allLifeCycleForecast);

    var allLifeCycleBudget = {};
    allLifeCycleBudget.id = 1;
    allLifeCycleBudget.name = "Total Project Budget";
    allLifeCycleBudget.value = (budgetSummaryArr[0].wbs_budget + total_wbs_budget).toFixed(2);
    totalSummaryArr.push(allLifeCycleBudget);

    var allForecastBudget = {};
    allForecastBudget.id = 2;
    allForecastBudget.name = "Total Allocated Forecast";
    allForecastBudget.value = total_forecast_budget.toFixed(2);
    totalSummaryArr.push(allForecastBudget);

    var allWBSBudget = {};
    allWBSBudget.id = 3;
    allWBSBudget.name = "Total Approved Budget";
    allWBSBudget.value = total_wbs_budget.toFixed(2);
    totalSummaryArr.push(allWBSBudget);

    var currentFyCost = {};
    currentFyCost.id = 4;
    currentFyCost.name = "Year-to-Date Cost";
    currentFyCost.value = currentFyCostVal.toFixed(2);
    totalSummaryArr.push(currentFyCost);

    var projectVarianceAmt = {};
    projectVarianceAmt.id = 5;
    projectVarianceAmt.name = "Total Project Variance";
    projectVarianceAmt.value = (budgetSummaryArr[0].wbs_budget + total_forecast_budget).toFixed(2) - (budgetSummaryArr[0].wbs_budget + total_wbs_budget).toFixed(2);
    totalSummaryArr.push(projectVarianceAmt);

    var wbsVarianceAmt = {};
    wbsVarianceAmt.id = 6;
    wbsVarianceAmt.name = "Budget Variance";
    wbsVarianceAmt.value = total_forecast_budget.toFixed(2) - total_wbs_budget.toFixed(2);
    totalSummaryArr.push(wbsVarianceAmt);

    return totalSummaryArr;
    
  };


  PageModule.prototype.refreshTotalSummary = function (budgetSummaryArr) {
    
    if(budgetSummaryArr === undefined){
      return [];
    }
    var updatedTotalSummaryArr = [];

        //calculate total forecast
    var total_forecast_budget = 0;
    for(var i= 1; i< budgetSummaryArr.length; i++){
      total_forecast_budget = total_forecast_budget + budgetSummaryArr[i].forecast_budget;
    }

    var allLifeCycleBudget = {};
    allLifeCycleBudget.id = 0;
    allLifeCycleBudget.name = "Total Project Life Cycle Budget";
    allLifeCycleBudget.value = budgetSummaryArr[0].wbs_budget + total_forecast_budget;
    updatedTotalSummaryArr.push(allLifeCycleBudget);
    
    var allForecastBudget = {};
    allForecastBudget.id = 3;
    allForecastBudget.name = "Total Project Forecast";
    allForecastBudget.value = total_forecast_budget;
    updatedTotalSummaryArr.push(allForecastBudget);

    return updatedTotalSummaryArr;
    
  };

  PageModule.prototype.getBarChartData = function (selectedPeriod, budgetSummaryArr) {
    var budgetChartDataArr = [];
    var budgetChartData = {};
    var budgetChartData2 = {};
    if(budgetSummaryArr === undefined || budgetSummaryArr.length === 0){
      return budgetChartDataArr;
    }

    for(const budgetSummary of budgetSummaryArr){
      if(budgetSummary.period_fy === selectedPeriod) {
          budgetChartData.id = 1;
          budgetChartData.value = budgetSummary.wbs_budget;
          budgetChartData.series = "WBS Budget";
          budgetChartData.group = "Approved Budget vs Allocated Forecast " + selectedPeriod;
          budgetChartDataArr.push(budgetChartData);

          budgetChartData2.id = 2;
          budgetChartData2.value = 0.00;
          budgetChartData2.value = budgetSummary.forecast_budget;
          budgetChartData2.series = "WBS Forecast";
          budgetChartData2.group = "Approved Budget vs Allocated Forecast " + selectedPeriod;
          budgetChartDataArr.push(budgetChartData2);
          return budgetChartDataArr;
      }
    }

    return budgetChartDataArr;
    
  };

  function calculateGridTotal(fyDataArr, budgetDataArr, wbsBudgetFyDataArr) {
    var totalBudget = 0;
    var columnTotal = {};
    fyDataArr.forEach((item, index) => {
      var fyRowTotal = item['jul'] + item['aug'] + item['sep'] + item['oct'] + item['nov'] + item['dec'] + item['jan'] + item['feb'] + item['mar'] + item['apr'] + item['may'] + item['jun'];

      var budgetRowbased = budgetDataArr.filter(it => (it.task_number === item.task_number) && (it.expenditure_type_name === item.expenditure_type_name));
      var allFyRowTotal = budgetRowbased.reduce(function (prev, cur) {
        return prev + cur['jul'] + cur['aug'] + cur['sep'] + cur['oct'] + cur['nov'] + cur['dec'] + cur['jan'] + cur['feb'] + cur['mar'] + cur['apr'] + cur['may'] + cur['jun'];
      }, 0);
      
      allFyRowTotal = allFyRowTotal + item['task_prior_cost']; 
      fyDataArr[index]['fy_total'] = fyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      fyDataArr[index]['all_fy_total'] = allFyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

      fyDataArr[index]['formatted_task_prior_cost'] = item.task_prior_cost.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      fyDataArr[index]['formatted_task_current_fy_cost'] = item.task_current_fy_cost.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      
      var wbsBudgetFyRow = wbsBudgetFyDataArr.filter(it => (it.task_number === item.task_number) && (it.expenditure_type_name === item.expenditure_type_name));
      var wbsBudgetFyRowTotal= wbsBudgetFyRow[0]['jul'] + wbsBudgetFyRow[0]['aug'] + wbsBudgetFyRow[0]['sep'] + wbsBudgetFyRow[0]['oct'] + wbsBudgetFyRow[0]['nov'] + wbsBudgetFyRow[0]['dec'] + wbsBudgetFyRow[0]['jan'] + wbsBudgetFyRow[0]['feb'] + wbsBudgetFyRow[0]['mar'] + wbsBudgetFyRow[0]['apr'] + wbsBudgetFyRow[0]['may'] + wbsBudgetFyRow[0]['jun'];
      fyDataArr[index]['wbs_budget_total'] = wbsBudgetFyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      
      //column total
      for (var i = 0; i < periodFields.length; i++) {
        var month = periodFields[i].attribute;
        
        if (columnTotal[month] === undefined || columnTotal[month] === null) {
          columnTotal[month] = 0;
        }
        columnTotal[month] = columnTotal[month] + item[month];
      }

      totalBudget = totalBudget + fyRowTotal;
    });

    //format column total
    for (var i = 0; i < periodFields.length; i++) {
      var month = periodFields[i].attribute;
      columnTotal[month] = columnTotal[month].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    fyDataArr.forEach((item, index) => {
      fyDataArr[index]['total_budget'] = totalBudget.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      fyDataArr[index]['column_total_budget'] = columnTotal;
    });

    return fyDataArr;

  }

  PageModule.prototype.generateGridData = function (budgetDataArr, budgetSummaryArr, selectedPeriod, wbsBudgetDataArr) {
    var budgetData = {};

    if (budgetDataArr === undefined || budgetDataArr === null || budgetDataArr.length === 0) {

      return null;
    }

    if (selectedPeriod !== '0') {

      var formattedDataArr = [];
      formattedDataArr = budgetDataArr.filter(it => (it.period_fy == selectedPeriod));
      var wbsBudgetFyDataArr = [];
      wbsBudgetFyDataArr = wbsBudgetDataArr.filter(it => (it.period_fy == selectedPeriod));

      formattedDataArr = calculateGridTotal(formattedDataArr, budgetDataArr, wbsBudgetFyDataArr);
      
      cube = generateCube(formattedDataArr, axes);
      budgetData = new MyDataGridDataSource(cube);

    } else {
      cube = generateCube([], axes);
      budgetData = new MyDataGridDataSource(cube);
    }
    originalGridData = budgetData;
    return budgetData;
  };

  PageModule.prototype.handleEditEnd = function (event, budgetDataArr, currentPeriod, budgetSummaryArr) {

    if (event === undefined || event === null) {
      return;
    }
    var newData = event.cellContext.data;
    var rowIndex = event.cellContext.indexes.row;

    var cellHeader = JSON.parse(event.cellContext.keys.column);
    var colName = Object.keys(cellHeader)[3];
    var oldData = event.cellContext.datasource.data._rows[rowIndex][colName];

    if (newData === null) {
      newData = 0.00;
    }

    event.cellContext.datasource.data._rows[rowIndex][colName] = newData;

    var fyRowTotal = 0.00;
    fyRowTotal = Number(event.cellContext.datasource.data._rows[rowIndex]['fy_total'].toString().replace(/\,/g, ''))  - Number(oldData) + Number(newData);
  
    event.cellContext.datasource.data._rows[rowIndex]['fy_total'] = fyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    var allFyRowTotal = 0.00;

    allFyRowTotal = Number(event.cellContext.datasource.data._rows[rowIndex]['all_fy_total'].toString().replace(/\,/g, ''))  - Number(oldData) + Number(newData);
  
    event.cellContext.datasource.data._rows[rowIndex]['all_fy_total'] = allFyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  
    //update budgetSummaryArr
    var budgetSummaryRec = {};
    for(var budgetSummary of budgetSummaryArr){
      if(budgetSummary.period_fy === currentPeriod) {
          budgetSummaryRec = budgetSummary;
      }
    }

    var totalBudget = 0.00;
    totalBudget = Number(budgetSummaryRec.forecast_budget) - Number(oldData) + Number(newData);
   
    budgetSummaryRec.forecast_budget = totalBudget;

    //update cell directly with the new value
    var cellAllFyRowTotalId = 'cell_total_2' + rowIndex;
    $("#" + cellAllFyRowTotalId).text(allFyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));

    var cellRowTotalId = 'cell_total_4' + rowIndex;
    $("#" + cellRowTotalId).text(fyRowTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));

    $("#fy_total_budget").text(totalBudget.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));

    //update columnTotal
    var cellMonthTotalId = 'column_total_budget_' + colName;
    
    var monthTotal = Number($("#" + cellMonthTotalId).text().toString().replace(/\,/g, ''));
    monthTotal = monthTotal - Number(oldData) + Number(newData);
    
    $("#" + cellMonthTotalId).text(monthTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));

    return budgetSummaryRec;


  };

  PageModule.prototype.formatCurrency = function (amount) {
    var formattedamt = 0;

    if (!isNaN(amount)) {
      amount = Number.parseFloat(amount).toFixed(2);
      formattedamt = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    return formattedamt;

  };

  PageModule.prototype.getCuttedString = function (strOrig) {
    var str = "";
    str = strOrig.substring(0, 48);
    return str;
  };

  PageModule.prototype.setTileSelected = function(selectedPeriod, budgetSummaryArr){

      for(var i=0; i < budgetSummaryArr.length; i++){
        if (budgetSummaryArr[i].period_fy === selectedPeriod){
    
          document.getElementById('budgetDetBoxID' + i).classList.add('small-box-highlight');
          document.getElementById('budgetDetTileID' + i).classList.add('small-box-border-highlight');

        }else{
    
          document.getElementById('budgetDetBoxID' + i).classList.remove('small-box-highlight');
          document.getElementById('budgetDetTileID' + i).classList.remove('small-box-border-highlight');
        }
      }
  };

  PageModule.prototype.checkForDataChange = function(gridData, currentPeriod, origGridData){
      var return_flagdata = {};
      var task09XXDetails =  [] ;
      var updatedcount = 0;
      
      return_flagdata.updated_flag = false;
     
      if(gridData == undefined || gridData.data == undefined){
        return return_flagdata;
      }
  
      var updatedBudgetArr = gridData.data._rows;
      var orignalBudgetArr = origGridData.filter(it => (it.period_fy === currentPeriod));

      for(var i=0; i< updatedBudgetArr.length; i++){
        
        var updatedRow = updatedBudgetArr[i];
        var orignalRow = orignalBudgetArr.filter(it =>( (it.task_number === updatedRow.task_number)&&(it.expenditure_type_name === updatedRow.expenditure_type_name)));
  
        for (const period of periodFields){
           
           if (updatedRow[period.attribute] !== orignalRow[0][period.attribute]){
  
            if (/^09\.\d{2}(\.\d{2})?$/.test(updatedRow.task_number)) {
  
                task09XXDetails.push({
                                              FY: updatedRow.period_fy,
                                              task_number: updatedRow.task_number,
                                              task_name: updatedRow.task_name,
                                              task_expenditure_name: updatedRow.expenditure_type_name,
                                              period: period.attribute + "-"+updatedRow.period_fy.slice(2),
                                              updated_amount: updatedRow[period.attribute],
                                            });
                } else {
           
                }
                
              
            updatedcount++;
           
            }
          }
      }
  
      return_flagdata.task09XXDetails = task09XXDetails;
    
      if(updatedcount>0){
       
     return_flagdata.updated_flag = true;
      }
      return return_flagdata;
    };

  PageModule.prototype.getTaskExpObj = function (taskExpObj, userName) {
    var obj = {};
    obj.user_name = userName;
    obj.sub_project_number = taskExpObj.sub_project_number;
    obj.task_number = taskExpObj.task_number;
    obj.expenditure_type_id = taskExpObj.expenditure_type_id;
    
    return obj;
  };
  
  PageModule.prototype.getTaskExpDeletionObj = function (recId, userName) {
    var obj = {};
    obj.user_name = userName;
    obj.rec_id = recId;
    
    return obj;
  };

   PageModule.prototype.checkAutoApproved = function( currentData, previousData,lastPostedData) {
      var currentForecastAmount;
      var approvedForecastAmount;
      var lastPostedAmount;
      var autoapprove = true;
      
      var hasLastPostedData = Array.isArray(lastPostedData) && lastPostedData.length > 0;

    for (var i = 1; i < currentData.length; i++) {
        currentForecastAmount = Math.round(currentData[i].forecast_budget * 100) / 100;
        approvedForecastAmount = Math.round(previousData[i].wbs_budget * 100) / 100;

        if (!hasLastPostedData || !lastPostedData[i - 1]) {
    
            if (approvedForecastAmount >= currentForecastAmount) {
                continue;
            } else {
                autoapprove = false;
                break;
            }
        } else {
            lastPostedAmount = Math.round(lastPostedData[i - 1].forecast_budget * 100) / 100;

            if (lastPostedAmount === currentForecastAmount && approvedForecastAmount < currentForecastAmount) {
                continue;
            } else if (approvedForecastAmount < currentForecastAmount) {
                autoapprove = false;
                break;
            }
        }
    }
       return autoapprove;


  }; 


  PageModule.prototype.getBudgetDataToSave = function(username,action,comments,selectedPeriod,subProjectDetails, gridData, origGridData,ifpostError,assignedto,endorser_owner,escalator_owner) {

      var payload = {};

      if (ifpostError !== undefined && ifpostError!='' && ifpostError!=='false' && ifpostError!==false)
      {
         action= 'POSTEDERROR';
      }
      payload.action = action.toUpperCase();
      payload.sub_project_number = subProjectDetails.sub_project_number;
      payload.budget_type_id = 2; 
      payload.allocation_batch_number = subProjectDetails.allocation_batch_number;
      payload.version_id  = subProjectDetails.version_id;
      payload.status = subProjectDetails.status;
      payload.review_completed = subProjectDetails.review_completed;
      payload.assigned_to = assignedto; 
      payload.endorser_owner = endorser_owner;
      payload.escalator_owner = escalator_owner;
      payload.period_fy = selectedPeriod;
      payload.proj_comments = comments;
      payload.count = 0;
      payload.updated = 'N';
      payload.created_by = username;
      var rows = gridData.data._rows;
      payload.period_code = rows[0].period_code;

      if(payload.action === "SAVE"){
        
        var return_flagdata = this.checkForDataChange(gridData, selectedPeriod, origGridData);

        if(return_flagdata.updated_flag !== 'N'){
          payload.updated = 'Y';
          payload.data = rows;
        }
        
      } //SAVE
      
      return payload;
    };


    PageModule.prototype.getOPAForecastFlowSave = function(useremail,action,comments,selectedPeriod,subProjectDetails, currentData, previousData,assignedto,opaProcessId,autoapprove) {
      var opaPayload = {};
      var dataObject = {};
      var currentForecastAmount = 0;
      var previousForecastAmount = 0;
  
      for(var i= 1; i< currentData.length; i++){ 
      currentForecastAmount = currentForecastAmount + currentData[i].forecast_budget;
    }
    //This is allocated data,while we need to compare with previous fy data
      
        previousForecastAmount = Math.round((previousForecastAmount + previousData[0].wbs_budget) * 100) / 100;
  
    
      dataObject.emailAddress = useremail;
     
    
      if(action.toUpperCase() === "SUBMIT"){
       dataObject.action = 'CREATE_NEW';
      }
      else if (action.toUpperCase() === "ENDORSE"){
        dataObject.action = 'ENDORSED';
      }
      else if (action.toUpperCase() === "APPROVE"){
        dataObject.action = 'APPROVE';
      }
      else if (action.toUpperCase() === "REJECT"){
        dataObject.action = 'REJECT';
      }
      else if (action.toUpperCase() === "WITHDRAW"){
        dataObject.action = 'WITHDRAW';
        
      }
      dataObject.projectnumber = subProjectDetails.sub_project_number;
      dataObject.projectname = subProjectDetails.sub_project;
  
      dataObject.allocationBatchNumber = subProjectDetails.allocation_batch_number;
      dataObject.userID = assignedto;
    
      dataObject.autoApproved = autoapprove;
      dataObject.opaProcessId = opaProcessId;
      dataObject.forecastVersionName = subProjectDetails.version_name;
      opaPayload.dataObject = dataObject;
    

      return opaPayload;
    };
    


    PageModule.prototype.displaySaveBtn = function(task_status){
      if(task_status == undefined || task_status == null || task_status == "" || task_status == "Not Allocated" || task_status == "Draft" || task_status == "Posted" || task_status == "Withdrawn"||task_status == "PostedError"||task_status == "Rejected"){
        return true;
      }else{
        return false;
      }
    };

    PageModule.prototype.displaySubmitBtn = function(task_status, editflag){
      if(task_status == "Draft" && editflag === "Y" ){
        return true;
      }else{
        return false;
      }
    };

    PageModule.prototype.disableMakeItDefaultBtn = function(task_status, editflag){
      if(editflag !== "Y"){
        return true;
      }
      if(task_status == "Approved" ||task_status =="Submitted"){
        return true;
      }else{
        return false;
      }
    };
    
    //  Project Optimus 
    PageModule.prototype.displayEndorseBtn = function(task_status){
      if(task_status !== undefined && task_status == "Awaiting Endorsement" ){
        return true;
      }else{
        return false;
      }
    };

    PageModule.prototype.displayApproveRejectBtn = function(task_status){
      if(task_status !== undefined && (task_status == "Awaiting Approval" || task_status == "Escalated-Awaiting Approval") ){
        return true;
      }else{
        return false;
      }
    };

    PageModule.prototype.displayPostBtn = function(task_status){
      if(task_status !== undefined && (task_status == "Approved" ||task_status == "PostedError")){
        return true;
      }else{
        return false;
      }
    };

    
    PageModule.prototype.getSuccessMessageBasedOnAction = function(action){
      if( action!== undefined && action === "Submit" ){
        return "Submitted";
      }else  if( action!== undefined && action === "Approve" ){
        return "Approved";
      }else  if( action!== undefined && action === "Reject" ){
        return "Rejected";
      }else  if( action!== undefined && action === "Withdraw" ){
        return "Withdrawn";  
      }else  if( action!== undefined && action === "Endorse" ){
        return "Endorsed";  
      }else{
        "Saved";
      }
    };

    PageModule.prototype.getUserAccess = function(accessArr){
      var accessObj={};
      accessObj.pageAccess = 'N';
      accessObj.editFlag = 'N';
      accessObj.approveFlag = 'N';
      accessObj.postFlag = 'N';
      accessObj.endorseFlag = 'N';

      if(accessArr === undefined || accessArr === null || accessArr.length === 0){
        return accessObj;
      }

      for(const access of accessArr){
        if(access.action_allowed === "READ"){
          accessObj.pageAccess = 'Y';
        }else if(access.action_allowed === "EDIT"){
          accessObj.editFlag = 'Y';
        }else if(access.action_allowed === "APPROVE"){
          accessObj.approveFlag = 'Y';
        }else if(access.action_allowed === "POST"){
          accessObj.postFlag = 'Y';
        }else if(access.action_allowed === "ENDORSE"){
          accessObj.endorseFlag = 'Y';
        }
      }
      return accessObj;
    };

   PageModule.prototype.createPostData = function(subProjectSummary){

      var payload = {};
      payload.ProjectNumber = subProjectSummary.sub_project_number;
      payload.BudgetVersionName = subProjectSummary.version_name;
      return payload;
    };

  PageModule.prototype.launchMenu = function () {
    document.getElementById("menuOption").open();

  };

  PageModule.prototype.showBudgetAllocationDiv = function () {
    document.getElementById("budgetAllocationDiv").style.display="block";
    document.getElementById("historyTable").style.display="none";
    document.getElementById("commentTable").style.display="none";
  };

  PageModule.prototype.showCommentTable = function () {
   document.getElementById("commentTable").style.display="block";
   document.getElementById("historyTable").style.display="none";
  document.getElementById("budgetAllocationDiv").style.display="none";
  };

  PageModule.prototype.showHistoryTable = function () {
   document.getElementById("historyTable").style.display="block";
   document.getElementById("commentTable").style.display="none";
   document.getElementById("budgetAllocationDiv").style.display="none";
  };

  PageModule.prototype.createExportDataForecast = function (budgetSummaryArr, budgetDataArr, wbsBudgetDataArr) {

    var exportDataArr=[];

    if (budgetSummaryArr != undefined && budgetSummaryArr !== null && budgetSummaryArr !== "" && budgetDataArr != undefined && budgetDataArr !== null && budgetDataArr !== "")
    {
      if(budgetSummaryArr.length > 0 && budgetDataArr.length > 0){
        var firstFY = budgetSummaryArr[1].period_fy;

        var tempBudgetArr = budgetDataArr.filter(it => (it.period_fy === firstFY));
        for(const tempBudget of tempBudgetArr){
          //for each task expenditure
          var obj = {};
          
          obj["Task Number"] = tempBudget.task_number + '\t';
          obj["Task Name"]  = tempBudget.task_name;
          obj["Expenditure Type"]  = tempBudget.expenditure_type_name;
          
          //to calculate current wbs budget total on task level
          var task_budget_total = 0;
          if(wbsBudgetDataArr != undefined && wbsBudgetDataArr !== null && wbsBudgetDataArr !== "" && wbsBudgetDataArr.length > 0 ){
              for(var j=1; j < budgetSummaryArr.length; j++){
                var current_period_fy = budgetSummaryArr[j].period_fy;

                var fyTaskBudgetData = wbsBudgetDataArr.filter(it => (it.period_fy === current_period_fy && it.task_number === tempBudget.task_number && it.expenditure_type_id === tempBudget.expenditure_type_id));
                var fyTaskBudgetTotal = fyTaskBudgetData[0].jul + fyTaskBudgetData[0].aug + fyTaskBudgetData[0].sep + fyTaskBudgetData[0].oct 
                                      + fyTaskBudgetData[0].nov + fyTaskBudgetData[0].dec + fyTaskBudgetData[0].jan + fyTaskBudgetData[0].feb 
                                      + fyTaskBudgetData[0].mar + fyTaskBudgetData[0].apr + fyTaskBudgetData[0].may + fyTaskBudgetData[0].jun;

                task_budget_total = task_budget_total + fyTaskBudgetTotal;
              }
          }
          task_budget_total = task_budget_total + tempBudget.task_prior_cost;
          obj["Year-To-Date Cost"]  = tempBudget.task_current_fy_cost === 0 ? "" : tempBudget.task_current_fy_cost.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");;
          obj["Total Project Budget"]  = task_budget_total === 0 ? "" : task_budget_total.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); //budgetSummaryArr[1].wbs_budget;          
          obj["Total Project Contract"]  = "";
          obj["Prior Years Cost"]  = tempBudget.task_prior_cost === 0 ? "" : tempBudget.task_prior_cost.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");;
          //to calculate current fy cost

          for(var i=1; i < budgetSummaryArr.length; i++){
            var period_fy = budgetSummaryArr[i].period_fy;

            var fyTaskForecastData = budgetDataArr.filter(it => (it.period_fy === period_fy && it.task_number === tempBudget.task_number && it.expenditure_type_id === tempBudget.expenditure_type_id));
            var fyNum = fyTaskForecastData[0].mcal_year - 2000;
            var prevFyNum = fyNum - 1;
            obj['Jul-' + prevFyNum] = fyTaskForecastData[0].jul === 0 ? "" : fyTaskForecastData[0].jul.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Aug-' + prevFyNum] = fyTaskForecastData[0].aug === 0 ? "" : fyTaskForecastData[0].aug.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Sep-' + prevFyNum] = fyTaskForecastData[0].sep === 0 ? "" : fyTaskForecastData[0].sep.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Oct-' + prevFyNum] = fyTaskForecastData[0].oct === 0 ? "" : fyTaskForecastData[0].oct.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Nov-' + prevFyNum] = fyTaskForecastData[0].nov === 0 ? "" : fyTaskForecastData[0].nov.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Dec-' + prevFyNum] = fyTaskForecastData[0].dec === 0 ? "" : fyTaskForecastData[0].dec.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Jan-' + fyNum] = fyTaskForecastData[0].jan === 0 ? "" : fyTaskForecastData[0].jan.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Feb-' + fyNum] = fyTaskForecastData[0].feb === 0 ? "" : fyTaskForecastData[0].feb.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Mar-' + fyNum] = fyTaskForecastData[0].mar === 0 ? "" : fyTaskForecastData[0].mar.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Apr-' + fyNum] = fyTaskForecastData[0].apr === 0 ? "" : fyTaskForecastData[0].apr.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['May-' + fyNum] = fyTaskForecastData[0].may === 0 ? "" : fyTaskForecastData[0].may.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            obj['Jun-' + fyNum] = fyTaskForecastData[0].jun === 0 ? "" : fyTaskForecastData[0].jun.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

          }
          
          exportDataArr.push(obj);
        }
    
      }
    }

  return exportDataArr;
    
  }; 

    function dynamicSort(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        /* next line works with strings and numbers, 
         * and you may want to customize it to your needs
         */
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}


  PageModule.prototype.readFileContent = function(file) {
    var fileData = new Promise(function(resolve) {
      if (file) {
        var fileReader = new FileReader();
        fileReader.onload = function(fileReadEvent) {
          var readCSVData = fileReadEvent.target.result;
          resolve(readCSVData);
        };
        fileReader.readAsText(file);
      } else {
        resolve("false");
      }
    });
    return fileData;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.processFileContent = function (fileData, uploaded_by, transid, sub_project_number, origFileDataArr) {

    var fileDataArr = [];
    var finalObj = {};
    var startPos = 7;
    var rows = fileData.split("\n");
    var validFlag = 'Y';
    var errorMsg;
    var retData = {};
    retData.validFlag = validFlag;
    retData.errorMsg = errorMsg;
    retData.finalObj = finalObj;
    const d = new Date();
    var currmonth = d.getMonth() - 6;
    var junData = '';

    var rowDataHeader = this.parseRow(rows[0]);
      
       var  currFiscalYear = rowDataHeader[startPos];
     
         if ( rowDataHeader[startPos].substring( 4) == 'ul' )
      {
           currFiscalYear = Number(currFiscalYear.toString().substr(0,2))+1;
      }

      else
      {
           currFiscalYear = Number(rowDataHeader[startPos].substr(4) ) + 1 ;
      }


    for (var i = 1; i < rows.length ; i++) {

      var rowData = this.parseRow(rows[i]);
      if (rowData[0] !== undefined && rowData[0] !== null && rowData[0] !== '' && rowData[2] !== undefined && rowData[2] !== null && rowData[2] !== '') {

        for (var j = 0; j < 10; j++) {

          var filerowObj = {};

          filerowObj.BUDGET_PERIOD = 'FY' + (Number(currFiscalYear) + j);

          filerowObj.TASK_CODE = rowData[0].replace('\t','');
          filerowObj.EXPENDITURE_NAME = rowData[2];
          var origRowData = origFileDataArr.filter(it => (it["Task Number"].replace('\t','') === filerowObj.TASK_CODE.replace('\t','') && it["Expenditure Type"] === filerowObj.EXPENDITURE_NAME));



          for (const period of periodFields) {
            var k = period.value - 1;
            var periodValue = period.attribute.toUpperCase();

            filerowObj[periodValue] = rowData[startPos + k + j * 12];
            if (period.attribute === "jun" && filerowObj[periodValue] !== undefined && filerowObj[periodValue] !== null) {
              filerowObj[periodValue] = filerowObj[periodValue].replace('\r', '');
            }

            if (j === 0 && k < currmonth) {
              var fieldName;
              if (period.value < 7) {
                fieldName = period.label + '-' + (currFiscalYear - 1);
              } else {
                fieldName = period.label + '-' + currFiscalYear;
              }

              var origAmount = 0;
              if(origRowData[0] !== undefined && origRowData[0] !== null){
               
               origAmount = origRowData[0][fieldName] ? Number(origRowData[0][fieldName].toString().replace(/\,/g, '')) : 0;
              }
              
              var newAmount = filerowObj[periodValue] ? Number(filerowObj[periodValue].toString().replace(/\,/g, '')) : 0;
              if (origAmount !== newAmount) {
                validFlag = 'N';
                errorMsg = "Data cannot be updated for previous Months. Task: " + filerowObj.TASK_CODE + " Expenditure: " + filerowObj.EXPENDITURE_NAME;

                retData.validFlag = validFlag;
                retData.errorMsg = errorMsg;
                retData.finalObj = finalObj;
                return retData;
              }
            }

          }

          filerowObj.UPLOADED_BY = uploaded_by;
          filerowObj.TRANS_ID = transid;
          filerowObj.SUB_PROJECT_NUMBER = sub_project_number;
          filerowObj.BUDGET_TYPE_ID = 2;
          fileDataArr.push(filerowObj);

        }
      }
    }

    //finalObj.UPLOADED_BY = uploaded_by;
    finalObj.BUDGET_DATA_ARR = fileDataArr;

    retData.validFlag = validFlag;
    retData.errorMsg = errorMsg;
    retData.finalObj = finalObj;
    return retData;

  };



PageModule.prototype.parseRow = function(row) {
    var insideQuote = false,
      entries = [],
      entry = [];
    row.split('').forEach(function(character) {
      if (character === '"') {
        insideQuote = !insideQuote;
      } else {
        if (character == "," && !insideQuote) {
          entries.push(entry.join(''));
          entry = [];
        } else {
          entry.push(character);
        }
      }
    });
    entries.push(entry.join(''));
    return entries;
  };


  return PageModule;
});
