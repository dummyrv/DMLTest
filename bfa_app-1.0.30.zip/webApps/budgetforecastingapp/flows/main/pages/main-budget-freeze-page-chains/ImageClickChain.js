define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ImageClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const response2 = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/getBudgetFreezeBudgetFreezeJobLog',
      });

      const results = await ActionUtils.forEach(response2.body.items, async (item, index) => {

        if (response2.body.items[0].status === 'RUNNING') {
          $page.variables.IsJobRunning = true;
        } else {
          $page.variables.IsJobRunning = false;
        }
      }, { mode: 'serial' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.BudgetFreezeJobLogSDP,
        refresh: null,
      });
      
    }
  }

  return ImageClickChain;
});
