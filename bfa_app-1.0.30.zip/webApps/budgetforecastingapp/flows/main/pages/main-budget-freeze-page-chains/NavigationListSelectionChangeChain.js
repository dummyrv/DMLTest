define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class NavigationListSelectionChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.selection 
     */
    async run(context, { selection }) {
      const { $page, $flow, $application } = context;

      if ($page.variables.IsJobRunning === true) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Alert',
          message: 'Budget freeze job running, please try again after sometime.',
          type: 'info',
          displayMode: 'transient',
        });
      }

      const resetbtnstate = await $page.functions.resetbtnstate($page.variables.currentFreezeData.open_month);

      if (resetbtnstate === false) {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          summary: 'Alert!',
          message: 'Please reset the current unfreeze month.',
          type: 'info',
        });
      }

      $page.variables.showNavBottomBorder = true;

    if ($page.variables.currentFreezeData.open_all_flag === "Y") {
        $page.variables.switchVal = true;
      } else {
        $page.variables.switchVal = false;
      }
      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.submitFreezeData',
    '$page.variables.enableFreezeSubmitBtn',
    '$page.variables.enableUnFreezeSubmitBtn',
    '$page.variables.IsFreezeMonthSame',
    '$page.variables.IsFreezeMonthOld',
    '$page.variables.IsMonthOpen',
    '$page.variables.enableAllMonthBtn',
    '$page.variables.IsSwitchOn',
  ],
      });
    }
  }

  return NavigationListSelectionChangeChain;
});
