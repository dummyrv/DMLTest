define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application } = context;

      const valid = await $page.functions.validateoldfreezeMonth($page.variables.currentFreezeData.freeze_month, $page.variables.submitFreezeData.newFreezeMonth);

      const validatesamefreezeMonth = await $page.functions.validatesamefreezeMonth($page.variables.currentFreezeData.freeze_month, $page.variables.submitFreezeData.newFreezeMonth);

      $page.variables.enableFreezeSubmitBtn = false;
      $page.variables.IsFreezeMonthOld = valid;
      $page.variables.IsFreezeMonthSame = validatesamefreezeMonth;
    }
  }

  return SelectValueItemChangeChain;
});
