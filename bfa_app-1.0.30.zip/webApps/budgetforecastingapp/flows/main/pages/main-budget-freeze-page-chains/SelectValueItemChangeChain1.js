define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.IsMonthOpen',
  ],
      });

      const validateoldUnfreezeMonth = await $page.functions.validateoldUnfreezeMonth($page.variables.currentFreezeData.freeze_month, $page.variables.submitFreezeData.unFreezeMonth);

      if (validateoldUnfreezeMonth === true) {

        $page.variables.enableUnFreezeSubmitBtn = true;
        $page.variables.IsMonthOpen = validateoldUnfreezeMonth;
      } else {
        $page.variables.enableUnFreezeSubmitBtn = false;
      }
    }
  }

  return SelectValueItemChangeChain1;
});
