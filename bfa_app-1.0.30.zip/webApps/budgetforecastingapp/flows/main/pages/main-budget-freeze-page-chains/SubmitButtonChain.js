define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitButtonChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const freezeWarningDialogueClose = await Actions.callComponentMethod(context, {
        selector: '#freezeWarningDialogue',
        method: 'close',
      });

      await $application.functions.showLoading();

      const response = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/postBudgetFreezeFreezeSummary',
        body: $page.variables.submitFreezeData,
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          message: response.body.output,
          summary: 'Failure',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          displayMode: 'persist',
          type: 'confirmation',
          message: response.body.output,
        });

        await Actions.callChain(context, {
          chain: 'PageLoadChain',
        });
      }

      await $application.functions.hideLoading();
    }
  }

  return SubmitButtonChain;
});
