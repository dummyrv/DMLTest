define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageLoadChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/getBudgetFreezeCurrentFreezeData',
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'response2.statusText',
        });
      
        return;
      }

      $page.variables.currentFreezeData = response.body;

      if (response.body.open_all_flag === "Y") {
        $page.variables.switchVal = true;
        $page.variables.IsAllMonthOpen = true;
      } else {
        $page.variables.switchVal = false;
      }

      const response3 = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/getBudgetFreezeBudgetFreezeJobLog',
      });

      const results = await ActionUtils.forEach(response3.body.items, async (item, index) => {

        if (response3.body.items[0].status === 'RUNNING') {
          $page.variables.IsJobRunning = true;
        } else {
          $page.variables.IsJobRunning = false;
        }
      }, { mode: 'serial' });
    }
  }

  return PageLoadChain;
});
