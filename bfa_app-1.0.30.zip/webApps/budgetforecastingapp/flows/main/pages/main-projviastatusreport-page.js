define(["knockout", "ojs/ojpagingdataproviderview", "ojs/ojarraydataprovider","ojs/ojpagingcontrol","ojs/ojknockouttemplateutils"],
 function(ko, PagingDataProviderView, ArrayDataProvider, KnockoutTemplateUtils) {
  
  'use strict';

  var PageModule = function PageModule() {};
    var self = this;
  
    var cube = null;
    var dataArr = null;
    var distinctPeriodAr = [];
    var baseProjTableADP = [];
    var rowDataObj = {};
    var distinctPeriod = ['FY20','FY21'];
    var monthNamesArr = ['Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun'];

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.checkCurrVersionFlag = function (arg1) {
    alert("argument"+arg1);
  };


  PageModule.prototype.defaultYear=function (){
      var today = new Date();
      var year = today.getFullYear();
      var month = today.getMonth()+1;
      var startFY = year -2000;
      if( month > 6){
        year = year + 1;
      }
    
      return year;
    
    };
  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.readAndLoadLovsForDropDowns = function (commonSegmentRes,pastbasedperiodcodesRes,budgetStatusTypeRes,budgetTypeRes,responseType,budgetTypeList) {
    var authCodeArr=[];
     var iniCodeArr=[];
      var costCodeArr=[];
      var baseProjArr=[];

      var budgetStatusArr=[];
      var budgetTypeArr=[];
      var pastBasedPerCodeArr=[];
      var transactionTypeArr=[];

    var dataArr={};

    var selBudgetTypeByDefault;
    var selBudgetYearByDefault;

    if(responseType=="segementCode"){
    commonSegmentRes.forEach(function(item, index) {
          var tempObj = {};
          if(item.segment_name=="AUTHORITY CODE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          authCodeArr.push(tempObj);
          }
           else if(item.segment_name=="INITIATIVE CODE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          iniCodeArr.push(tempObj);
          }
           else if(item.segment_name=="COST CENTRE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          costCodeArr.push(tempObj);
          }
          else if(item.segment_name=="BASE PROJECT"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          baseProjArr.push(tempObj);
          }
          
        });
        dataArr.authcodeArray=authCodeArr;
       dataArr.inicodeArray=iniCodeArr;
       dataArr.costcodeArray=costCodeArr;
       dataArr.baseProjArray=baseProjArr;
    }
    else if(responseType=="budgetStatusType"){

         budgetStatusTypeRes.forEach(function(item, index) {
          var tempObj = {};
          tempObj.status = item.status;
          budgetStatusArr.push(tempObj);
        });


          var tempArr =[];
          budgetStatusTypeRes.forEach(function(item, index) {
                            tempArr.push(item.type);
                  });

          var uniqueTransTypes = [];
          $.each(tempArr, function(i, el){
              if($.inArray(el, uniqueTransTypes) === -1) uniqueTransTypes.push(el);
          });

        // var tempObj = {};
        // tempObj.type="All";
        // tempObj.description="All";
        // transactionTypeArr.push(tempObj);

          uniqueTransTypes.forEach(function(item, index) {
                    var tempObj = {};

                    
                      if(item=="WBS"){
                    tempObj.type = item;
                    tempObj.description="WBS Allocation";
                    transactionTypeArr.push(tempObj);
                      }else if(item=="CB"){
                    tempObj.type = item;
                    tempObj.description="EPM Allocation";
                    transactionTypeArr.push(tempObj);
                      }else if(item=="SP"){
                    tempObj.type = item;
                    tempObj.description="PFM Allocation";
                    transactionTypeArr.push(tempObj);
                      }

                  });


        dataArr.budgetStatuseArray=budgetStatusArr;
        dataArr.transactionTypeAray=transactionTypeArr;
    }
    else if(responseType=="pastBasedPeriodCode"){
         pastbasedperiodcodesRes.forEach(function(item, index) {
          var tempObj = {};
          tempObj.period_code = item.period_code;
          tempObj.period_name = item.period_name;
          pastBasedPerCodeArr.push(tempObj);
        });
         dataArr.pastBasedPerCodeArray=pastBasedPerCodeArr;
    }
    else if(responseType=="budgetType"){
         budgetTypeRes.forEach(function(item, index) {
          var tempObj = {};
          tempObj.budget_type_id = item.budget_type_id;
          tempObj.budget_type_name = item.budget_type_name;
          budgetTypeArr.push(tempObj);
          if(item.budget_type_name==budgetTypeList[Object.keys(budgetTypeList)[0]]){
            dataArr.selBudgetTypeByDefault=item.budget_type_id;
          }
        });
         dataArr.budgetTypeArray=budgetTypeArr;
    }

      
       
       
    

    return dataArr;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.test = function (arg1,arg2) {
    console.log("test");
   // alert("argument"+arg1.status+"-"+arg1.initiative_code+"-"+arg1.authority_code+"-"+arg1.cost_center+"-"+arg1.project_number);

   var deptArray =  [
                  {
                      slno: "40",
                      authority: "Administration1"
                   
                  } ,
                 {
                      slno: "40",
                      authority: "Administration2"
                   
                  } 
                
              ];
   
return deptArray;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.populateData = function (arg1) {
 
    var data={};
    var dataArr=[];
   
                var myJSON = {
                "slno":"0",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON1 = {
                "slno":"1",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON2 = {
                "slno":"2",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON3 = {
                "slno":"3",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON4 = {
                "slno":"4",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON5 = {
                "slno":"5",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON6 = {
                "slno":"6",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };
                var myJSON7 = {
                "slno":"7",
                "initiative":"1389 - Metro Bus",
                "projectNumber":"100074 - Metro Bus",
                "authority":"2020 - DOT Provision of Outputs",
                "subProjNum":"dummy",
                "costCenter":"2062 - Metro Bus Contracts",
                "version":"Revised Budgets 2020-21_v5",
                "status":"Received",
                "budgetType":"Controlling Budget",
                "budgetPeriod":"4444000",
                "comments":"test comments1",
                 "cbSbWbsProjObjData":[
                   {
                      "slno":"0",
                      "budgetType":"Controlling Budget",
                      "status":"Received",
                      "version":"Revised Budgets 2020-21_v5",
                      "subProjNum":"100074",
                      "FY21":"800",
                      "FY22":"800",
                      "FY23":"800",
                      "FY24":"890",
                      "FY25":"780",
                      "FY26":"990",
                      "FY27":"200",
                      "comments":"test comments1"
                   }, 
                   {
                      "slno":"1",
                      "budgetType":"Controlling Budget",
                      "status":"Phased",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.11",
                      "FY21":"700",
                      "FY22":"600",
                      "FY23":"500",
                      "FY24":"990",
                      "FY25":"380",
                      "FY26":"490",
                      "FY27":"600",
                      "comments":"test comments1"
                   },
                    {
                      "slno":"2",
                      "budgetType":"Controlling Budget",
                      "status":"Draft",
                      "version":"Revised Budgets 2020-21_v7",
                      "subProjNum":"100074.20",
                      "FY21":"300",
                      "FY22":"200",
                      "FY23":"300",
                      "FY24":"490",
                      "FY25":"580",
                      "FY26":"690",
                      "FY27":"700",
                      "comments":"test comments2"
                   }
                 ]
                };


dataArr.push(myJSON);
dataArr.push(myJSON1);
dataArr.push(myJSON2);
dataArr.push(myJSON3);
dataArr.push(myJSON4);
dataArr.push(myJSON5);
dataArr.push(myJSON6);
dataArr.push(myJSON7);


// var noOfPages=dataArr.length/2;
// var pages=[];
// for(var i=1;i<=noOfPages;i++){
//   pages.push(i);
// }

// data.dataArr=dataArr;
// data.
return dataArr;



  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.populateDataFromService = function (response, transType, status,headerConfigurations,budgetTypeList) {
    console.info("===> transaction type:" +transType);
    if(response.length > 0){
      $("#paginationTable").show();
      }
    var projStatusReporting = {};
    var foramttedArr = [];
    var mainHeaderArray = [];
    var index = 0;
    var subProject = "";
    var subProjStatus = "";
    var dataSourceTypeName = "";
    
    var level3HeaderObj = [];
    var tempDistinctPeriodArr = [...new Set(response.map(x => x.year))];
    tempDistinctPeriodArr.sort();

    var initiativeCodes = [...new Set(response.map(x => x.initiative_code))];
    initiativeCodes.forEach((itemi, index1) => {
        console.info("===> initiative code: " + itemi);
        var epmBaseProjArray = response.filter(it => it.initiative_code === itemi);

        var projCodeData = [...new Set(epmBaseProjArray.map(x => x.base_project_code))];
        projCodeData.forEach((item, index2) => {
            var projArr = epmBaseProjArray.filter(it => it.base_project_code === item);


            var authorityCodes = [...new Set(projArr.map(x => x.authority_code))];
            authorityCodes.forEach((item2, index3) => {
                var authorityArr = projArr.filter(it => it.authority_code === item2);

                var costCenterCodes = [...new Set(authorityArr.map(x => x.cost_center))];
                costCenterCodes.forEach((item5, index4) => {
                    var costcenterArr = authorityArr.filter(it => it.cost_center === item5);


                    var subProjs = [...new Set(costcenterArr.map(x => x.sub_project))];
                    var dataSourceType = [...new Set(costcenterArr.map(x => x.data_source))];

                    if (dataSourceType[0] === "CB") {
                      var level2HeaderObj = [];
                     
                        subProjs.forEach((item4, index5) => {
                            var subProjListArray = costcenterArr.filter(it => it.sub_project === item4);
                            var dataTypeList = [...new Set(subProjListArray.map(x => x.data_source))];
                            dataTypeList.forEach((item6, index6) => {
                                if (item6 == "CB") {
                                    var allocBatNumListArr = [...new Set(subProjListArray.map(it => it.allocation_batch_number))];
                                    allocBatNumListArr.sort();
                                    allocBatNumListArr.forEach((allocBatNum, index5) => {
                                        var mainHeaderobj = {};
                                        var subArray = [];


                                        var headerObj = {};
                                        headerObj.slno = Number(index5) + Number(index6);
                                        headerObj.budgetType =headerConfigurations.budgetType;
                                        headerObj.allocation_type = headerConfigurations.allocationType;
                                        headerObj.status = headerConfigurations.status;
                                        headerObj.version =headerConfigurations.version;
                                        headerObj.subProjNum =headerConfigurations.subProject;
                                        headerObj.comments = headerConfigurations.comments;
                                        headerObj.basePeriodName = headerConfigurations.budgetPeriod;
                                      level2HeaderObj[0] = headerConfigurations.allocationType;
                                      level2HeaderObj[1] = headerConfigurations.status;
                                      level2HeaderObj[2] = headerConfigurations.subProject;
                                      level2HeaderObj[3] = headerConfigurations.version;
                                        tempDistinctPeriodArr.forEach((year, index) => {
                                            headerObj[year] = year;
                                            level2HeaderObj.push(year);
                                        });
                                       
                                      



                                        var mainCBBudgetArr = subProjListArray.filter(it => it.allocation_batch_number === allocBatNum);



                                        index = index + 1;
                                        mainHeaderobj.slno = index;
                                        mainHeaderobj.initiative = mainCBBudgetArr[0].initiative_code + ' - ' + mainCBBudgetArr[0].initiative_name;
                                        mainHeaderobj.projectNumber = mainCBBudgetArr[0].base_project_code + ' - ' + mainCBBudgetArr[0].project_name;
                                        mainHeaderobj.authority = mainCBBudgetArr[0].authority_code + ' - ' + mainCBBudgetArr[0].authority_name;
                                        mainHeaderobj.subProjNum = "";
                                        mainHeaderobj.costCenter = mainCBBudgetArr[0].cost_center + ' - ' + mainCBBudgetArr[0].cost_center_name;
                                        mainHeaderobj.version = mainCBBudgetArr[0].version;
                                        mainHeaderobj.status = mainCBBudgetArr[0].status;
                                        mainHeaderobj.budgetType = mainCBBudgetArr[0].budget_type;
                                        console.log("issue CB if loop check " + itemi + " " + item + " " + item2 + " " + item5 + " " + item4 + " " + item6);
                                        var arrIndex = mainCBBudgetArr.findIndex(x => (x.year === "FY21"));
                                        mainHeaderobj.budgetPeriod = arrIndex >= 0 ? mainCBBudgetArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                                        // mainHeaderobj.budgetPeriod=subProjListArr.filter(it => it.year === "FY21")[0].budget_amount; 
                                        mainHeaderobj.comments = mainCBBudgetArr[0].comments;
                                        mainHeaderobj.basePeriodName = mainCBBudgetArr[0].base_period_name;
                                        var subObj = {};


                                        subObj.slno = Number(index5) + Number(index6);
                                        subObj.budgetType = mainCBBudgetArr[0].budget_type;
                                        subObj[headerConfigurations.allocationType] = "EPM Budget";
                                        subObj[headerConfigurations.status] = mainCBBudgetArr[0].status;
                                        subObj[headerConfigurations.version] = mainCBBudgetArr[0].version;
                                        //subObj.subProjNum=mainCBBudgetArr[0].base_project_code;
                                        subObj.comments = mainCBBudgetArr[0].comments;
                                        subObj.basePeriodName = mainCBBudgetArr[0].base_period_name;
                                        tempDistinctPeriodArr.forEach((year, index) => {
                                            // if(year=="FY21" || year=="FY22" || year=="FY23" || year=="FY24" || year=="FY25" || year=="FY26" || year=="FY27"){
                                            console.log("issue CB if loop check while adding sub " + itemi + " " + item + " " + item2 + " " + item5 + " " + item4 + " " + item6);
                                            var arrIndex = mainCBBudgetArr.findIndex(x => (x.year === year));
                                            subObj[year] = arrIndex >= 0 ? mainCBBudgetArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                                            //subObj[year]=subProjListArr.filter(it => it.year === year)[0].budget_amount;
                                            //}
                                        });
                                        subObj.level2HeaderObj = level2HeaderObj;
                                        subArray.push(subObj);

                                        var initiative = mainCBBudgetArr[0].initiative_code;
                                        var projectNumber = mainCBBudgetArr[0].base_project_code;
                                        var authority = mainCBBudgetArr[0].authority_code;
                                        var costCenter = mainCBBudgetArr[0].cost_center;



                                        //to get the sub projects using allocaiton_batch_num and parent_batch_num
                                        var subProjListArr = costcenterArr.filter(it => it.parent_batch_number === allocBatNum);
                                        var subProjs1 = [...new Set(subProjListArr.map(x => x.sub_project))];
                                        // to get specific sub proj
                                        subProjs1.forEach((subProj, index5) => {
                                            var subProjArr = subProjListArr.filter(it => it.sub_project === subProj);

                                            // to get wbsDataArr using allocaiton_batch_num and parent_batch_num
                                            var wbsDataArr = costcenterArr.filter(it => it.parent_batch_number == subProjArr[0].allocation_batch_number && it.sub_project === subProj);


                                            var subObj1 = {};
                                            subProject = "";
                                            subObj1.slno = Number(index5) + Number(index6);
                                            subObj1.budgetType = subProjArr[0].budget_type;
                                            subObj1[headerConfigurations.allocationType] = "PFM Budget";
                                            subObj1[headerConfigurations.status] = subProjArr[0].status;
                                            subObj1[headerConfigurations.version] = subProjArr[0].version;
                                            subObj1[headerConfigurations.subProject] = subProjArr[0].sub_project;
                                            subProject = subProjArr[0].sub_project;
                                            subObj1.comments = subProjArr[0].comments;
                                            subObj1.basePeriodName = subProjArr[0].base_period_name;
                                            tempDistinctPeriodArr.forEach((year, index) => {
                                                //   if(year=="FY21" || year=="FY22" || year=="FY23" || year=="FY24" || year=="FY25" || year=="FY26" || year=="FY27"){
                                                console.log("issue while adding subobj1 sp  " + itemi + " " + item + " " + item2 + " " + item5 + " " + item4 + " " + item6);
                                                var arrIndex = subProjArr.findIndex(x => (x.year === year));
                                                if(arrIndex >= 0){
                                                  console.log(subProjArr[arrIndex]['budget_amount']);
                                                }
                                                console.log();
                                                subObj1[year] = arrIndex >= 0 ? subProjArr[arrIndex]['budget_amount'] != undefined || subProjArr[arrIndex]['budget_amount'] != null ? subProjArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") :'0.00' : '0.00';
                                                //subObj[year]=subProjListArr.filter(it => it.year === year)[0].budget_amount;
                                                //  }
                                            });
                                            subObj1.initiative_code = initiative;
                                            subObj1.project_number = projectNumber;
                                            subObj1.authority_code = authority;
                                            subObj1.cost_center = costCenter;
                                            subArray.push(subObj1);



                                            if (wbsDataArr.length > 0) {
                                                var subObj2 = {};

                                                subObj2.slno = Number(index5) + Number(index6);
                                                subObj2.budgetType = wbsDataArr[0].budget_type;
                                                if(subObj2.budgetType == budgetTypeList[Object.keys(budgetTypeList)[0]]){
                                                  subObj2[headerConfigurations.allocationType]  = headerConfigurations['wbsBudget'];
                                                }
                                                else{
                                                  subObj2[headerConfigurations.allocationType] = headerConfigurations['wbsForecast'];
                                                }
                                                subObj2.status = wbsDataArr[0].status;
                                                subObj2.version = wbsDataArr[0].version;
                                                subObj2.subProjNum = wbsDataArr[0].sub_project;
                                                subObj2.comments = wbsDataArr[0].comments;
                                                subObj2.basePeriodName = wbsDataArr[0].base_period_name;
                                                tempDistinctPeriodArr.forEach((year, index) => {
                                                    // if(year=="FY21" || year=="FY22" || year=="FY23" || year=="FY24" || year=="FY25" || year=="FY26" || year=="FY27"){
                                                    console.log("issue while adding  wbs " + itemi + " " + item + " " + item2 + " " + item5 + " " + item4 + " " + item6);
                                                    var arrIndex = wbsDataArr.findIndex(x => (x.year === year));
                                                    subObj2[year] = arrIndex >= 0 ? wbsDataArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                                                    //subObj[year]=subProjListArr.filter(it => it.year === year)[0].budget_amount;
                                                    // }
                                                });
                                                subObj2.initiative_code = initiative;
                                                subObj2.project_number = projectNumber;
                                                subObj2.authority_code = authority;
                                                subObj2.cost_center = costCenter;
                                                subArray.push(subObj2);

                                            }


                                        });

                                        mainHeaderobj.cbSbWbsProjObjData = subArray;
                                        if((subProject != "" || subProject != undefined) && level2HeaderObj[headerConfigurations.subProject] ==  headerConfigurations.subProject){
                                           // level2HeaderObj[headerConfigurations.subProject] = headerConfigurations.subProject+"-"+subProject+"";
                                        }
                                        subProject = "";
                                        mainHeaderobj.level2HeaderObj = level2HeaderObj;
                                       // level2HeaderObj.length =0;
                                        mainHeaderArray.push(mainHeaderobj);

                                    });


                                }

                            });

                        });
                    }
                    else if (dataSourceType[0] === "SP") {
                      
                        var mainHeaderobj = {};
                        var subArray = [];
                        var init = "";
                        var cost = "";
                        var auth = "";
                        var prj = "";

                        // main header level information
                        index = index + 1;
                        mainHeaderobj.slno = index;
                        mainHeaderobj.initiative = costcenterArr[0].initiative_code + ' - ' + costcenterArr[0].initiative_name;
                        mainHeaderobj.projectNumber = costcenterArr[0].base_project_code + ' - ' + costcenterArr[0].project_name;
                        mainHeaderobj.authority = costcenterArr[0].authority_code + ' - ' + costcenterArr[0].authority_name;
                        mainHeaderobj.subProjNum = "";
                        mainHeaderobj.costCenter = costcenterArr[0].cost_center + ' - ' + costcenterArr[0].cost_center_name;
                        mainHeaderobj.version = costcenterArr[0].version;
                        mainHeaderobj.status = costcenterArr[0].status;
                        mainHeaderobj.budgetType = costcenterArr[0].budget_type;
                        console.log("issue CB if loop check " + itemi + " " + item + " " + item2 + " " + item5);
                        var arrIndex = costcenterArr.findIndex(x => (x.year === "FY21"));
                        mainHeaderobj.budgetPeriod = arrIndex >= 0 ? costcenterArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                        // mainHeaderobj.budgetPeriod=subProjListArr.filter(it => it.year === "FY21")[0].budget_amount; 
                        mainHeaderobj.comments = costcenterArr[0].comments;
                        mainHeaderobj.basePeriodName = costcenterArr[0].base_period_name;

                        // sub header level header info
                        var headerObj = {};
                        headerObj.slno = 0;
                        headerObj.budgetType = headerConfigurations.budgetType;
                      headerObj.allocation_type = headerConfigurations.allocationType;
                      headerObj.status = headerConfigurations.status;
                      headerObj.version =headerConfigurations.version;
                       headerObj.subProjNum =headerConfigurations.subProject;
                        headerObj.comments = headerConfigurations.comments;
                        headerObj.basePeriodName = headerConfigurations.budgetPeriod;
                        
                        tempDistinctPeriodArr.forEach((year, index) => {
                            headerObj[year] = year;
                            
                        });
                      

                        subProjs = [...new Set(costcenterArr.map(x => x.sub_project))];
                        subProjs.forEach((subProj, index5) => {
                            var subProjArr = costcenterArr.filter(it => it.sub_project === subProj);

                            // to get wbsDataArr using allocaiton_batch_num and parent_batch_num
                            // var wbsDataArr = costcenterArr.filter(it => it.parent_batch_number == subProjArr[0].allocation_batch_number);
                            var level2HeaderObj=[];
                              //level2HeaderObj.length = 0;
                             level2HeaderObj[0] = headerConfigurations.allocationType;
                                      level2HeaderObj[1] = headerConfigurations.status;
                                      level2HeaderObj[2] = headerConfigurations.subProject;
                                      level2HeaderObj[3] = headerConfigurations.version;
                            var subObj1 = {};

                            subObj1.slno = Number(index5);
                            subObj1.budgetType = subProjArr[0].budget_type;
                            subObj1[headerConfigurations.allocationType] = "PFM Budget";
                            subObj1[headerConfigurations.status] = subProjArr[0].status;
                            subObj1[headerConfigurations.version] = subProjArr[0].version;
                            subProject = subProjArr[0].sub_project;
                            subProjStatus = subProjArr[0].status;
                            subObj1[headerConfigurations.subProject+"-"+subProject+"-"+subProjStatus+"-"+subProjArr[0].initiative_code+"-"+subProjArr[0].base_project_code+"-"+subProjArr[0].authority_code+"-"+ subProjArr[0].cost_center] = subProjArr[0].sub_project;
                            subObj1.comments = subProjArr[0].comments;
                            subObj1.basePeriodName = subProjArr[0].base_period_name;
                            tempDistinctPeriodArr.forEach((year, index) => {
                               level2HeaderObj.push(year);
                                // if(year=="FY21" || year=="FY22" || year=="FY23" || year=="FY24" || year=="FY25" || year=="FY26" || year=="FY27"){
                                console.log("issue while adding subobj1 sp  " + itemi + " " + item + " " + item2 + " " + item5);
                                var arrIndex = subProjArr.findIndex(x => (x.year === year));
                               subObj1[year] = arrIndex >= 0 ? subProjArr[arrIndex]['budget_amount'] != undefined || subProjArr[arrIndex]['budget_amount'] != null ? subProjArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") :'0.00' : '0.00';
                                //subObj[year]=subProjListArr.filter(it => it.year === year)[0].budget_amount;
                                // }
                            });
                            subObj1.initiative_code = subProjArr[0].initiative_code;;
                            subObj1.project_number = subProjArr[0].base_project_code;
                            subObj1.authority_code = subProjArr[0].authority_code;
                            subObj1.cost_center = subProjArr[0].cost_center;
                            init =  subProjArr[0].initiative_code;
                            auth =  subProjArr[0].authority_code;
                            cost =  subProjArr[0].cost_center;
                            prj =  subProjArr[0].base_project_code;
                             if((subProject != "" || subProject != undefined) ){
                            level2HeaderObj[2] = headerConfigurations.subProject+"-"+subProject+"-"+subProjStatus+"-"+init+"-"+prj+"-"+auth+"-"+cost;
                                        }
                            subObj1["level2HeaderObj"] = level2HeaderObj;
                          
                            subArray.push(subObj1);
                            //subObj1.level2HeaderObj = {};
                           // level2HeaderObj.length = 0;




                           


                        });
                        
                        mainHeaderobj.cbSbWbsProjObjData = subArray;
                        //mainHeaderobj.level2HeaderObj = level2HeaderObj;
                       // level2HeaderObj.length = 0;
                        mainHeaderArray.push(mainHeaderobj);

                    }
                    else if (dataSourceType[0] === "WBS") {
                        
                        var mainHeaderobj = {};
                        var cbSbWbsProjObjData = {};
                        var subArray = [];
                        var subLevelArray = [];
                        var yearNumber, yearNumberFromPeriod_Name, monthName, monthNumber;
                        var total_budget_amount = 0;
                        var monthLevelArray = [];
                        // main header level information
                        index = index + 1;
                        mainHeaderobj.slno = index;
                        mainHeaderobj.initiative = costcenterArr[0].initiative_code + ' - ' + costcenterArr[0].initiative_name;
                        mainHeaderobj.projectNumber = costcenterArr[0].base_project_code + ' - ' + costcenterArr[0].project_name;
                        mainHeaderobj.authority = costcenterArr[0].authority_code + ' - ' + costcenterArr[0].authority_name;
                        mainHeaderobj.subProjNum = "";
                        mainHeaderobj.costCenter = costcenterArr[0].cost_center + ' - ' + costcenterArr[0].cost_center_name;
                        mainHeaderobj.version = costcenterArr[0].version;
                        mainHeaderobj.status = costcenterArr[0].status;
                        mainHeaderobj.budgetType = costcenterArr[0].budget_type;
                        console.log("issue CB if loop check " + itemi + " " + item + " " + item2 + " " + item5);
                        var arrIndex = costcenterArr.findIndex(x => (x.year === "FY21"));
                        console.log("========== arrIndex" +arrIndex);
                        mainHeaderobj.budgetPeriod = arrIndex >= 0 ? costcenterArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                        // mainHeaderobj.budgetPeriod=subProjListArr.filter(it => it.year === "FY21")[0].budget_amount; 
                        mainHeaderobj.comments = costcenterArr[0].comments;
                        mainHeaderobj.basePeriodName = costcenterArr[0].base_period_name;
                        //mainHeaderobj.period_name = costcenterArr[0].period_name;

                        // sub header level header info
                        var headerObj = {};
                        headerObj.slno = 0;
                    headerObj.budgetType = headerConfigurations.budgetType;
                      headerObj.allocation_type = headerConfigurations.allocationType;
                      headerObj.status = headerConfigurations.status;
                      headerObj.version =headerConfigurations.version;
                       headerObj.subProjNum =headerConfigurations.subProject;
                        headerObj.comments = headerConfigurations.comments;
                        headerObj.basePeriodName = headerConfigurations.budgetPeriod;
                      
                        tempDistinctPeriodArr.forEach((year, index) => {
                        headerObj[year] = year;
                        //level2HeaderObj.push(year);
                        });
                        //subArray.push({yearHeader: headerObj});
                        //console.log("=== year header added with key:" +JSON.stringify(subArray));
                        //subArray.push(headerObj);

                        var subHeaderObj = {};
                        /*subHeaderObj.allocation_type = "Allocation Type";
                        subHeaderObj.status = "Status";
                        //subHeaderObj.version = "Version";
                        subHeaderObj.subProjNum = "PFM Project";
                        subHeaderObj.month = "Month";
                        //subHeaderObj.years = [];
                        tempDistinctPeriodArr.forEach((year, index) => {
                            subHeaderObj[year] = year;
                        });
                        subLevelArray.push(subHeaderObj);*/

                        subProjs = [...new Set(costcenterArr.map(x => x.sub_project))];
                        subProjs.forEach((subProj, index5) => {
                        subHeaderObj[headerConfigurations.allocationType] = headerConfigurations.allocationType;
                        subHeaderObj[headerConfigurations.status] = headerConfigurations.status;
                        //subHeaderObj.version = "Version";
                        subHeaderObj[headerConfigurations.subProject] = headerConfigurations.subProject;
                        subHeaderObj.month = "Month";
                        
                        //subHeaderObj.years = [];
                        tempDistinctPeriodArr.forEach((year, index) => {
                            subHeaderObj[year] = year;
                               //level3HeaderObj.push(year);
                        });
                        subLevelArray.push(subHeaderObj);
                            var subProjArr = costcenterArr.filter(it => it.sub_project.toString() === subProj.toString());
                            //console.log("array being looped through for WBS:" +JSON.stringify(subProjArr));
                            //console.log("array being looped over for WBS length:" +subProjArr.length + " " +subProj);
                            subProjArr.forEach((subProject, index7) => {
                              var level2HeaderObj =  [];
                                yearNumber = (subProject.year).slice(-2);
                                //console.log("year num:" + yearNumber);
                                yearNumberFromPeriod_Name = (subProject.period_name).substring((subProject.period_name).indexOf('-') + 1);
                                //console.log("year number from period name:" +yearNumberFromPeriod_Name);
                                monthName = (subProject.period_name).substring(0, (subProject.period_name).indexOf('-'));
                                monthNumber = (new Date(Date.parse(monthName +" 1, 2012")).getMonth()+1);
                                //console.log("Month Number:" +monthNumber + " " +monthName);
                                monthLevelArray[subProject.year] = [];
                                if(monthNumber > 6){
                                  //console.log("Month to append:" +monthName + " " +(yearNumber-1));
                                  monthLevelArray.push(subProject.period_name);
                                }
                                else{
                                  //console.log("Month to append:" +monthName + " " +(yearNumber));
                                  monthLevelArray.push(subProject.period_name);
                                }
                                //console.log("Month level array:"  +monthLevelArray);
                                // if(yearNumber === yearNumberFromPeriod_Name){
                                //     console.log("Month to append:" +monthName);
                                // }
                            });


                            // to get wbsDataArr using allocaiton_batch_num and parent_batch_num
                            // var wbsDataArr = costcenterArr.filter(it => it.parent_batch_number == subProjArr[0].allocation_batch_number);

                            var subObj1 = {};
                            var level2HeaderObj=[];
                            var level3HeaderObj = [];

                            subObj1.slno = Number(index5);
                            subObj1.budgetType = subProjArr[0].budget_type;
                            
                                if(subObj1.budgetType == budgetTypeList[Object.keys(budgetTypeList)[0]]){
                                                  subObj1[headerConfigurations.allocationType]  = headerConfigurations['wbsBudget'];
                                                }
                                                else{
                                                  subObj1[headerConfigurations.allocationType] = headerConfigurations['wbsForecast'];
                                                }
                           // subObj1.allocation_type = "WBS Budget";
                            subObj1[headerConfigurations.status] = subProjArr[0].status;
                            subObj1[headerConfigurations.version] = subProjArr[0].version;
                           
                             
                            subObj1.comments = subProjArr[0].comments;
                            subObj1.basePeriodName = subProjArr[0].base_period_name;
                              level2HeaderObj[0] = headerConfigurations.allocationType;
                           level2HeaderObj[1] = headerConfigurations.status;
                              level2HeaderObj[2] = headerConfigurations.subProject;
                                 level2HeaderObj[3] = headerConfigurations.version;
                                  level3HeaderObj[0] = headerConfigurations.allocationType;
                            level3HeaderObj[1] = headerConfigurations.status;
                            level3HeaderObj[2] = headerConfigurations.subProject;
                            level3HeaderObj[3] ="month";
                                    //level2HeaderObj[4] = headerConfigurations.allocationType;
                            tempDistinctPeriodArr.forEach((year, index) => {
                              level3HeaderObj.push(year);
                                console.log("issue while adding subobj1 sp  " + itemi + " " + item + " " + item2 + " " + item5);
                                //var arrIndex = subProjArr.findIndex(x => (x.year === year));
                                //subObj1[year] = arrIndex >= 0 ? subProjArr[arrIndex]['budget_amount'].toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                                
                                //to make the total of budget amount of all the months of a FY
                                var subProjArrYearwise = subProjArr.filter(it => it.year === year && it.sub_project.toString() == subProj.toString());
                                console.log("sub project array filtered year wise length:" +subProjArrYearwise.length  +  " sub project array filtered year wise: " +JSON.stringify(subProjArrYearwise));
                                if (subProjArrYearwise.length) {
                                  total_budget_amount = subProjArrYearwise.reduce(function (prev, cur) {
                                      return prev + cur['budget_amount'];
                                  },0);
                                }
                                else{
                                  total_budget_amount = 0;
                                }
                                console.log("^^^^^^^^^^ total budget value of FY:" +total_budget_amount + "year:" +year);
                                subObj1[year] = total_budget_amount.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");   
                                level2HeaderObj.push(year);                             
                            });
                            subObj1.initiative_code = subProjArr[0].initiative_code;;
                            subObj1.project_number = subProjArr[0].base_project_code;
                            subObj1.authority_code = subProjArr[0].authority_code;
                            subObj1.cost_center = subProjArr[0].cost_center;
                            level2HeaderObj[2] = headerConfigurations.subProject+"-"+subProj+"-"+subProjArr[0].status+"-"+subProjArr[0].initiative_code+"-"+subProjArr[0].base_project_code+"-"+subProjArr[0].authority_code+"-"+subProjArr[0].cost_center;
                             subObj1[headerConfigurations.subProject+"-"+subProj+"-"+subProjArr[0].status+"-"+subProjArr[0].initiative_code+"-"+subProjArr[0].base_project_code+"-"+subProjArr[0].authority_code+"-"+subProjArr[0].cost_center] = subProj;
                            //subArray.push(subObj1);
                            subObj1.level2HeaderObj = level2HeaderObj;
                           
                             subObj1.level3HeaderObj = level3HeaderObj;
                            monthNamesArr.forEach((month, index) => {
                              var subObj2 = {};
                              var monthDataArr;
                              subObj2.slno = Number(index);
                             // subObj2.allocation_type = "WBS Budget";
                              /* if(subProjArr[0].budget_type == "Budget"){
                                                  subObj2[headerConfigurations.allocationType] = "WBS Budget";
                                                }
                                                else{
                                                  subObj2[headerConfigurations.allocationType] = "WBS Forecast";
                                                }
                                */                
                                if(subProjArr[0].budget_type == budgetTypeList[Object.keys(budgetTypeList)[0]]){
                                                  subObj2[headerConfigurations.allocationType]  = headerConfigurations['wbsBudget'];
                                                }
                                                else{
                                                  subObj2[headerConfigurations.allocationType] = headerConfigurations['wbsForecast'];
                                                }
                              subObj2[headerConfigurations.status] = subProjArr[0].status;
                              subObj2[headerConfigurations.subProject] = subProjArr[0].sub_project;
                              subObj2.years = [];
                              var yrs = [];

                              subObj2.month = month;
                              monthDataArr = subProjArr.filter(it => 
                              (it.period_name).substring(0, (it.period_name).indexOf('-')) === month && it.sub_project.toString() == subProj.toString()
                              );
                              console.log("Month wise filtered array:" +monthDataArr.length + " " +month);
                              if(monthDataArr.length > 0){
                                monthDataArr.forEach((monthData, index9) => {
                                  var yearObj = {};
                                  yearObj.year = monthDataArr[index9].year;
                                  yearObj.amount = monthDataArr[index9].budget_amount;
                                  
                                  var lngth = yrs.push(yearObj);
                                  
                                  //console.log("##################################### Year Obj: "+JSON.stringify(yearObj)+ "lenght: "+lngth);
                                  //(subObj2.years).push(yearObj);
                                  ///console.log("**************************** Month wise year data:" +JSON.stringify(yrs));
                                  subObj2.years = yrs;
                                  //var monthArrIndex = monthDataArr.findIndex(x => (x.year === monthDataArr[index9].year));
                                  //subObj2[monthDataArr[index9].year] = monthArrIndex >= 0 ? (monthDataArr[index9].budget_amount).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0.00';
                                  subObj2[monthDataArr[index9].year] = (monthDataArr[index9].budget_amount).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                });
                              }
                              else{
                                tempDistinctPeriodArr.forEach((year, index10) => {
                                  var yearObj = {};
                                  yearObj.year = year;
                                  yearObj.amount = '0.00';

                                  var lngth = yrs.push(yearObj);

                                  subObj2.years = yrs;
                                  subObj2[year] = '0.00';
                                });
                              }
                              subObj2.initiative_code = subProjArr[0].initiative_code;
                              subObj2.project_number = subProjArr[0].base_project_code;
                              subObj2.authority_code = subProjArr[0].authority_code;
                              subObj2.cost_center = subProjArr[0].cost_center;
                              subLevelArray.push(subObj2);
                              console.log("monthly data WBS:" +JSON.stringify(subLevelArray));

                            });

                            subObj1.months = subLevelArray;
                            subLevelArray = [];
                            subArray.push(subObj1);
                        });
                        mainHeaderobj.cbSbWbsProjObjData = subArray;
                        mainHeaderobj.level2HeaderObj = level2HeaderObj;
                        mainHeaderobj.level3HeaderObj = level3HeaderObj;
                        console.log("$$$$$$$$$$$$$$$$$$ data object final WBS:" +JSON.stringify(mainHeaderobj));
                        mainHeaderArray.push(mainHeaderobj);
                    }
                    dataSourceTypeName = dataSourceType[0];
                });
            });
        });
    });
    var dataobj = {};
    dataobj.mainHeaderArray = mainHeaderArray;
    
    dataobj.tempDistinctPeriodArr = tempDistinctPeriodArr;
    dataobj.data_source = dataSourceTypeName;
    return dataobj;

};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getPaginationDataProvider = function (showBudgetTableADP) {
    //console.info("========== Budget Table ADP" +JSON.stringify(showBudgetTableADP));
    var showBudgetTableArr = [];
    showBudgetTableArr = showBudgetTableADP.filter(it=>it.cbSbWbsProjObjData.length>0);    
    console.log("======= Budget Table Array" +JSON.stringify(showBudgetTableArr));
    //this.KnockoutTemplateUtils = KnockoutTemplateUtils;
    //this.pagingDataProvider = ko.observable(new PagingDataProviderView(showBudgetTableArr));
    var paginationDataProvider = new PagingDataProviderView(new ArrayDataProvider(showBudgetTableArr, { idAttribute: "slno" }));
    console.log("======= Paging Data Provider" +JSON.stringify(paginationDataProvider));
    //console.log("======= Paging Data Provider -> cbSbWbsProjObjData:" +JSON.stringify(paginationDataProvider.data.cbSbWbsProjObjData));
    return new PagingDataProviderView(new ArrayDataProvider(showBudgetTableArr, { idAttribute: "slno" }));
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.createExportData = function (exportData, dataSourceTypeName,headerConfigurations,tableHeaders) {
    console.log("&&&&&&&& data source type name in export data:" +dataSourceTypeName,exportData);
    var exportDataArr=[];
    var index=0;
    if (exportData != undefined && exportData !== null && exportData !== ""){
      if(exportData.length>0){
        if(dataSourceTypeName == undefined || dataSourceTypeName === "CB" || dataSourceTypeName === "SP"){
          exportData.forEach((item, index5) => {
                      var initiative= item.initiative;
                      var projectNumber=item.projectNumber;
                      var authority=item.authority;
                      var costCenter=item.costCenter;
                    
                      if(item.cbSbWbsProjObjData.length>0){
                          item.cbSbWbsProjObjData.forEach((item1, index5) => {
                            if(item1.subProjNum!="PFM Budget"){
                              var subProjectNo = Object.keys(item1).filter(function(obj){
                              return (obj.split("-")[0] == tableHeaders.subProject);
                          });
                          subProjectNo = subProjectNo[0] == undefined ? "": subProjectNo[0].split("-")[1];
                               // var subProjectNo = item1[tableHeaders.subProject];
                               if(subProjectNo == "" || subProjectNo == undefined){
                               subProjectNo = "NA";
                                 }
                              var obj={};
                              index=index+1;
                              obj.SlNo=index;
                              obj[headerConfigurations.initiative]=initiative;
                              obj[headerConfigurations.projectNumber]=projectNumber;
                              obj[headerConfigurations.authority]=authority;
                              obj[headerConfigurations.costCenter]=costCenter;
                              obj[headerConfigurations.budgetPeriod]=item1.basePeriodName;
                              obj[headerConfigurations.budgetType]=item1.budgetType;
                              obj[headerConfigurations.allocationType]=item1[tableHeaders.allocationType];
                              obj[headerConfigurations.status]=item1[tableHeaders.status];
                              obj[headerConfigurations.subProjectNumber]=subProjectNo+"\t";
                              obj[headerConfigurations.version]=item1[tableHeaders.version];
                              var keySet=Object.keys(item1);
                              // to fetch the dynamic year budget data
                              for(var i=0;i<keySet.length;i++){
                                if(keySet[i].startsWith("FY")){
                                  obj[keySet[i]] = item1[keySet[i]] !== "" ? item1[keySet[i]].toString() : '0.00';
                                  //obj[keySet[i]]=item1[keySet[i]].toString();
                                }
                              }
                              exportDataArr.push(obj);
                            }
                          });
                      }
          });
        }
        //else if(dataSourceTypeName === "WBS"){
        else{
          var subProj = "";
          var tempObj = {};
          console.log("export data",exportData);
          exportData.forEach((item, index5) => {
            if(item.cbSbWbsProjObjData.length>0){
              item.cbSbWbsProjObjData.forEach((item1, index5) => {
                var obj = {};
                var years = Object.keys(item["cbSbWbsProjObjData"][index5]).filter(function(element){
                      var ele = element.match(/FY/g);
                      return ele;   
                    });
                years.forEach((eleYear,index)=>{
                          
                   
                if(item1.months){
                  item1.months.forEach((item2, index6) => {
                    //subProj = item2[tableHeaders.subProject];
                    subProj = item2[tableHeaders.subProject];
                    if(subProj != tableHeaders.subProject){
                      // obj={};
                      index = index+1;
                       
                      
                   
                      if(item2.month != "Month"){
                        //obj.BUDGET_YEARS = years;
                       // obj.month = item2.month;
                        // to fetch the dynamic year budget data
                        var monthKeySet = Object.keys(item2);
                        tempObj[item2.month] = item2[eleYear] == undefined ? "0.00" : item2[eleYear];
                        /*for(var i=0;i<monthKeySet.length;i++){
                          if(monthKeySet[i].startsWith("FY")){
                           // obj[monthKeySet[i]] = item2[monthKeySet[i]].toString();
                          }

                          //console.log("*********object in export data:" +JSON.stringify(obj));
                        }*/
                        console.log(obj);
                        //exportDataArr.push(obj);
                        console.log("**********object pushed to export data:" ,obj,exportDataArr);
                      }
                      // if(item2.years.length > 0){
                      //   item2.years.forEach((item3, index7) => {
                      //     obj.BUDGET_PERIOD = item3.year;
                      //     obj.JUL = item3.amount;
                      //     obj.AUG = item3.amount;
                      //     obj.SEP = item3.amount;
                      //     obj.OCT = item3.amount;
                      //     obj.NOV = item3.amount;
                      //     obj.DEC = item3.amount;
                      //     obj.JAN = item3.amount;
                      //     obj.FEB = item3.amount;
                      //     obj.MAR = item3.amount;
                      //     obj.APR = item3.amount;
                      //     obj.MAY = item3.amount;
                      //     obj.JUN = item3.amount;

                      //   });
                      //   exportDataArr.push(obj);
                      // }
                      
                    }
                  });
                }
                    obj[headerConfigurations.initiative]=item.initiative;
                    obj[headerConfigurations.projectNumber]=item.projectNumber;
                   
                   obj[headerConfigurations.authority]=item.authority;
                   obj[headerConfigurations.costCenter]=item.costCenter;
                   obj[headerConfigurations.allocationType]=item1[tableHeaders.allocationType];
                    obj[headerConfigurations.budgetType]= item.budgetType;
                   obj[headerConfigurations.status] = item1[tableHeaders.status];
                    obj[headerConfigurations.version]= item1[tableHeaders.version];
                    obj[headerConfigurations.subProjectNumber] = subProj+"\t";         
                    obj[headerConfigurations.budgetPeriod] = eleYear;
                    obj  = {...obj,...tempObj};
                    exportDataArr.push(obj);
                    obj={};
                    tempObj={};
                 });
              });
            }
          });
        }
      }
    }
    console.log("**** export data array:" +JSON.stringify(exportDataArr));
    console.log(JSON.stringify(exportDataArr));
    return exportDataArr;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.createProjCtrlBudAmtDetData = function (searchResponseObjArr,initiative_code,authority_code,cost_center,project_number,budgetTypeList) {

  var projCtrlBudArr =[];
  var distinctPeriodAr =[];
  var dataObj={};

  var ctrlBudgetArr = searchResponseObjArr.filter(it => it.initiative_code===initiative_code && it.base_project_code==project_number && it.authority_code==authority_code && it.cost_center==cost_center && (it.data_source=="CB"));

  

  ctrlBudgetArr.forEach((item, index) => {
  var tempObj={};
   tempObj.SlNo =index;
   tempObj.authority_code=item.authority_code;
   tempObj.cost_center=item.cost_center;
   tempObj.cost_center_name=item.cost_center_name;
   tempObj.proj_amount=item.budget_amount;
   tempObj.proj_number=item.base_project_code;
   tempObj.year=item.year;
    tempObj.budget_type_id = item.budget_type == budgetTypeList[Object.keys(budgetTypeList)[0]] ? "1":"4";
   tempObj.budget_type_name = item.budget_type;
   projCtrlBudArr.push(tempObj);
  });


   var tempDistinctPeriodArr= [...new Set(searchResponseObjArr.map(x => x.year))]; 
        tempDistinctPeriodArr.sort();
       
        var objTotal = {};
        objTotal["attribute"] = 'All'; 
        objTotal["label"] = 'All';
        distinctPeriodAr.push(objTotal);

        tempDistinctPeriodArr.forEach((item, index) => {
            var obj = {};
            obj["attribute"] = item; 
            obj["label"] = item;
            distinctPeriodAr.push(obj);
        });

   dataObj.projCtrlBudArr = projCtrlBudArr;
   dataObj.periodList = distinctPeriodAr;
   dataObj.cost_center_name=ctrlBudgetArr[0].cost_center + ' - ' + ctrlBudgetArr[0].cost_center_name;
   dataObj.authority_name=ctrlBudgetArr[0].authority_code + ' - ' + ctrlBudgetArr[0].authority_name;
   dataObj.initiative_name=ctrlBudgetArr[0].initiative_code + ' - ' + ctrlBudgetArr[0].initiative_name;
   dataObj.project_name=ctrlBudgetArr[0].base_project_code + ' - ' + ctrlBudgetArr[0].project_name;
  return dataObj;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  PageModule.prototype.showLoaderDiv = function (arg1) {
     setTimeout(function(){
  document.getElementById("loader").style.display="block";
  document.getElementById("showData").style.display="none";
  },500);
  };


 /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.hideLoaderDiv = function (arg1) {
     setTimeout(function(){
  document.getElementById("loader").style.display="none";
  document.getElementById("showData").style.display="block";
  },500);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  PageModule.prototype.showNoDataDiv = function (arg1) {
     setTimeout(function(){
  document.getElementById("noData").style.display="block";
  document.getElementById("showData").style.display="none";
   $("#paginationTable").hide();
  },1000);
  };


 /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.hideNoDataDiv = function (arg1) {
     setTimeout(function(){
  document.getElementById("noData").style.display="none";
  document.getElementById("showData").style.display="block";
  },500);
  };

    /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
  PageModule.prototype.displayShowDataDiv = function (arg1) {
     setTimeout(function(){
  document.getElementById("noData").style.display="none";
  document.getElementById("showData").style.display="block";
  },500);
  };


 /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.hideShowDataDiv = function (arg1) {
     setTimeout(function(){
  document.getElementById("noData").style.display="block";
  document.getElementById("showData").style.display="none";
   },500);
  };
 
 /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.checkIfYearExists = function (tempDistinctPeriodArr,yearKey) {
    var status=true;
      tempDistinctPeriodArr.forEach((item, index) => {
           if(item===yearKey){
             status=false;
           }
        });

  return status;
  };



  /**
   *
   * @param {String} arg1
   * @return {String}
   */
//   PageModule.prototype.loadStatusDropDownAsPerTransSel = function (transType , statusArray) {

// var budgetStatusArr=[];
// var SP=['Phased','Allocated'];
// var WBS=['Draft','Submitted','Approved','Rejected','Withdrawn','Posted','PostingFailed','AdminRejected','PostedError'];
// var All=['Received','Phased','Allocated','Draft','Submitted','Approved','Rejected','Withdrawn','Posted','PostingFailed','AdminRejected','PostedError'];
   



//       if(transType=="CB")
//       {
//            var tempObj = {};
//           tempObj.status = "Received";
//           budgetStatusArr.push(tempObj);
//       }
//       else if(transType=="SP"){
//       for(var i=0;i<SP.length;i++){
//       var tempObj = {};
//           tempObj.status = SP[i];
//           budgetStatusArr.push(tempObj);
//           }
//       }
//       else if(transType=="WBS"){
//        for(var i=0;i<WBS.length;i++){
//       var tempObj = {};
//           tempObj.status = WBS[i];
//           budgetStatusArr.push(tempObj);
//           }
//       }
//       else if(transType=="All"){
//        for(var i=0;i<All.length;i++){
//       var tempObj = {};
//           tempObj.status = All[i];
//           budgetStatusArr.push(tempObj);
//           }
//       }

//       return budgetStatusArr;
//   };


  return PageModule;
});