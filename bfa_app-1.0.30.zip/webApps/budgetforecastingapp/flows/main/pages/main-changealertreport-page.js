define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojbootstrap', 'ojs/ojmodel',
  'ojs/ojcube',
  'ojs/ojconverter-number', 'ojs/ojknockouttemplateutils',
  'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider',
  'ojs/ojhtmlutils','ojs/ojdatacollection-utils',
  "ojs/ojarraydataprovider",
  "ojs/ojpagingdataproviderview","ojs/ojpagingcontrol",
  'ojs/ojdatagrid', 'ojs/ojknockout', 'ojs/ojtable', 'ojs/ojrowexpander'], 
  function(oj, ko, $, Bootstrap, Model, Cube, NumberConverter,
  KnockoutTemplateUtils, FlattenedTreeDataProviderView,
  ArrayTreeDataProvider, HtmlUtils, DataCollectionEditUtils,ArrayDataProvider,
  PagingDataProviderView,PagingControl
  ) {
  'use strict';
  var popUp;
  var currentPage = 0;
  var subProjectTei = 0;
  var lastTransType = "";
  var PageModule = function PageModule() {
  
    var self = this;
    var popup;
    this.KnockoutTemplateUtils = KnockoutTemplateUtils;
    var cube = null;
    var dataArr = null;
    var distinctPeriodAr = [];
    var baseProjTableADP = [];
    var rowDataObj = {};
    var distinctPeriod = ['FY20','FY21'];
  
    dataArr = [{
        "FY21" : 0,
        "FY22" : 0,
        "FY23" : 0,
        "FY24" : 0,
        "FY25" : 0,
        "FY26" : 0,
        "FY27" : 0,
        "project" : '200073 - High Capacity Metro Trains',
        "authority" : '3120 - DOT Additions to the Net Asset Base',
        "projectDisplay": '200073 - High Capacity Metro Trains',
        "authorityDisplay": '3120 - DOT Additions to the Net Asset Base',
        "costCenter": '1680 - High Capacity Metro Trains',
        "subProject": '200073.20 - HCMT & Depot Development',
        "budgetType": 'Controlling Status',
        "version": 'version1'
    },{
        "FY21" : 0,
        "FY22" : 0,
        "FY23" : 0,
        "FY24" : 0,
        "FY25" : 0,
        "FY26" : 0,
        "FY27" : 0,
        "project" : '200073 - High Capacity Metro Trains',
        "authority" : '3120 - DOT Additions to the Net Asset Base',
        "projectDisplay": '200073 - High Capacity Metro Trains',
        "authorityDisplay": '3120 - DOT Additions to the Net Asset Base',
        "costCenter": '1680 - High Capacity Metro Trains',
        "subProject": '200073.20 - HCMT & Depot Development',
        "budgetType": 'Forecast Status',
        "version": 'version2'
    },{
        "FY21" : 0,
        "FY22" : 0,
        "FY23" : 0,
        "FY24" : 0,
        "FY25" : 0,
        "FY26" : 0,
        "FY27" : 0,
        "project" : '200073 - High Capacity Metro Trains',
        "authority" : '3120 - DOT Additions to the Net Asset Base',
        "projectDisplay": '200073 - High Capacity Metro Trains',
        "authorityDisplay": '3120 - DOT Additions to the Net Asset Base',
        "costCenter": '1680 - High Capacity Metro Trains',
        "subProject": '200073.20 - HCMT & Depot Development',
        "budgetType": 'Contract Status',
        "version": 'version3'
    },{ 
        "FY21" : 0,
        "FY22" : 0,
        "FY23" : 0,
        "FY24" : 0,
        "FY25" : 0,
        "FY26" : 0,
        "FY27" : 0,
        "project" : '200073 - High Capacity Metro Trains',
        "authority" : '3120 - DOT Additions to the Net Asset Base',
        "projectDisplay": '200073 - High Capacity Metro Trains',
        "authorityDisplay": '3120 - DOT Additions to the Net Asset Base',
        "costCenter": '1680 - High Capacity Metro Trains',
        "subProject": '200073.22 - HCMT & Depot Development',
        "budgetType": 'Controlling Status',
        "version": 'version1'
    },{
        "FY21" : 0,
        "FY22" : 0,
        "FY23" : 0,
        "FY24" : 0,
        "FY25" : 0,
        "FY26" : 0,
        "FY27" : 0,
        "project" : '200073 - High Capacity Metro Trains',
        "authority" : '3120 - DOT Additions to the Net Asset Base',
        "projectDisplay": '200073 - High Capacity Metro Trains',
        "authorityDisplay": '3120 - DOT Additions to the Net Asset Base',
        "costCenter": '1680 - High Capacity Metro Trains',
        "subProject": '200073.22 - HCMT & Depot Development',
        "budgetType": 'Forecast Status',
        "version": 'version2'
    },{
        "FY21" : 0,
        "FY22" : 0,
        "FY23" : 0,
        "FY24" : 0,
        "FY25" : 0,
        "FY26" : 0,
        "FY27" : 0,
        "project" : '200073 - High Capacity Metro Trains',
        "authority" : '3120 - DOT Additions to the Net Asset Base',
        "projectDisplay": '200073 - High Capacity Metro Trains',
        "authorityDisplay": '3120 - DOT Additions to the Net Asset Base',
        "costCenter": '1680 - High Capacity Metro Trains',
        "subProject": '200073.22 - HCMT & Depot Development',
        "budgetType": 'Contract Status',
        "version": 'version3'
    }];
    
    var currencyOptions =
      {
        style: 'decimal',
        maximumFractionDigits: 2
      };
    this.currencyConverter = new NumberConverter.IntlNumberConverter(
        currencyOptions);
    
    function generateCube(dataArr, axes) {
      return new Cube.DataValueAttributeCube(dataArr, axes,distinctPeriodAr);
//          [{
//             attribute: 'FY21',
//             label: 'FY2021'
//           }, {
//             attribute: 'FY22',
//             label: 'FY2022'
//           },
//           {
//             attribute: 'FY23',
//             label: 'FY2023'
//           }, {
//             attribute: 'FY24',
//             label: 'FY2024'
//           },
//           {
//             attribute: 'FY25',
//             label: 'FY2025'
//           }, {
//             attribute: 'FY26',
//             label: 'FY2026'
//           },
//           {
//             attribute: 'FY27',
//             label: 'FY2027'
//           }
//         ]);
    }  
    var axes = [{
        axis: 0,
        levels: [
          {
            dataValue: true
          }
        ]
      },
      { axis: 1,
          levels: [
                { attribute: 'initiative' },
                { attribute: 'projectDisplay' },
                { attribute: 'authorityDisplay' },
                { attribute: 'costCenter' },
                { attribute: 'subProject' },
                { attribute: 'status' },
                { attribute: 'version' }] }
    ];
    
    function MyDataGridDataSource(data, options)
     {
       
         MyDataGridDataSource.superclass.constructor.call(this, data, options);
     }
     oj.Object.createSubclass(MyDataGridDataSource, oj.CubeDataGridDataSource, "oj.MyDataGridDataSource");
     MyDataGridDataSource.prototype.fetchHeaders = function(headerRange, callbacks, callbackObjects)
     {
         var callback = function(headerSet, headerRange) {          
            headerSet.getLabel = function(level){
              if(headerRange.axis == "column"){
                  if(level == 0)
                  return 'Period';
              }

             if (headerRange.axis == "row"){
               if(level == 0)
              return 'Initiative';
              else if(level == 1)
              return 'Project Number';
              else if (level == 2)
              return 'Authority Code';
              else if (level == 3)
              return 'Cost Center';
              else if (level == 4)
              return 'Sub Project';
              else if (level == 5)
              return 'Status';
              else if (level == 6)
              return 'Version';
              else
              return '';
            }

            return '';
            };
            callbacks.success.call(this, headerSet, headerRange);
         }
         MyDataGridDataSource.superclass.fetchHeaders.call(this, headerRange, {success: callback}, callbackObjects);
     };
     
    this.launchedFromCell = ko.observable('None launched yet');
    
    PageModule.prototype.myActionFunction = function (dataArr,authCode,costcenter,initCode,projNum) {
        //console.log(rowDataObj);
        console.log(dataArr,projNum,authCode,costcenter,initCode,projNum);
         var selectedProjList= dataArr.filter(it => (it.proj_number === projNum) && (it.authority_code === authCode) && (it.cost_center === costcenter));
        //return selectedProjList;
        console.log(selectedProjList);
        
        rowDataObj.selectedProjList = selectedProjList;
        rowDataObj.periodList = distinctPeriodAr;
    //    rowDataObj.costCenterNum = rowDataObj.costCenter.split('-')[0].trim();
     //   rowDataObj.initiativeCode = rowDataObj.initiative.split('-')[0].trim();
        return rowDataObj;
      };
      
      PageModule.prototype.assignTableData = function (tabelADPData) {
        baseProjTableADP = tabelADPData;
      };
     
    PageModule.prototype.menuBeforeOpenAction = function(event) {
      var target = event.detail.originalEvent.target;
      var transactionType;
      var isHeaderLabel = false;
      var data = {};
        var context = document.getElementById('projdatagrid').getContextByNode(target);
        if (context != null) {
          var rowData = context.datasource.data._rows;
          if (context.indexes != null) {
            this.launchedFromCell(context.indexes.row + ',' + context.indexes.column);
          } else if (context.index != null) {
            this.launchedFromCell(context.axis + ' header index ' + context.index);
          }
          if (context.axis == 'column' || (context.axis == 'row' && context.subId == 'oj-datagrid-header-label')) {
            isHeaderLabel = true;
          } else {
          if(context.level <=3) {
            transactionType = '';
            rowDataObj.subproject = '';
          } else {
            // transactionType = (rowData[context.index]['transactionType'] === 'SP' && !rowData[context.index]['subProject']) ? 'WBS' : rowData[context.index]['transactionType'];
            transactionType = rowData[context.index]['transactionType'];
            rowDataObj.subproject = rowData[context.index]['subProject'];
          }
          rowDataObj.project = rowData[context.index]['project'];
          rowDataObj.authority = rowData[context.index]['authority'];
          rowDataObj.projectName = rowData[context.index]['projectDisplay'];
          rowDataObj.authorityName = rowData[context.index]['authorityDisplay'];
          rowDataObj.costCenter = rowData[context.index]['costCenter'];
          rowDataObj.initiative = rowData[context.index]['initiative']; 
          rowDataObj.status = rowData[context.index]['status'];
//           var projArr = baseProjTableADP.filter(it => (it.proj_number === rowData
          var projArr = baseProjTableADP.filter(it => (it.proj_number === rowDataObj.project) && (it.authority_code === rowDataObj.authority))
          rowDataObj.amount = projArr.length ? projArr[0].proj_amount : 0;
          isHeaderLabel = false;
        }
        }
        data.transactionType = transactionType;
        data.isHeaderLabel = isHeaderLabel;
        return data;
//         console.log(rowDataObj);
    };
    
    PageModule.prototype.formatProjBaseDataGrid = function(response,responseData,flag,initCode,costCode,authCode,prjCode,budgetTypeList) {
      if(response == undefined || response == ''){
        $("#noDataContent").show();
      }
      else{
        $("#noDataContent").hide();
      }
       console.log("formatProjBaseDataGrid",new Date());
        console.log("======response====="+response,responseData,flag,"initcode"+initCode,"projcode"+prjCode,"costcode"+costCode,"authcode"+authCode);
        var budgetData;
        var foramttedArr = [];
        var intiArray = [];
        var projectArray = [];
        var subProjectArray = [];
        var costCenterArray = [];
        var authCodeArray = [];
        var controllingBudgetArray = [];
        
        var subProjectData;
        var wbsData;
        var controllingBudgetData;
        var controllingBudgetDataArray = [];
        //var 
        //response = response.slice(0, 10);
      if(flag != undefined){
        console.log(initCode,flag);
        if(initCode != undefined){
          responseData = responseData.filter(function(responseDataObj){
            return initCode == "" || initCode == "Show - All" || initCode == "Show" ? responseDataObj : responseDataObj.initiative_code == initCode;
          });

          console.log("after init",responseData,initCode);
              response = responseData;
        }
         if(costCode != undefined){
          responseData = responseData.filter(function(responseDataObj){
            return costCode == "" || costCode == "Show - All" || costCode == "Show" ? responseDataObj : responseDataObj.cost_center == costCode;
          });
              response = responseData;
              console.log(response,responseData,"after cost code",costCode);
        }
    
     if(authCode != undefined){
          responseData = responseData.filter(function(responseDataObj){
            return authCode == "" || authCode == "Show - All" || authCode == "Show" ? responseDataObj : responseDataObj.authority_code == authCode;
          });

          console.log("after authcode",responseData,authCode);
              response = responseData;
        }
         if(prjCode != undefined){
          responseData = responseData.filter(function(responseDataObj){
            return prjCode == "" || prjCode == "Show - All" || prjCode == "Show" ? responseDataObj : responseDataObj.base_project_code == prjCode;
          });
           console.log("after proj code",responseData,prjCode);
              response = responseData;
        }
        
      }
      
        console.log(response,responseData);
        var tempDistinctPeriodArr= [...new Set(response.map(x => x.year))]; 
        tempDistinctPeriodArr.sort();
        var initiativeCodes = [...new Set(response.map(x => x.initiative_code))];
        var data;
        var tempInitCodes = [...new Set(response.map(x => x.initiative_code))];
        var tempProjCodes = [...new Set(response.map(x => x.base_project_code))];
        var tempAuthCodes = [...new Set(response.map(x => x.authority_code))];
        var tempCostCtrCodes = [...new Set(response.map(x => x.cost_center))];
        
        var tempSubProjCodes = [...new Set(response.map(x => x.sub_project))];
        var tempdata;
        
         

       tempInitCodes.forEach((item1,item1Index) =>{
                 tempdata = response.filter((item1Obj)=>{
                                        return item1Obj.initiative_code == item1;
                                 });


                                 console.log("after init",item1,tempdata);
                  var distinctProjectcodes =  [...new Set(tempdata.map(x => x.base_project_code))];
                  console.log("distinct project  codes",distinctProjectcodes,tempdata);
                   
                  distinctProjectcodes.forEach((item2,itemIndex)=>{
                     data = tempdata;
                          data  = tempdata.filter(function(item2Obj){
                              return item2Obj.base_project_code == item2 &&  item2Obj.initiative_code == item1;
                          });
                  var distinctAuthCodes = [...new Set(data.map(x => x.authority_code))];
                  console.log("distinct auth codes",data,distinctAuthCodes);
                  distinctAuthCodes.forEach((item4,item4Index)=>{
                      data = tempdata;
                         data  = data.filter(function(item4Obj){
                              return item4Obj.authority_code == item4 && item4Obj.base_project_code == item2;
                          });
                 
                 var distinctCostCentreCodes =  [...new Set(data.map(x => x.cost_center))];
                 distinctCostCentreCodes.forEach((item5,item5Index)=>{
                      data = tempdata;
                   data  = data.filter(function(item5Obj){
                              return item5Obj.cost_center == item5 && item5Obj.authority_code == item4 && item5Obj.base_project_code == item2;
                          });
                 
                 // var distinctSubProjectCodes = [...new Set(data.map(x => x.sub_project))];
                 // console.log("distinct sub projects",distinctSubProjectCodes,data);
                  //distinctSubProjectCodes.forEach((item3,item3Index)=>{
                          data = data.filter(function(item3Obj){
                              return item3Obj.cost_center == item5 && item3Obj.authority_code == item4 && item3Obj.base_project_code == item2 ;
                          });
                          
                          controllingBudgetData = [];
                          controllingBudgetData = data.filter(function(cntrlObj){
                              return cntrlObj.transaction_type == "CB";
                          });
                          subProjectData = [];
                          subProjectData =  data.filter(function(cntrlObj){
                              return cntrlObj.transaction_type == "SP";
                          });

                          //var fcast = [];
                          var fcast = data.filter(function(cntrlObj){
                              return cntrlObj.transaction_type== "FB";
                          });

                          var contractData = data.filter(function(cntrlObj){
                              return cntrlObj.budget_type== "Contract Budget";
                          });
                          console.log("forecast data",fcast);

                          if(controllingBudgetData.length ==0){
                              controllingBudgetData.push({

                              });
                          }
                          var subCtr=0;
                          if(subProjectData.length == 0){
                            subProjectData.push({
                                  
                            });
                            subCtr++;
                          }
                          
                          var distinctSubProjectCodes = [...new Set(subProjectData.map(x => x.sub_project))];
                          //debugger;
                           
                          distinctSubProjectCodes.forEach((item3,item3Index)=>{
                            var tempData = subProjectData.filter((subBudgetData)=>{
                                        return subBudgetData.sub_project == item3;
                                     });  
                                     wbsData= [];

                            if(subCtr == 1){
                               wbsData = data.filter(function(cntrlObj){
                             return cntrlObj.transaction_type == "WBS";
                         });
                            }
                            else
                            {
                            wbsData = data.filter(function(cntrlObj){
                             return cntrlObj.transaction_type == "WBS" && cntrlObj.sub_project == item3;
                         });   
                            }
                          

                             var distinctWbsCodes = [...new Set(wbsData.map(x => x.sub_project))];
                             console.log("distinct wbs codes",distinctWbsCodes,item3,wbsData);
                             if(distinctWbsCodes.length ==0){
                               distinctWbsCodes = [...new Set(fcast.map(x => x.sub_project))];
                             }
                          var wbsArray   = [];
                          var wbsForeCastArr = [];
                          var wbsContractAarr = [];
                            //wbsData = [];
                            console.log(wbsData);
                         // wbsData = data.filter(function(cntrlObj){
                            //  return cntrlObj.transaction_type == "WBS" && cntrlObj.sub_project == item3;
                        //  });
                          console.log(wbsData,tempData,subProjectData,item3,data);
                          distinctWbsCodes.forEach((wbsItem,wbsIndex)=>{
                            
                               var tempData = wbsData.filter((subBudgetData)=>{
                                        return  subBudgetData.sub_project == wbsItem && (subBudgetData.budget_type == budgetTypeList[Object.key(budgetTypeList)[0]] || subBudgetData.budget_type == "TEI");
                                     });
                                     if(item3 != undefined){
                                       tempData = wbsData.filter((subBudgetData)=>{
                                        return  item3 == subBudgetData.sub_project && subBudgetData.sub_project == wbsItem && (subBudgetData.budget_type == budgetTypeList[Object.key(budgetTypeList)[0]] || subBudgetData.budget_type == "TEI");
                                     });
                                     }
                              console.log("fcast data",fcast,wbsItem);
                               var wbsForeCastData =  fcast.filter((subBudgetData)=>{
                                        return subBudgetData.sub_project == wbsItem && (subBudgetData.budget_type == budgetTypeList[Object.key(budgetTypeList)[1]] || subBudgetData.budget_type == "TEI");
                                     });

                               
                                     if(item3 != undefined){
                                       wbsForeCastData =  fcast.filter((subBudgetData)=>{
                                        return subBudgetData.sub_project == item3 && subBudgetData.sub_project == wbsItem && (subBudgetData.budget_type == budgetTypeList[Object.key(budgetTypeList)[1]] || subBudgetData.budget_type == "TEI");
                                     });
                                     }
                                 var contractDataObj = contractData.filter((subBudgetData)=>{
                                        return subBudgetData.sub_project == wbsItem && (subBudgetData.budget_type == budgetTypeList[Object.key(budgetTypeList)[2]] || subBudgetData.budget_type == "TEI");
                                     });
                                       if(item3 != undefined){
                                       contractDataObj =  contractData.filter((subBudgetData)=>{
                                        return subBudgetData.sub_project == item3 && subBudgetData.sub_project == wbsItem && (subBudgetData.budget_type == budgetTypeList[Object.key(budgetTypeList)[2]] || subBudgetData.budget_type == "TEI");
                                     });
                                     }
                                     console.log(item3,"wbs data",wbsData,"wbs item",wbsItem,tempData,"wbsforecastdata",wbsForeCastData);
                                  wbsArray.push({"key":wbsItem,"value":tempData});      
                                  wbsForeCastArr.push({"key":wbsItem,"value":wbsForeCastData});
                                  wbsContractAarr.push({"key":wbsItem,"value":contractDataObj});
                          });
                              
                                   // debugger;
                                     subProjectArray.push({"key":item3,"value":tempData,"wbsData":wbsArray,"wbsFcastData":wbsForeCastArr,"contactBudgetData":wbsContractAarr});
                          });
                         

                          
                           console.log("data=============",data,controllingBudgetData,subProjectData,item1,item2,item4,item5);

                         
                         // var subProject = item3 == undefined ? 'subproject'+item3Index : item3;
                            //item3 = item3 == undefined ? 'subproject'+item3Index : item3;
                         //   if(subProjectData.length > 0){
                         // subProjectArray.push({"value":subProjectData,"key":item3});
                          //  }
                            controllingBudgetDataArray.push({"controllingbudget":controllingBudgetData,"subProjectData":subProjectArray});
                         // controllingBudgetArray.push({"key":item5,"value":controllingBudgetData});
                          subProjectArray = [];
                           //console.log("end of sub project codes",subProjectData,item3);
                        // });
                        
                         costCenterArray.push({"projectName":data[0].base_project_code+"-"+data[0].project_name,"projCode":item2,"key":item5,"value":controllingBudgetDataArray,"key_name":data[0].cost_center_name,"version":data[0].version,"init_name":data[0].initiative_code +"-"+data[0].initiative_name ,"auth_name":data[0].authority_code+"-"+data[0].authority_name,"budget_type":data[0].budget_type});
                         controllingBudgetDataArray = [];
                   });
                            var ret = data.filter(function(retObj){
                                return retObj.base_project_code == item2;
                        });
                        console.log("ret",ret,subProjectData,item2);
                            if(ret.length > 0){
                              authCodeArray.push({"key":item4,"value":costCenterArray,"key_name":data[0].authority_name});
                            }
                             // costCenterArray = [];
                             
                         console.log("end of project codes===========",item2); 
                         });
                         projectArray.push({"key":item2,"value":authCodeArray,"key_name":data[0].project_name,"init_name":data[0].initiative_code +"-"+data[0].initiative_name ,"auth_name":data[0].authority_code+"-"+data[0].authority_name,"budget_type":data[0].budget_type});
                         authCodeArray = [];
                  });
             
             intiArray.push({"value":projectArray,"key":item1,"key_name":data[0].initiative_name});
             projectArray = [];
             console.log("end of init codes===========",item1);
       });
       console.log("final array ",costCenterArray);
      
      
       
      var retData = {};
      //costCenterArray = costCenterArray.slice(0,10);
    // intiArray = intiArray.slice(0,5);
      retData.intitArray = costCenterArray.slice(0,10);
      retData.mainData = costCenterArray;
      retData.responseData = response;
      retData.distinctFY = tempDistinctPeriodArr;
      console.log("end of init array",new Date());
      ////console.log("===> summary count: " + JSON.stringify(retData));                
      return retData;
      };
      

    PageModule.prototype.getLovData = function(response){
       console.log("get loav data",new Date(),response);
       
        var initOptionsArray = [];
        var authOptionsArray = [];
        var prjOptionsArray = [];
        var costCtrOptions = [];
        var initoptionsObj = {};
        var authoptionsObj = {};
        var costOptionsObj = {};
        var prjOptionsObj = {};
        var lastInitCode;
        var lastAuthCode;
        var lastCostCode;
        var lastPrjCode;
        var duplicateInitArr = [];
        var duplicateAuthArr = [];
        var duplicateCostArr = [];
        var duplicatePrjArr = [];
        var optionsObj={};
      optionsObj.code = "Show";
     optionsObj.description = " All";
     initOptionsArray.push(optionsObj);
     prjOptionsArray.push(optionsObj);
     costCtrOptions.push(optionsObj);
     authOptionsArray.push(optionsObj);

        response.forEach((item,itemIndex)=>{
          //console.log(initoptionsObj.code,item.);
            // ;
              if(duplicateInitArr.indexOf(item.initiative_code) == -1)
                 {
                   initoptionsObj.code = item.initiative_code;             
                   initoptionsObj.description = item.initiative_name;
                   lastInitCode = item.initiative_code;
                   duplicateInitArr.push(item.initiative_code);
                   initOptionsArray.push(initoptionsObj);
                   initoptionsObj = {};
              }
              
              if(duplicateAuthArr.indexOf(item.authority_code) == -1)
              {
                  authoptionsObj.code = item.authority_code;
               authoptionsObj.description= item.authority_name;
               duplicateAuthArr.push(item.authority_code);
               lastAuthCode = item.authority_code;
               authOptionsArray.push(authoptionsObj);
              authoptionsObj = {};
              }
              if(duplicatePrjArr.indexOf(item.base_project_code) == -1)
              {
                prjOptionsObj.code = item.base_project_code;
               prjOptionsObj.description = item.project_name;
               lastPrjCode = item.base_project_code;
               duplicatePrjArr.push(item.base_project_code);
               prjOptionsArray.push(prjOptionsObj);
              prjOptionsObj = {};
              }
             // console.log("duplicate check",lastCostCode,item.cost_center,itemIndex);
            if(duplicateCostArr.indexOf(item.cost_center) == -1)
            {
               console.log("duplicate check 1",lastCostCode,item.cost_center,itemIndex);
              costOptionsObj.code = item.cost_center ;
              costOptionsObj.description =  item.cost_center_name;
              costCtrOptions.push(costOptionsObj);
              duplicateCostArr.push(item.cost_center);
              costOptionsObj = {};
              lastCostCode = item.cost_center;
            }
              
        });
 initOptionsArray.sort(function(a, b) {
  return a.code > b.code;
});
prjOptionsArray.sort(function(a,b){
  return parseInt(a.code) - parseInt(b.code);
});

authOptionsArray.sort(function(a, b){
    return a.code - b.code;
});

costCtrOptions.sort(function(a,b){
  return a.code - b.code;
});
        console.log(authOptionsArray);
 //console.log();
        return   {"options" : {
        "initOptions":initOptionsArray,
        "authOptions":authOptionsArray,
        "prjOptions":prjOptionsArray,
        "costOptions":costCtrOptions
      }};
    };


 PageModule.prototype.getCounts = function(response,flag,initCode,prjCode,authCode,costCode){
console.log(response,flag,initCode,prjCode,authCode,costCode);
   if(flag != undefined){
     if(initCode != undefined){
          response = response.filter(function(responseDataObj){
            return initCode == "" || initCode == "Show - All" || initCode == "Show" ? responseDataObj : responseDataObj.initiative_code == initCode;
          });
             console.log(initCode,response);
          
        }
         if(costCode != undefined){
          response = response.filter(function(responseDataObj){
            return costCode == "" || costCode == "Show - All" || costCode == "Show" ? responseDataObj : responseDataObj.cost_center == costCode;
          });
              console.log(costCode,response);
        }
    
     if(authCode != undefined){
          response = response.filter(function(responseDataObj){
            return authCode == "" || authCode == "Show - All" || authCode == "Show" ? responseDataObj : responseDataObj.authority_code == authCode;
          });
 console.log(authCode,response);
        }
         if(prjCode != undefined){
          response = response.filter(function(responseDataObj){
            return prjCode == "" || prjCode == "Show - All" || prjCode == "Show" ? responseDataObj : responseDataObj.base_project_code == prjCode;
          });
           console.log(prjCode,response);
        }
   }
   console.log("counts",response,new Date());
    var budgetData;
        var foramttedArr = [];
        
        var tempDistinctPeriodArr= [...new Set(response.map(x => x.year))]; 
        tempDistinctPeriodArr.sort();
        var initiativeCodes = [...new Set(response.map(x => x.initiative_code))];
       console.log("counts",response,initiativeCodes,new Date());
        var cbNum = 0;
        var spNum = 0;
        var wbsNum = 0;
        var wbsFbNum = 0;
        var newActionNum = 0;

        initiativeCodes.forEach((itemi, index) => {
          //console.log("===> initiative code: " + itemi);
          var projCode = response.filter(it => it.initiative_code === itemi);
          var projCodeData = [...new Set(projCode.map(x => x.base_project_code))];
          projCodeData.forEach((item, index) => {
          var projArr = projCode.filter(it => it.base_project_code === item);
          var authorityCodes = [...new Set(projArr.map(x => x.authority_code))];
          authorityCodes.forEach((item2, index) => {
            var authorityArr = projArr.filter(it => it.authority_code === item2);
            var costCenterCodes = [...new Set(authorityArr.map(x => x.cost_center))];
            costCenterCodes.forEach((item5, index) => {
            var costcenterArr = authorityArr.filter(it => it.cost_center === item5);
            var subProjs = [...new Set(costcenterArr.map(x => x.sub_project))];
            subProjs.forEach((item4, index) => {
            var subProjListArr = costcenterArr.filter(it => it.sub_project === item4);
            var dataTypeList = [...new Set(subProjListArr.map(x => x.transaction_type))];
            dataTypeList.forEach((item6, index) => {
            var obj = {};
            var arrDataIndex = subProjListArr.findIndex(x => (x.transaction_type === item6));
            var arrTEIDataIndex = subProjListArr.findIndex(x => (x.transaction_type === item6) && (x.budget_type === 'TEI'));
            tempDistinctPeriodArr.forEach((item3, index) => {
                var arrIndex = subProjListArr.findIndex(x => (x.year === item3 && x.transaction_type === item6));
                obj[item3] = arrIndex >=0 ? subProjListArr[arrIndex]['budget_amount'] : 0;
            });
            obj["project"] = item;  
            obj["authority"] = item2;
            obj["projectDisplay"] = item; 
            obj["authorityDisplay"] = item2;
            obj["costCenter_code"] = item5;
            obj["subProject"] = item4;
            obj["initiative_code"] = itemi;
            obj["status"] = arrDataIndex >=0 ? subProjListArr[arrDataIndex]['status'] : 0;
            obj["version"] = arrDataIndex >=0 ? subProjListArr[arrDataIndex]['version'] : 0;
            obj["combinationID"] = arrDataIndex >=0 ? subProjListArr[arrDataIndex]['combination_id'] : 0;
            obj["transactionType"] = item6;
            obj["All"] = arrDataIndex >=0 ? subProjListArr[arrDataIndex]['total_budget'] : 0;
            obj["TEI"] = arrTEIDataIndex >=0 ? subProjListArr[arrTEIDataIndex]['budget_amount'] : 0;
            obj["newChildAction"] = arrDataIndex >=0 ? subProjListArr[arrDataIndex]['new_child_allocation'] : 0;
            if(item6 == "CB"){
              cbNum++;
            }else if(item6 == "SP"){
              spNum++;
            }else if(item6 == "WBS"){
              wbsNum++;
            }
            else if(item6 == "FB"){
              wbsFbNum++;
            }
            if(obj["newChildAction"] == "Y"){
              newActionNum++;
            }

            //console.log("===> obj: " + JSON.stringify(obj));
            foramttedArr.push(obj);
            });
            });
          });
          });
          });
        });
        var summaryCounts = {};
        summaryCounts.cb_number = cbNum;
        summaryCounts.sp_number = spNum;
        summaryCounts.wbs_number = wbsNum;
        summaryCounts.wbs_fb_number = wbsFbNum;
        summaryCounts.new_action_number = newActionNum;

         console.log("counts end",new Date());

      var retData = {};
      retData.summaryCounts = summaryCounts;
                    
      return retData;
      
      
 }
    PageModule.prototype.getCellClassName = function(cellContext) {
        //console.log(cellContext);
        var cellClassName = 'oj-helper-justify-content-right oj-read-only';
        return cellClassName;
    };
    
    PageModule.prototype.getRowHeaderStyleName = function(cellContext) {
        var cellClassName;
        var row = JSON.parse(cellContext.key);
        var rowData = cellContext.datasource.data._rows;
        if (cellContext.level === 3) {
             cellClassName = 'width:100px;font-weight:normal;font-size:0.857rem;height:40px;word-wrap:break-word;';
        } else if (cellContext.level === 6) {
             cellClassName = 'width:100px;font-weight:normal;font-size:0.857rem;height:55px;word-wrap:break-word;'; 
        } else if (cellContext.level === 5) {
          cellClassName = 'width:110px;font-weight:normal;font-size:0.857rem;'; 
           /*  if (rowData[cellContext.index].transactionType === 'CB') {
                cellClassName = 'width:100px;font-weight:normal;font-size:0.857rem;background-color: #dceff8;'; 
             } else if (rowData[cellContext.index].transactionType === 'SP') {
                cellClassName = 'width:100px;font-weight:normal;font-size:0.857rem;background-color: #dcf8eb;'; 
             } else if (rowData[cellContext.index].transactionType === 'WBS') {
               cellClassName = 'width:100px;font-weight:normal;font-size:0.857rem;background-color: #eff8dc;'; 
             }*/
        } else {
             cellClassName = 'width:100px;font-weight:normal;font-size:0.857rem;'; 
        }
        return cellClassName;
    };
    
    PageModule.prototype.getCellTemplate = function(cellContext) {
        var mode;
        //mode = cellContext.mode;
        mode = 'navigation';
        if (mode === 'edit') {
          return KnockoutTemplateUtils.getRenderer('editCellTemplate')(cellContext);
        } else if (mode === 'navigation') {
          return KnockoutTemplateUtils.getRenderer('cellTemplate')(cellContext);
        }
        return '';
    };

    PageModule.prototype.getRowHeaderTemplate = function(cellContext) {

        return KnockoutTemplateUtils.getRenderer('rowHeaderTemplate')(cellContext);
    };
    
    PageModule.prototype.formatProjBaseData = function(response) {
        //console.log(response);
        var resultArr = [];
        response.forEach(function(item, index) {
          var tempObj = {};
          tempObj.SlNo = index;
          tempObj.proj_number = item.proj_number;
          tempObj.authority_code = item.authority_code;
          tempObj.proj_amount = item.proj_amount;
          //debugger;
          tempObj.cost_center = item.cost_center;
          tempObj.cost_center_name = item.cost_center_name;
          resultArr.push(tempObj);
        });
        return resultArr;
      };

      PageModule.prototype.formatPeriodBasedProjDet = function(response) {
        //console.log(response);
        var resultArr = [];
        response.forEach(function(item, index) {
          var tempObj = {};
          tempObj.SlNo = index;
          tempObj.proj_number = item.proj_number;
          tempObj.authority_code = item.authority_code;
          tempObj.cost_center = item.cost_center;
          tempObj.proj_amount = item.proj_amount;
          tempObj.cost_center_name = item.cost_center_name;
          tempObj.year = item.year;
          tempObj.budget_type_id = item.budget_type_id;
          tempObj.budget_type_name = item.budget_type_name;
          resultArr.push(tempObj);
        });
        return resultArr;
      };

      PageModule.prototype.getPeriodProjBaseData = function(periodBasedProjDet, projNum, authCode, costcenter) {
        var selectedProjList= periodBasedProjDet.filter(it => (it.proj_number === projNum) && (it.authority_code === authCode) && (it.cost_center === costcenter));
        return selectedProjList;
      };
      
     PageModule.prototype.searchProjNum = function(projNumSrchTxt, projDataGrid) {
        var projData;
        var arry = [];
        var foramttedArr =[];
        var x = document.getElementById("projdatagrid");
        // var y = document.getElementById("projdatagrid2");
        var filtered = [];
        if ((projNumSrchTxt !== -1) && (projNumSrchTxt !== '-1') && (projNumSrchTxt.length >0) && projDataGrid) {
          var arry = projNumSrchTxt;
          for(var arr in projDataGrid.data._rows){
            for(var filter in arry){
                if(projDataGrid.data._rows[arr].combinationID == arry[filter] ){
                    filtered.push(projDataGrid.data._rows[arr]);
                  }
            }
          }
          foramttedArr = filtered;
        }
        // //console.log(filtered);
        // var foramttedArr = projDataGrid.data._rows.filter(it => it.project.includes(projNumSrchTxt));
        if (foramttedArr.length) {
          // x.style.display = "block";
          // y.style.display = "none";
          cube = generateCube(foramttedArr, axes); 
          projData = new MyDataGridDataSource(cube); 
        } 
        // else {
        //   x.style.display = "none";
        //   y.style.display = "block";
        // }
                          
        return projData;
     };
     
     PageModule.prototype.resetData= function() {
       var x = document.getElementById("projdatagrid");
      //  var y = document.getElementById("projdatagrid2");
       x.style.display = "block";
       y.style.display = "none";  
     };

     PageModule.prototype.menuOpenAction= function() {
       //console.log('menu open');  
     };

    PageModule.prototype.getPerioddata = function(data,fyYear){
       console.log("data",data);
       var temp = {};
       var all = 0;
      if(data.length == 0){
        return [];
      }
      else
      {
        var tei = data.filter(function(obj){
                return obj.budget_type == "TEI";
        });
        /*if(data[0].sub_project == "200073.25"){
          debugger;
        }*/
        console.log("tei obj",tei,tei.length);
        lastTransType = data[0].transaction_type;
        if(tei.length > 0){
        temp["TEI"] = tei[0]["budget_amount"];
         if(tei[0].transaction_type == "SP")
        {
          subProjectTei = tei[0]["budget_amount"];
        }
        }
        else
        {
        if(subProjectTei != 0 && (data[0].transaction_type == "WBS" || data[0].transaction_type == "FB")){
          temp["TEI"] = subProjectTei;
        }
        if((lastTransType == "WBS" || lastTransType == "FB") && (data[0].transaction_type == "SP" || data[0].transaction_type == "CB")){
          subProjectTei = 0;
         // temp["TEI"] = "0";
        }
        if(data[0].transaction_type == "SP" || data[0].transaction_type == "CB"){
           temp["TEI"] = "0";
        }
        //temp["TEI"] = "0";
        }

        var newDataAlert = data.filter(function(obj){
                return obj.new_child_allocation == "Y";
        });
        console.log("new data alert",newDataAlert);
       if(newDataAlert.length > 0){
           temp["new_child_allocation"] = newDataAlert[0].new_child_allocation;
       }
       else{
         temp["new_child_allocation"] = "N";
       }
        
       var previosFYData = data.filter(function(obj){
                return obj.year == "0";
       });
       console.log(previosFYData,"previous year data");
       if(previosFYData.length > 0){
       temp["previousTotal"] = previosFYData[0].budget_amount;
       }
       else
       {
         temp["previousTotal"] = "0";
       }
       //////////////end of previous year amount calc///////////
     var totalBudget = data.filter(function(obj){
                return obj.budget_type != "TEI"; 
       });
      totalBudget = totalBudget.filter(function(obj){
                return obj.year != "0"; 
       });
        
       console.log("total data",totalBudget);
       
       temp["ALL"] = totalBudget[0] == undefined ? "0":totalBudget[0].total_budget;
       temp["version"] = totalBudget[0] == undefined ? data[0].version : totalBudget[0].version;
        temp["status"] =  totalBudget[0] == undefined ?  data[0].status: totalBudget[0].status;
      }
    var fetchFirst = data[0];

  var periodArray = [];
  console.log(fyYear);
    if(fyYear != undefined){
      periodArray  = fyYear;
    }
   else{
     periodArray = ["FY21","FY22","FY23","FY24","FY25","FY26","FY27","FY28","FY29","FY30","FY31"];
   }
      console.log("dataof oth",data[0]);
      /*if(periodArr != undefined){
          //periodArray = periodArr;
      }*/
    
    var tempArray = [];
    tempArray.push(data[0].total_budget);
    tempArray.push(data[0].total_budget);
   
    //temp["new_child_allocation"] = data[0].new_child_allocation;
   
    temp["budget_type"] = data[0].budget_type;
    temp["transaction_type"] = data[0].transaction_type;
    
    temp["authority_code"] = data[0].authority_code;
    temp["cost_center"] = data[0].cost_center;
    temp["initiative_code"] = data[0].initiative_code;
    temp["initiative_name"] = data[0].initiative_name;
    temp["authority_name"] = data[0].authority_name;
    temp["project_name"] = data[0].project_name;
    temp["cost_center_name"] = data[0].cost_center_name;
    temp["base_project_code"] = data[0].base_project_code;
    temp["subproject"] = data[0].sub_project == undefined ? "":data[0].sub_project;
    temp["subproject"] = data[0].sub_project == undefined ? "":temp["subproject"].split(".")[0]+"-"+temp["subproject"].split(".")[1];
    temp["id"] = data[0].allocation_batch_number+data[0].status+temp["subproject"];
    for(var i=0;i<periodArray.length;i++)
    {
        var ret = data.filter(function(retObj){
          return retObj.year == periodArray[i].fy_name && retObj.budget_type != "TEI";
        });
        if(ret.length == 0){
          temp[periodArray[i].fy_name] = "0";
          tempArray.push({
		"initiative_code": "",
		"initiative_name": "",
		"authority_code": "",
		"authority_name": "",
		"base_project_code": "",
		"project_name": "",
		"cost_center": "",
		"cost_center_name": "",
		"sub_project": "",
		"combination_id": "",
		"sub_project_name": "",
		"budget_type": "",
		"year": periodArray[i].fy_name,
		"base_period_name": "",
		"budget_amount": "0",
		"status": "",
		"status_date": "",
		"version": "",
		"business_unit": "",
		"project_start_date": "",
		"allocation_batch_number": "",
		"new_child_allocation": "",
		"transaction_type": "",
		"data_source": "",
		"total_budget": ""
	});
        }
        else{
          tempArray.push(ret[0]);
          //all = all + (ret[0].budget_amount == undefined || ret[0].year == "0"  ? 0 : ret[0].budget_amount);
          temp[periodArray[i].fy_name] = ret[0].budget_amount == undefined ? "0": ret[0].budget_amount;
           temp["allocation_batch_number"] = ret[0].allocation_batch_number;
           temp["sub_project"] = ret[0].sub_project;
          // temp["base_project_code"] = ret[0].base_project_code;
        }
    }

   
 
    var tempDataArray = [];
     console.log("temp array",tempArray,temp);
    tempDataArray.push(temp);
     console.log("temp array",tempArray,tempDataArray);
     return tempDataArray;

    };
    
    
    
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.openMenu = function (event,id) {
    console.log("event",event,JSON.stringify(id),id.data,id);
    //event.preventDefault();
              document.getElementById("myMenu"+id).open();

  };

 PageModule.prototype.printLog = function(data,data1){
   console.log(data,data1);
  
 };

PageModule.prototype.getLovDataOptions = function (commonSegmentRes,type) {
     

    var dataArr = {};
    var budgetTypeArr = [];
    var pastBasedPerCodeArr = [];
    var authCodeArr=[];
     var initCodeArr=[];
      var costCodeArr=[];
      var baseProjArr=[];
      var statusArr = [];
      var transactionTypeArr = [];
      
  
  if(type == 'status'){
        commonSegmentRes.forEach((item,itemIndex)=>{
                if(item.type)
                statusArr.push(item.type);
        });
            var uniqueTransTypes = [];
          $.each(statusArr, function(i, el){
              if($.inArray(el, uniqueTransTypes) === -1) uniqueTransTypes.push(el);
          });

          uniqueTransTypes.forEach(function(item, index) {
                    var tempObj = {};

                    
                      if(item=="WBS"){
                  //  tempObj.type = item;
                   // tempObj.description="WBS Allocation";
                   // transactionTypeArr.push(tempObj);
                      }else if(item=="CB"){
                    tempObj.type = item;
                    tempObj.description="EPM Allocation";
                    transactionTypeArr.push(tempObj);
                      }else if(item=="SP"){
                    tempObj.type = item;
                    tempObj.description="PFM Allocation";
                    transactionTypeArr.push(tempObj);
                      }

                  });
     dataArr.statusArray = transactionTypeArr;

  }else
  {
    commonSegmentRes.forEach(function(item, index) {
          var tempObj = {};
          if(item.segment_name=="AUTHORITY CODE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          authCodeArr.push(tempObj);
          }
           else if(item.segment_name=="INITIATIVE CODE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          initCodeArr.push(tempObj);
          }
           else if(item.segment_name=="COST CENTRE"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          costCodeArr.push(tempObj);
          }
          else if(item.segment_name=="BASE PROJECT"){
          tempObj.segment_name = item.segment_name;
          tempObj.code = item.code;
          tempObj.description = item.description;
          baseProjArr.push(tempObj);
          }
          
        });
    
        dataArr.authcodeArray=authCodeArr;
       dataArr.initcodeArray=initCodeArr;
       dataArr.costcodeArray=costCodeArr;
       dataArr.baseProjArray=baseProjArr;
  }
       return dataArr;
     
  };


  PageModule.prototype.getHeaderModule = function(periodArr){
     var tempArr = ["Allocation type","All","TEI","Status","Version"];
     return tempArr.concat(periodArr);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  var popup = "";
  PageModule.prototype.showTitle = function (id,data) {
    console.log(data,id);
     if(data == undefined){
      popup.close();
return;
  }
  
       
       console.log(data);
       popup = document.getElementById("headerPopup"+data);
       popup.open("#"+data);
  };

  /** 
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.calculateListHeight = function (dataArr) {
    console.log("calc heigt",new Date());
    console.log(dataArr.length);
     $("#pagination :input").attr('readonly',true);
     $("#pagination :input").attr('disabled',true);
    //$("#backBtn").removeClass("oj-lg-hide oj-md-hide");
    if(dataArr.length == 0){
      $(".collapseComponent").hide();
      $("#pagination").hide();
      $("#listview").css("height","0px");
      return false;
    }
     $("#pagination").show();
    if(dataArr.length < 7){
       $("#listview").css("height","auto");
       return false;
    }
    
    var height = window.screen.availHeight - ($("header[role=banner]").height() + $("#level1flex").height() + $("#header").height() + $("footer").height());
    height = height - 80;
    $("#listview").height(height+"px");
    console.log("height adjusted-----------------"+height, new Date());
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.collapseCompress = function (arg1) {
    if($("#collapseCompText").text() == 'Collapse All')
    {
      $("#collapseCompText").text("Compress All");
      $("oj-collapsible").attr("expanded","true");
      $("#collapseCompIcon").removeClass(" vb-icon-plus").addClass(" vb-icon-minus");
      
    }
    else{
       $("#collapseCompText").text("Collapse All");
       $("oj-collapsible").attr("expanded","false");
       $("#collapseCompIcon").removeClass(" vb-icon-minus").addClass(" vb-icon-plus");
    }
  };
    /**
   *
   * @param {String} arg1
   * @return {String}
   */
  
 PageModule.prototype.getpagingModule = function(dataArr){
  var pagingDataProvider = new PagingDataProviderView(new ArrayDataProvider(dataArr, { idAttribute: 'key' }));
 /* pagingDataProvider.addEventListener('page', (event) => {
       var currentPage = event.detail.page;
       var previousPage = event.detail.previousPage;
     });*/

    

     return pagingDataProvider;
 };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.getRestMoreData = function (dataArr,pageNo) {
    var firstInd ="";
    var lastInd = "";
    if(pageNo == 'Next Page'){
      pageNo = currentPage + 1;
      if(dataArr.length <=10){
        pageNo = 1;
      }
    }
    if(pageNo == 'Previous Page'){
      console.log(currentPage,pageNo);
      if(currentPage == 0 || currentPage == 1){
        //return false;
          pageNo = currentPage = 1;
      }
      else
      {
        pageNo = pageNo == 0 ? 0 : currentPage - 1;
      }
    }
    if(pageNo == 'First Page'){
      pageNo = currentPage = 1;
    }
   
    
    
     if(pageNo == 'Last Page'){
      var total  = dataArr.length;
      console.log(total);
      total = total%10;
      console.log(total);
      firstInd = dataArr.length - total;
      lastInd = dataArr.length;
      currentPage =Math.ceil((dataArr.length/10));
    }
    else
    {
 console.log(pageNo);
    pageNo = pageNo.toString().replace(/(\r\n|\n|\r|\D)/gm, "");
    currentPage  = parseInt(pageNo);
   
     firstInd = pageNo == 0 ? 0 :  parseInt((pageNo-1)+'0');
     lastInd = parseInt(pageNo+'0');
    }
    console.log(firstInd,lastInd,pageNo,currentPage);
    dataArr = dataArr.slice(firstInd,lastInd);
    return dataArr;

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.exportData = function (data,fyYear,callBackFn,formatCurFn,headerConfigurations,tableHeaders) {
    var exportDataArr = [];
    var exportObj = {};
    data.forEach((level1,level1Index)=>{

              level1.value.forEach((level2,level2Index)=>{

                       var controllingBudget = level2.controllingbudget;
                    var retData =   callBackFn(controllingBudget,fyYear);
                    if(retData.length >0 && retData[0].initiative_code != undefined){
                       exportObj = {};
                     	exportObj[headerConfigurations.initiative] = retData[0].initiative_code +" - "+ retData[0].initiative_name;
                     exportObj[headerConfigurations.authority]  = retData[0].authority_code +" - "+ retData[0].authority_name;
                      exportObj[headerConfigurations.costCenter]  = retData[0].cost_center+" - "+ retData[0].cost_center_name;
                      exportObj[headerConfigurations.projectNumber]  = retData[0].base_project_code+" - "+retData[0].project_name;
                      exportObj[headerConfigurations.allocationType]  = tableHeaders['epmBudget'];
                    exportObj[headerConfigurations.status]  = retData[0].status;
                      exportObj[headerConfigurations.version]  = retData[0].version;
                   exportObj[headerConfigurations.subProjectNumber]  = "NA";
                      exportObj[headerConfigurations.teiAmount]   = formatCurFn(retData[0].TEI);
                    exportObj[headerConfigurations.all]  = formatCurFn(retData[0].ALL);
                     exportObj[headerConfigurations.prioryears]  = formatCurFn(retData[0].previousTotal);
                      exportObj[fyYear[0].fy_name] = formatCurFn(retData[0][fyYear[0].fy_name]);
                      exportObj[fyYear[1].fy_name] = formatCurFn(retData[0][fyYear[1].fy_name]);
                      exportObj[fyYear[2].fy_name] = formatCurFn(retData[0][fyYear[2].fy_name]);
                      exportObj[fyYear[3].fy_name] = formatCurFn(retData[0][fyYear[3].fy_name]);
                      exportObj[fyYear[4].fy_name] = formatCurFn(retData[0][fyYear[4].fy_name]);
                      exportObj[fyYear[5].fy_name] = formatCurFn(retData[0][fyYear[5].fy_name]);
                      exportObj[fyYear[6].fy_name] = formatCurFn(retData[0][fyYear[6].fy_name]);
                      exportObj[fyYear[7].fy_name] = formatCurFn(retData[0][fyYear[7].fy_name]);
                      exportObj[fyYear[8].fy_name] = formatCurFn(retData[0][fyYear[8].fy_name]);
                      exportObj[fyYear[9].fy_name] = formatCurFn(retData[0][fyYear[9].fy_name]);
                      exportDataArr.push(exportObj);
                     
                    }
                       var subProjectBudget = level2.subProjectData;

                      subProjectBudget.forEach((subProject,subProjectIndex)=>{
                        if(subProject.key != undefined){
                             var subProjectData = subProject.value;
                             retData =   callBackFn(subProjectData,fyYear);
                      if(retData.length > 0 && retData[0].status != undefined){
                      exportObj = {};
                      exportObj = {};
                     	exportObj[headerConfigurations.initiative] = retData[0].initiative_code +" - "+ retData[0].initiative_name;
                     exportObj[headerConfigurations.authority]  = retData[0].authority_code +" - "+ retData[0].authority_name;
                      exportObj[headerConfigurations.costCenter]  = retData[0].cost_center+" - "+ retData[0].cost_center_name;
                      exportObj[headerConfigurations.projectNumber]  = retData[0].base_project_code+" - "+retData[0].project_name;
                      exportObj[headerConfigurations.allocationType]  = tableHeaders['pfmBudget'];
                    exportObj[headerConfigurations.status]  = retData[0].status;
                      exportObj[headerConfigurations.version]  = retData[0].version;
                   exportObj[headerConfigurations.subProjectNumber]  = subProject.key+"\t";
                      exportObj[headerConfigurations.teiAmount]   = formatCurFn(retData[0].TEI);
                    exportObj[headerConfigurations.all]  = formatCurFn(retData[0].ALL);
                     exportObj[headerConfigurations.prioryears]  = formatCurFn(retData[0].previousTotal);
                      exportObj[fyYear[0].fy_name] = formatCurFn(retData[0][fyYear[0].fy_name]);
                      exportObj[fyYear[1].fy_name] = formatCurFn(retData[0][fyYear[1].fy_name]);
                      exportObj[fyYear[2].fy_name] = formatCurFn(retData[0][fyYear[2].fy_name]);
                      exportObj[fyYear[3].fy_name] = formatCurFn(retData[0][fyYear[3].fy_name]);
                      exportObj[fyYear[4].fy_name] = formatCurFn(retData[0][fyYear[4].fy_name]);
                      exportObj[fyYear[5].fy_name] = formatCurFn(retData[0][fyYear[5].fy_name]);
                      exportObj[fyYear[6].fy_name] = formatCurFn(retData[0][fyYear[6].fy_name]);
                      exportObj[fyYear[7].fy_name] = formatCurFn(retData[0][fyYear[7].fy_name]);
                      exportObj[fyYear[8].fy_name] = formatCurFn(retData[0][fyYear[8].fy_name]);
                      exportObj[fyYear[9].fy_name] = formatCurFn(retData[0][fyYear[9].fy_name]);
                      exportDataArr.push(exportObj);
                      }
                        }
                     

                      var wbsData = subProject.wbsData;

                      retData =   callBackFn(wbsData,fyYear);
                       if(retData.length > 0){
                         exportObj = {};
                       exportObj = {};
                     	exportObj[headerConfigurations.initiative] = retData[0].initiative_code +" - "+ retData[0].initiative_name;
                     exportObj[headerConfigurations.authority]  = retData[0].authority_code +" - "+ retData[0].authority_name;
                      exportObj[headerConfigurations.costCenter]  = retData[0].cost_center+" - "+ retData[0].cost_center_name;
                      exportObj[headerConfigurations.projectNumber]  = retData[0].base_project_code+" - "+retData[0].project_name;
                      exportObj[headerConfigurations.allocationType]  = "WBS Budget";
                    exportObj[headerConfigurations.status]  = retData[0].status;
                      exportObj[headerConfigurations.version]  = retData[0].version;
                   exportObj[headerConfigurations.subProjectNumber]  = "NA";
                      exportObj[headerConfigurations.teiAmount]   = formatCurFn(retData[0].TEI);
                    exportObj[headerConfigurations.all]  = formatCurFn(retData[0].ALL);
                     exportObj[headerConfigurations.prioryears]  = formatCurFn(retData[0].previousTotal);
                      exportObj[fyYear[0].fy_name] = formatCurFn(retData[0][fyYear[0].fy_name]);
                      exportObj[fyYear[1].fy_name] = formatCurFn(retData[0][fyYear[1].fy_name]);
                      exportObj[fyYear[2].fy_name] = formatCurFn(retData[0][fyYear[2].fy_name]);
                      exportObj[fyYear[3].fy_name] = formatCurFn(retData[0][fyYear[3].fy_name]);
                      exportObj[fyYear[4].fy_name] = formatCurFn(retData[0][fyYear[4].fy_name]);
                      exportObj[fyYear[5].fy_name] = formatCurFn(retData[0][fyYear[5].fy_name]);
                      exportObj[fyYear[6].fy_name] = formatCurFn(retData[0][fyYear[6].fy_name]);
                      exportObj[fyYear[7].fy_name] = formatCurFn(retData[0][fyYear[7].fy_name]);
                      exportObj[fyYear[8].fy_name] = formatCurFn(retData[0][fyYear[8].fy_name]);
                      exportObj[fyYear[9].fy_name] = formatCurFn(retData[0][fyYear[9].fy_name]);
                      exportDataArr.push(exportObj);
                       }
                      

                            var foreCastData = subProject.wbsFcastData;

                      retData =   callBackFn(foreCastData,fyYear);
                       if(retData.length > 0){
                         exportObj = {};
                     exportObj = {};
                     	exportObj[headerConfigurations.initiative] = retData[0].initiative_code +" - "+ retData[0].initiative_name;
                     exportObj[headerConfigurations.authority]  = retData[0].authority_code +" - "+ retData[0].authority_name;
                      exportObj[headerConfigurations.costCenter]  = retData[0].cost_center+" - "+ retData[0].cost_center_name;
                      exportObj[headerConfigurations.projectNumber]  = retData[0].base_project_code+" - "+retData[0].project_name;
                      exportObj[headerConfigurations.allocationType]  = "WBS Forecast";
                    exportObj[headerConfigurations.status]  = retData[0].status;
                      exportObj[headerConfigurations.version]  = retData[0].version;
                   exportObj[headerConfigurations.subProjectNumber]  = "NA";
                      exportObj[headerConfigurations.teiAmount]   = formatCurFn(retData[0].TEI);
                    exportObj[headerConfigurations.all]  = formatCurFn(retData[0].ALL);
                     exportObj[headerConfigurations.prioryears]  = formatCurFn(retData[0].previousTotal);
                      exportObj[fyYear[0].fy_name] = formatCurFn(retData[0][fyYear[0].fy_name]);
                      exportObj[fyYear[1].fy_name] = formatCurFn(retData[0][fyYear[1].fy_name]);
                      exportObj[fyYear[2].fy_name] = formatCurFn(retData[0][fyYear[2].fy_name]);
                      exportObj[fyYear[3].fy_name] = formatCurFn(retData[0][fyYear[3].fy_name]);
                      exportObj[fyYear[4].fy_name] = formatCurFn(retData[0][fyYear[4].fy_name]);
                      exportObj[fyYear[5].fy_name] = formatCurFn(retData[0][fyYear[5].fy_name]);
                      exportObj[fyYear[6].fy_name] = formatCurFn(retData[0][fyYear[6].fy_name]);
                      exportObj[fyYear[7].fy_name] = formatCurFn(retData[0][fyYear[7].fy_name]);
                      exportObj[fyYear[8].fy_name] = formatCurFn(retData[0][fyYear[8].fy_name]);
                      exportObj[fyYear[9].fy_name] = formatCurFn(retData[0][fyYear[9].fy_name]);
                      exportDataArr.push(exportObj);
                       }
                      

                            var contractData = subProject.contactBudgetData;

                      retData =   callBackFn(contractData,fyYear);
                       if(retData.length > 0){
                      exportObj = {};
                    	exportObj[headerConfigurations.initiative] = retData[0].initiative_code +" - "+ retData[0].initiative_name;
                     exportObj[headerConfigurations.authority]  = retData[0].authority_code +" - "+ retData[0].authority_name;
                      exportObj[headerConfigurations.costCenter]  = retData[0].cost_center+" - "+ retData[0].cost_center_name;
                      exportObj[headerConfigurations.projectNumber]  = retData[0].base_project_code+" - "+retData[0].project_name;
                      exportObj[headerConfigurations.allocationType]  = "WBS Contract";
                    exportObj[headerConfigurations.status]  = retData[0].status;
                      exportObj[headerConfigurations.version]  = retData[0].version;
                   exportObj[headerConfigurations.subProjectNumber]  = "NA";
                      exportObj[headerConfigurations.teiAmount]   = formatCurFn(retData[0].TEI);
                    exportObj[headerConfigurations.all]  = formatCurFn(retData[0].ALL);
                     exportObj[headerConfigurations.prioryears]  = formatCurFn(retData[0].previousTotal);
                      exportObj[fyYear[0].fy_name] = formatCurFn(retData[0][fyYear[0].fy_name]);
                      exportObj[fyYear[1].fy_name] = formatCurFn(retData[0][fyYear[1].fy_name]);
                      exportObj[fyYear[2].fy_name] = formatCurFn(retData[0][fyYear[2].fy_name]);
                      exportObj[fyYear[3].fy_name] = formatCurFn(retData[0][fyYear[3].fy_name]);
                      exportObj[fyYear[4].fy_name] = formatCurFn(retData[0][fyYear[4].fy_name]);
                      exportObj[fyYear[5].fy_name] = formatCurFn(retData[0][fyYear[5].fy_name]);
                      exportObj[fyYear[6].fy_name] = formatCurFn(retData[0][fyYear[6].fy_name]);
                      exportObj[fyYear[7].fy_name] = formatCurFn(retData[0][fyYear[7].fy_name]);
                      exportObj[fyYear[8].fy_name] = formatCurFn(retData[0][fyYear[8].fy_name]);
                      exportObj[fyYear[9].fy_name] = formatCurFn(retData[0][fyYear[9].fy_name]);
                      exportDataArr.push(exportObj);
                       }


                        });

              });
          
    });
    return exportDataArr;
  };

  PageModule.prototype.getAllocationTypes = function (arg1) {

    var configs = arg1;
    configs = configs.Configurations.AllocationTypes;
    var allocTypes = [];
    configs.forEach((item,itemIndex)=>{
          if(item.status == "1" || item.status == 1){
            allocTypes.push(item);
          }
    });
    console.log(allocTypes);
    return allocTypes;
  };

  return PageModule;
});
