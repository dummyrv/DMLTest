define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application } = context;
      console.log('data--'+data.action);
      if (data && data.action === 'APPROVE') {
        const response = await Actions.callRest(context, {
          endpoint: 'ordsBtftapp/getRoleMappingGetMaxApproverLevelForPage',
          uriParams: {
            'p_page_id': $page.variables.newMapping.page_id,
          },
        });

        $page.variables.newMapping.opa_approver_level = response.body.items[0].current_max_approver_level+1;
      }else{
         $page.variables.newMapping.opa_approver_level=null;
      }
    }
  }

  return SelectValueItemChangeChain1;
});
