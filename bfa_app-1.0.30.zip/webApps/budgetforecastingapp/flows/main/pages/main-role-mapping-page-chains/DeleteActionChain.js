define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DeleteActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
      const response = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/postRoleMappingRoleMappingSummary',
        body: $page.variables.deleteMapping,
      });

        if (response.ok === true && response.body.status==="SUCCESS") {
          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            type: 'confirmation',
            message: response.body.message,
          });
        } else {

          await Actions.fireNotificationEvent(context, {
            summary: 'Error',
            message:  response.body.message,
          });
        }

      const deleteDialogeClose = await Actions.callComponentMethod(context, {
        selector: '#delete-dialoge',
        method: 'close',
      });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.currentRoleMappingSDP,
        refresh: null,
      });
    }
    
  }

  return DeleteActionChain;
});
