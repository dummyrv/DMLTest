define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $or, $eq, $and } = context;

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.currentRoleMappingSDP,
        refresh: null,
      });
    }
  }

  return ButtonActionChain2;
});
