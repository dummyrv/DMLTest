define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class IconClickChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      const deleteDialogeOpen = await Actions.callComponentMethod(context, {
        selector: '#delete-dialoge',
        method: 'open',
      });

     
       $page.variables.deleteMapping.rule_id= current.row.rule_id;
       $page.variables.deleteMapping.page_id= current.row.page_id;
       $page.variables.deleteMapping.action_included= current.row.action_included;
       $page.variables.deleteMapping.opa_approver_level= current.row.opa_approver_level;
      
    }
  }

  return IconClickChain1;
});
