define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class IconClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;
      console.log("page id " + current.row.page_id);
      console.log("role_name " + current.row.role_name);
      console.log("action_included " + current.row.action_included);

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $page.variables.allPageEditActionsSDP,
      });

      $page.variables.editMapping.page_id = current.row.page_id;
      $page.variables.editMapping.role_name = current.row.role_name;
      $page.variables.editMapping.action_included = current.row.action_included;
      $page.variables.editMapping.rule_id = current.row.rule_id;
      $page.variables.editMapping.opa_approver_level = current.row.opa_approver_level;


      const editMappingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#editMappingDialog',
        method: 'open',
      });




      //$page.variables.pageID = current.data.page_id;
    }
  }

  return IconClickChain;
});
