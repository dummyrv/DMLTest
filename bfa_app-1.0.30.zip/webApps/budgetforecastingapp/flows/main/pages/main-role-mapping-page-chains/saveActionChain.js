define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;


      if ($page.functions.isFormValid("oj-validation-group-edit")) {


        const response = await Actions.callRest(context, {
          endpoint: 'ordsBtftapp/postRoleMappingRoleMappingSummary',
          body: $page.variables.editMapping,
        });

        if (response.ok === true && response.body.status==="SUCCESS") {
          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            type: 'confirmation',
            message: response.body.message,
          });

          await Actions.fireDataProviderEvent(context, {
            target: $page.variables.currentRoleMappingSDP,
            refresh: null,
          });

          const editMappingDialogClose = await Actions.callComponentMethod(context, {
            selector: '#editMappingDialog',
            method: 'close',
          });
        } else {

          await Actions.fireNotificationEvent(context, {
            summary: 'Error',
            message:  response.body.message,
          });
        }
      }
    }
  }

  return saveActionChain;
});
