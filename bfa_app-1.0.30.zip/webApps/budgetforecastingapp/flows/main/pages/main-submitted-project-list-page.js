define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.formatSubmittedBudget = function(response) {
    console.log(response);
    var resultArr = [];
    response.forEach(function(item, index) {
      var tempObj = {};
      tempObj.proj_number = item.proj_number;
      tempObj.version = item.version;
      tempObj.action_by = item.action_by;
      tempObj.action_date = item.action_date;
      tempObj.budget_version_id = item.budget_version_id;
      resultArr.push(tempObj);
    });
    return resultArr;
  };

  PageModule.prototype.saveApproveStatusData = function(budgetVersionID, version, username, status) {
      var payload = {};
      var budgetArr = [];
      var tempObj = {};
      tempObj.version_id = budgetVersionID;
      tempObj.version = version;
      tempObj.submitted_by = username;
      tempObj.status = status;
      budgetArr.push(tempObj);
      payload.approveProjectVersion = budgetArr;
      return payload;
  };

  PageModule.prototype.budgetRejectDataSave = function(proj_num,
      reasontxt, username) {
      var payload = {};
      var budgetArr = [];
      var tempObj = {};
      tempObj.proj_number = proj_num;
      tempObj.reason = reasontxt.trim();
      tempObj.username = username;
      budgetArr.push(tempObj);
      payload.projBudgetRejection = budgetArr;
      return payload;
    };

  return PageModule;
});
