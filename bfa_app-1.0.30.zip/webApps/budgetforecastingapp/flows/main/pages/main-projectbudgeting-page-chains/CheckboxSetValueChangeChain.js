define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CheckboxSetValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application } = context;

console.log("value is -"+value);

      if (value.length === 0) {
        $page.variables.subProjectSummary.review_completed = 'N';
      } else {
         $page.variables.subProjectSummary.review_completed = value[0];
      }

      console.log("review_completed value is -"+ $page.variables.subProjectSummary.review_completed);
        console.log("budgetData  -"+JSON.stringify( $page.variables.budgetDataGrid.data._rows));
   
      $page.variables.IsCheckBoxValueChange = true;

      await $page.functions.setDatagridEditMode($page.variables.subProjectSummary.status, $page.variables.editFlag, $page.variables.historyFlag, value[0]);

      await Actions.callChain(context, {
        id: 'RefreshGridDataActionChain_update',
      });
    }
  }

  return CheckboxSetValueChangeChain;
});
