define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getProjWBSGetEndorserListByProjectFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application } = context;
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/getProjWBSGetEndorserListByProject',
        uriParams: {
          subprojnumber: $page.variables.subProjNum,
          projrolename: $page.variables.endorserRoleName,
        },
        responseType: 'getProjWBSGetEndorserListByProject',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

  
      if ($page.variables.endorserCount === undefined) {

          $page.variables.endorserCount = callRestEndpoint1.body.items.length;
      }
  

      return callRestEndpoint1;
    }
  }

  return getProjWBSGetEndorserListByProjectFetch;
});
