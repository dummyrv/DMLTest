define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getProjWBSGetEndorserListByProjectFetch3 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application } = context;
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'ordsBtftapp/getProjWBSGetEndorserListByProject',
        uriParams: {
          projrolename: $page.variables.escalatorRoleName,
          subprojnumber: $page.variables.subProjNum,
        },
        responseType: 'getProjWBSGetEndorserListByProject',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      if ($page.variables.escalatorCount === undefined) {

        $page.variables.escalatorCount = callRestEndpoint1.body.items.length;
      }

      return callRestEndpoint1;
    }
  }

  return getProjWBSGetEndorserListByProjectFetch3;
});
