define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      if ($page.variables.endorserCount === 0) {
        await Actions.fireNotificationEvent(context, {
          summary: 'ERROR',
          message: "Failed to find the "+ $page.variables.endorserRoleName+". Please try it again or contact DoT VIC IT team.",
          type: 'warning',
        });

        $page.variables.isFormValid = 'false';
      }
    }
  }

  return SelectClickChain;
});
